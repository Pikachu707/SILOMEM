#!/usr/bin/env python3
"""Print the numbers behind every table and figure of the paper, from the
results stored in this repository. No GPU, no network, no model.

    python reproduce.py            # everything
    python reproduce.py --part agent
    python reproduce.py --part compaction

Sections 3, 4 and 6 (compaction/) are read from the CSV files in
compaction/results/, which hold the reported numbers; each CSV header names
the run it summarizes. Section 7 (agent/) is recomputed from the stored agent
transcripts in agent/results/qwen72b/ with agent/summarize.py.
"""
from __future__ import annotations

import argparse
import glob
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
CRES = os.path.join(ROOT, "compaction", "results")
ARES = os.path.join(ROOT, "agent", "results", "qwen72b")

# paper item -> (csv file, what it shows, script that produced the run)
COMPACTION = [
    ("Table 2, Figure 2", "q1_operating.csv", "ablation at its loosest safe threshold",
     "harness/observe_q1.py"),
    ("Figure 3", "metrics.csv", "AUC of five similarity metrics on four models",
     "harness/observe_q1.py, analysis/similarity_sweep.py"),
    ("Section 3.2", "lo_sweep.csv", "abstention band sweep", "harness/observe_embed.py"),
    ("Table 3", "adversarial.csv", "rewording attack, four wordings", "harness/run_adversarial.py"),
    ("Figure 4", "attackbackend.csv", "rewording attack across five summarizers",
     "sweep_backends.sh"),
    ("Section 4.4", "omission.csv", "citations versus the recorded read set",
     "harness/run_omission.py"),
    ("Figure 6", "crossmem.csv", "damage to the other memories' records",
     "harness/run_crossmem.py"),
    ("Section 6.2", "crossmem_compaction.csv", "compaction stage, both routers",
     "harness/run_crossmem.py --separated"),
    ("Figure 7a", "memgpt.csv", "self-replicating payload over twelve rounds",
     "harness/run_memgpt.py --self-sustaining"),
    ("Figure 7b", "selectivity.csv", "tainted share, topic router",
     "harness/run_selectivity.py"),
    ("Figure 7b", "selectivity_sep.csv", "tainted share, topic+label router",
     "harness/run_selectivity.py --separated"),
    ("Table 7", "cost.csv", "cost of each rule", "harness/run_cost.py"),
    ("Figure 9", "endtoend.csv", "trajectories that act on laundered content",
     "analysis/endtoend.py"),
]

# raw per-run outputs that some numbers come from; printed if present
RAW = [
    ("Table 5, embedding row", "adv_embed.json", "harness/run_adv_embed.py"),
    ("Table 6", "injection.json", "harness/run_injection.py"),
]

AGENT = [
    ("Table 8", "qwen72b_E1.jsonl*", "attacks through memory and later-task utility"),
    ("Figure 8a", "qwen72b_E2.jsonl*", "trusted-input tasks by summaries retrieved"),
    ("Table 11", "qwen72b_E3.jsonl*", "later tasks with no attack"),
    ("Figure 8b", "qwen72b_E4.jsonl*", "refused actions shown to a simulated user"),
]


def show_csv(path: str) -> None:
    comments, rows = [], []
    for line in open(path):
        line = line.rstrip("\n")
        if not line.strip():
            continue
        (comments if line.startswith("#") else rows).append(line)
    for c in comments[:3]:
        print("   " + c)
    if not rows:
        return
    cells = [r.split() for r in rows]
    w = [max(len(r[i]) if i < len(r) else 0 for r in cells) for i in range(max(map(len, cells)))]
    for r in cells:
        print("   " + "  ".join(c.rjust(w[i]) if i else c.ljust(w[i]) for i, c in enumerate(r)))


def compaction() -> None:
    print("=" * 78)
    print("Sections 3, 4 and 6: compaction experiments (compaction/results/)")
    print("=" * 78)
    for item, f, what, script in COMPACTION:
        p = os.path.join(CRES, f)
        print(f"\n## {item}: {what}\n   data: compaction/results/{f}   run: compaction/{script}")
        if os.path.exists(p):
            show_csv(p)
        else:
            print("   (missing)")
    for item, f, script in RAW:
        p = os.path.join(CRES, f)
        print(f"\n## {item}\n   run: compaction/{script}")
        print(f"   raw output compaction/results/{f}: {'present' if os.path.exists(p) else 'not included'}")


def agent() -> None:
    print("\n" + "=" * 78)
    print("Section 7: SiloMem in an AgentDojo agent (agent/results/qwen72b/)")
    print("=" * 78)
    for item, pat, what in AGENT:
        files = sorted(glob.glob(os.path.join(ARES, pat)))
        print(f"\n## {item}: {what}")
        if not files:
            print(f"   transcripts {pat} not in this copy; the stored summary is agent/results/qwen72b/summary.md")
            continue
        out = subprocess.run([sys.executable, os.path.join(ROOT, "agent", "summarize.py"), *files],
                             capture_output=True, text=True)
        print(out.stdout.rstrip() or out.stderr.rstrip())
    print("\nFull summary of all four agent experiments: agent/results/qwen72b/summary.md")
    print("Where the payload went (Appendix E):          agent/results/qwen72b/E1_diag.txt")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--part", choices=["all", "compaction", "agent"], default="all")
    a = ap.parse_args()
    if a.part in ("all", "compaction"):
        compaction()
    if a.part in ("all", "agent"):
        agent()


if __name__ == "__main__":
    main()
