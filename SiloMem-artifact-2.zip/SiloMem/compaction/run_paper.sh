#!/usr/bin/env bash
# Re-run every experiment of Sections 3, 4 and 6 against one served model.
#
#   vllm serve Qwen/Qwen2.5-7B-Instruct --port 8000 &
#   MODEL=Qwen/Qwen2.5-7B-Instruct bash run_paper.sh
#
# Each script writes a JSON file with every model output it used. The CSV
# files in results/ hold the numbers reported in the paper; the header of
# each CSV says which run and which settings it summarizes.
# Figures 3 and 4 compare several models: see sweep_backends.sh.
set -uo pipefail
MODEL="${MODEL:-Qwen/Qwen2.5-7B-Instruct}"
export VLLM_KEY="${VLLM_KEY:-local}"
OUT="${OUT:-results/rerun}"
mkdir -p "$OUT"
TAG=$(echo "$MODEL" | tr '/:' '__')
run() { echo; echo "== $*"; python "$@" || echo "   FAILED: $*"; }

python harness/check_backend.py --base-url "http://localhost:${PORT:-8000}/v1" \
    --api-key-env VLLM_KEY --model "$MODEL" || exit 1

run harness/observe_q1.py      --model "$MODEL" --out "$OUT/q1_$TAG.json"          # Table 2, Fig. 2 (one model)
run harness/run_adversarial.py --model "$MODEL" --out "$OUT/adversarial.json"      # Table 3
run harness/run_adv_embed.py   --model "$MODEL" --out "$OUT/adv_embed.json"        # Table 5, embedding row
run harness/run_injection.py   --model "$MODEL" --out "$OUT/injection.json"        # Table 6
run harness/run_omission.py    --model "$MODEL" --out "$OUT/omission.json"         # Sec. 4.4, citations
run harness/run_crossmem.py    --model "$MODEL" --out "$OUT/crossmem.json"         # Fig. 6
run harness/run_crossmem.py    --model "$MODEL" --separated \
                               --out "$OUT/crossmem_compaction.json"               # Sec. 6.2, compaction stage
run harness/run_selectivity.py --model "$MODEL" --out "$OUT/selectivity.json"      # Fig. 7b, topic router
run harness/run_selectivity.py --model "$MODEL" --separated \
                               --out "$OUT/selectivity_sep.json"                   # Fig. 7b, topic+label router
run harness/run_memgpt.py      --model "$MODEL" --self-sustaining --summary-tokens 256 \
                               --rounds 12 --trials 20 --out "$OUT/memgpt.json"    # Fig. 7a
run harness/run_cost.py        --model "$MODEL" --out "$OUT/cost.json"             # Table 7
run analysis/endtoend.py                                                           # Fig. 9 (Appendix D)
echo; echo "done; outputs in $OUT"
