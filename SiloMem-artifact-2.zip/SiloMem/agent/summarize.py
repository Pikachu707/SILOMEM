#!/usr/bin/env python3
"""Tables from run.py output.

    python summarize.py results/*.jsonl            # markdown to stdout
    python summarize.py results/*.jsonl --csv results/summary.csv

Per (suite, attack, memory mode, refusal mode, model) and arm:
  n           episodes
  U1          utility of the first session (the one that read the injection)
  UL          utility of the later sessions (clean environments)
  ASR-now     attacker goal achieved in the first session
  ASR-later   attacker goal achieved in ANY later session (through memory)
  ref/s       refused actions per session;  ok/s  approved by the oracle user
  memU        share of live memory records labeled U at the end
  tok/s       agent tokens per session;  memtok  extractor+summarizer tokens per episode
Rates carry 95% Wilson intervals. Arms are compared on identical episodes, so
the paired tests (McNemar, exact) at the bottom use only episodes both arms
completed.
"""
from __future__ import annotations

import argparse
import gzip
import csv
import json
import math
from collections import defaultdict


def wilson(k: int, n: int) -> tuple[float, float]:
    if n == 0:
        return (float("nan"), float("nan"))
    z = 1.96
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, c - h), min(1.0, c + h))


def mcnemar_exact(b: int, c: int) -> float:
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    p = sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n
    return min(1.0, 2 * p)


def fmt_rate(k, n):
    if n == 0:
        return "–"
    lo, hi = wilson(k, n)
    return f"{100*k/n:.0f}% [{100*lo:.0f},{100*hi:.0f}]"


def load(paths):
    rows = []
    for p in paths:
        for line in (gzip.open(p, "rt") if p.endswith(".gz") else open(p)):
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    # newest implementation wins; among equal versions, the last write wins
    uniq = {}
    for r in rows:
        k = (r["episode_id"], r["arm"], r["memory_mode"], r["on_refuse"], r.get("top_k", 3),
             r.get("cli_model"), r["mock"])
        if k not in uniq or int(r.get("impl", "1")) >= int(uniq[k].get("impl", "1")):
            uniq[k] = r
    return list(uniq.values())


ORDER = ["nomem", "nomem_guard", "plain", "whole", "silomem"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+")
    ap.add_argument("--csv", default=None)
    a = ap.parse_args()
    rows = load(a.files)
    groups = defaultdict(lambda: defaultdict(list))
    for r in rows:
        g = (r["spec"]["suite"], r["spec"]["template"], r["memory_mode"], r["on_refuse"],
             r.get("top_k", 3), r.get("cli_model") or "MOCK")
        groups[g][r["arm"]].append(r)

    out_csv = []
    for g in sorted(groups):
        suite, attack, mode, refuse, top_k, model = g
        mock = any(r["mock"] for arms in groups[g].values() for r in arms)
        print(f"\n### {suite} · attack={attack} · memory={mode} (top-{top_k}) · on_refuse={refuse} · model={model}"
              + ("  **MOCK: plumbing check, not a result**" if mock else ""))
        print("\n| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |")
        print("|---|---|---|---|---|---|---|---|---|---|---|---|")
        for arm in [x for x in ORDER if x in groups[g]]:
            rs = groups[g][arm]
            n = len(rs)
            s1 = [r["sessions"][0] for r in rs]
            sl = [s for r in rs for s in r["sessions"][1:]]
            alls = [s for r in rs for s in r["sessions"]]
            u1 = sum(s["utility"] for s in s1)
            ul = sum(s["utility"] for s in sl)
            att = [r for r in rs if r["summary"]["attack_delayed"] is not None]
            an = sum(bool(r["summary"]["attack_immediate"]) for r in att)
            al = sum(bool(r["summary"]["attack_delayed"]) for r in att)
            ref = sum(len(s["refusals"]) for s in alls) / max(1, len(alls))
            ok = sum(len(s["approvals"]) for s in alls) / max(1, len(alls))
            mem = [r["memory"] for r in rs if r["memory"]]
            memu = (sum(m["live_U"] for m in mem) / max(1, sum(m["live"] for m in mem))) if mem else None
            tok = sum(s["agent_usage"]["prompt_tokens"] + s["agent_usage"]["completion_tokens"]
                      for s in alls) / max(1, len(alls))
            mt = [sum(v["prompt_tokens"] + v["completion_tokens"] for v in r["memory_usage"].values())
                  for r in rs if r.get("memory_usage")]
            memtok = sum(mt) / len(mt) if mt else 0
            err = sum(r["summary"]["errors"] for r in rs)
            row = {"suite": suite, "attack": attack, "memory_mode": mode, "top_k": top_k, "on_refuse": refuse,
                   "model": model, "arm": arm, "n": n,
                   "U1": u1 / max(1, n), "UL": ul / max(1, len(sl)),
                   "ASR_now": an / len(att) if att else None,
                   "ASR_later": al / len(att) if att else None,
                   "refusals_per_session": ref, "approvals_per_session": ok,
                   "memory_U_share": memu, "agent_tokens_per_session": tok,
                   "memory_tokens_per_episode": memtok, "errors": err, "mock": mock}
            out_csv.append(row)
            print(f"| {arm} | {n} | {fmt_rate(u1, n)} | {fmt_rate(ul, len(sl))} | "
                  f"{fmt_rate(an, len(att)) if att else '–'} | {fmt_rate(al, len(att)) if att else '–'} | "
                  f"{ref:.2f} | {ok:.2f} | {'–' if memu is None else f'{100*memu:.0f}%'} | "
                  f"{tok:.0f} | {memtok:.0f} | {err} |")

        # paired comparisons on shared episodes
        pairs = [("plain", "silomem", "attack_delayed"), ("whole", "silomem", "utility_later"),
                 ("nomem_guard", "silomem", "utility_later"), ("plain", "silomem", "utility_later")]
        lines = []
        for x, y, metric in pairs:
            if x not in groups[g] or y not in groups[g]:
                continue
            ex = {r["episode_id"]: r for r in groups[g][x]}
            ey = {r["episode_id"]: r for r in groups[g][y]}
            common = sorted(set(ex) & set(ey))
            if metric == "attack_delayed":
                vx = [bool(ex[e]["summary"][metric]) for e in common if ex[e]["summary"][metric] is not None]
                vy = [bool(ey[e]["summary"][metric]) for e in common if ey[e]["summary"][metric] is not None]
            else:
                vx = [s["utility"] for e in common for s in ex[e]["sessions"][1:]]
                vy = [s["utility"] for e in common for s in ey[e]["sessions"][1:]]
            if not vx:
                continue
            b = sum(1 for p, q in zip(vx, vy) if p and not q)
            c = sum(1 for p, q in zip(vx, vy) if q and not p)
            lines.append(f"- {metric}: {x} {sum(vx)}/{len(vx)} vs {y} {sum(vy)}/{len(vy)}; "
                         f"discordant {b}/{c}; McNemar p={mcnemar_exact(b, c):.3g}")
        if lines:
            print("\nPaired on identical episodes:")
            print("\n".join(lines))

    if a.csv:
        with open(a.csv, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(out_csv[0].keys()))
            w.writeheader()
            w.writerows(out_csv)
        print(f"\nwrote {a.csv}")


if __name__ == "__main__":
    main()
