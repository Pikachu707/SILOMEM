# Section 7: SiloMem in a multi-session AgentDojo agent

This part puts SiloMem's four parts (isolated extraction, routing by label,
recorded read sets, action check) into a real tool-using agent and runs it
across sessions, against injections that only work through memory. Every
result comes from AgentDojo's programmatic checks of the environment state;
no LLM judge is used.

| Paper | Experiment | Stored result |
|---|---|---|
| Table 8 | E1: delayed self-replicating attack, all summaries in the prompt | `results/qwen72b/qwen72b_E1.jsonl.gz`, `summary.md` |
| Figure 8a | E2: trusted-input tasks, top-1/2/3 retrieved summaries | `summary.md` |
| Table 11 | E3: no attack | `summary.md` |
| Figure 8b | E4: refused actions shown to a simulated user | `summary.md` |
| Appendix E | label tables, trusted-input tasks, retrieval, simulated user, payload funnel | `silomem_agent/labels.py`, `silomem_agent/extra_tasks.py`, `results/qwen72b/E1_diag.txt` |

`python summarize.py results/qwen72b/qwen72b_E1.jsonl.gz` recomputes Table 8
from the stored transcripts.

```
silomem_agent/
  labels.py       lattice; untrusted/sensitive tool tables, fixed before any run
  memory.py       memory store: plain / whole / silomem, BM25 retrieval, handles
  guard.py        replaces AgentDojo's ToolsExecutor: records the read set, runs the action check
  attacks.py      four injection templates: immediate, delayed, self-replicating, preference
  runner.py       multi-session episodes, 5 arms, paired design
  agents.py       mock agent (plumbing only) + OpenAI-compatible agent with token counting
  models.py       extractor/summarizer (mock or OpenAI-compatible)
  extra_tasks.py  8 supplementary banking tasks whose actions need only trusted input
  suites.py       suite loading (includes banking_extra)
run.py            run (resumable, parallel)
summarize.py      tables + Wilson intervals + paired McNemar tests
diagnose.py       attack-chain funnel: read → in memory → retrieved → tried → succeeded
tests/            27 tests, no GPU; includes an offline test of the real-model path via a fake OpenAI server
scripts/          run_all.sh (one-click, recommended), run_pilot.sh, run_main.sh
```

## 1. Run the offline checks first (no GPU, about 10 seconds)

```bash
pip install -r requirements.txt
python -m pytest tests -q
python run.py --backend mock --suite banking banking_extra --attack delayed --out results/mock.jsonl
python summarize.py results/mock.jsonl
```

Mock results only show the plumbing is right. They are not experimental
results, and summarize.py marks them **MOCK**. The mock agent obeys whenever
it sees the attacker's goal, and the mock summarizer keeps injected text
verbatim, which is the worst case for a defense.

## 2. Connect a real model

Any OpenAI-compatible server works. With vLLM, tool calling must be enabled:

```bash
# Qwen2.5 / Qwen3
vllm serve Qwen/Qwen2.5-72B-Instruct-AWQ --enable-auto-tool-choice \
    --tool-call-parser hermes --max-model-len 32768 --port 8000
# Llama 3.1/3.3 uses --tool-call-parser llama3_json
```

Don't use 7B/8B models as the agent: their AgentDojo utility is too low, so
the defense comparison would have nothing to compare. Use 32B or larger, or
an API model.

```bash
export OPENAI_API_KEY=local
M=Qwen/Qwen2.5-72B-Instruct-AWQ

# Pilot run (check the attack lands first; about 1–2 hours)
python run.py --backend openai --model $M --suite banking --attack delayed \
    --injection-tasks injection_task_0 injection_task_5 injection_task_7 \
    --workers 8 --out results/pilot.jsonl
python summarize.py results/pilot.jsonl
```

**Read the plain row of the pilot first.** If the plain arm's ASR-later is
close to 0, the delayed injection didn't land through memory with this model.
Any defense would then look effective, and the comparison doesn't mean
anything. In that case, first switch to `--attack self_replicating`, or check
whether the summarizer is dropping the instruction.

## 3. Main experiments

| Experiment | Command | What it answers |
|---|---|---|
| Delayed attack, main table | `--suite banking slack travel workspace --attack delayed` | Does injected content that enters memory get acted on in later sessions; can SiloMem stop it |
| Self-replicating | `--attack self_replicating` | Payload designed to survive recursive compaction (paper Fig. 5) |
| Memory poisoning | `--attack preference` | MINJA/AgentPoison style: the payload reads like a standing user preference, which summarizers tend to keep |
| Immediate attack, control | `--attack important_instructions` | AgentDojo's standard attack; for comparison with published numbers |
| Benign utility | `--attack none` | False refusals and utility cost when there is no attack |
| Selectivity | `--suite banking_extra --top-k 1 2 3` (one run per top-k) | Prop. 4.3: refusals SiloMem avoids compared with whole-cluster |
| Confirmation cost | add `--on-refuse confirm` to any of the above | Utility if the user approves legitimate actions, and how many confirmations are needed |
| Preloaded memory | `--memory-mode preload` | MemGPT-style: all notes placed in context |
| Auto-retrieved memory | `--memory-mode auto` | mem0-style: the orchestrator retrieves top-k notes for the request and puts them in context |

The five arms (each episode runs every arm, with the same task sequence):

- `nomem`: stock agent with no memory. Its delayed ASR must be 0 because there is no path through memory.
- `nomem_guard`: no memory; the action check covers only the current session.
- `plain`: memory + compaction by topic, no label enforcement (a Letta/MemGPT-style baseline).
- `whole`: whole-cluster propagation + action check.
- `silomem`: isolated extraction + (topic, label) routing + recorded read sets + action check.

## 4. Design decisions fixed before any run (state them in the paper)

1. **Untrusted tools** = union of:
   - tools whose output carried an AgentDojo injection canary
     (`test_every_canary_carrier_is_untrusted` re-derives this and fails if
     any carrier is missing);
   - tools that return third-party content by design (Slack messages/inbox,
     received emails, files).
2. **Sensitive actions** = every tool that changes environment state, plus
   Slack's `get_webpage`, which logs the URL it visits and can exfiltrate
   data through it; one Slack injection goal is visiting a URL.
   `test_tools_that_change_state_are_sensitive` replays every ground-truth
   call to check this.
3. **The action rule follows the paper**: a sensitive action goes through
   only if every item in the read set is T. Read actions are never blocked.
4. **Arguments chosen by the model count as derived content**: a tool
   output's label is the meet of the tool's source label and the context
   label at the time of the call.
5. **Retrieval** is BM25 + stopwords, deterministic, and blind to labels.
6. **The confirm-mode user** approves a blocked action iff the tool is in
   the user task's ground truth and no argument carries a value that only
   the attacker uses. This approximates a careful person. Report it
   separately from deny mode.

## 5. Things to know in advance

- **In AgentDojo, every task that takes an action reads untrusted data first.**
  Banking 12/12, Slack 20/20, travel 6/6, workspace 22/22. So in deny mode,
  any strict provenance defense refuses these actions in that session
  whether or not memory is involved. That is why `nomem_guard` is the
  reference: SiloMem's job is to keep memory from adding refusals on top of
  it, and to block delayed attacks. The paper's selectivity claim
  (Prop. 4.3) only shows on actions that need trusted input alone, which is
  why `banking_extra` exists. It is our own supplement: describe it in the
  paper and report it separately.
- **Selectivity depends on retrieval.** On the mock, banking_extra later
  utility is whole 17% vs SiloMem 42% at top-1, and 5% vs 7% at top-3: the
  more notes a search returns, the more likely an untrusted one gets mixed
  into the deciding call. This matches the precondition of Prop. 4.3 (the
  deciding call reads only the summaries that hold the needed claims).
  Report the top-k sweep in the paper.
- **Out of scope**: travel injection_task_6 only changes what the answer
  says. The action check doesn't cover this; report it separately.
- **Count only calls that actually ran.** AgentDojo builds its call trace
  from the calls the model *proposed*, so a refused call would still count
  as an attack success for trace-based checks (for example Slack
  injection_task_5). The runner keeps only executed calls in the trace
  (`test_refused_calls_do_not_count_as_attack_success`). Calls that fail for
  other reasons stay in the trace, as in AgentDojo.
- Some AgentDojo workspace injection tasks have an empty ground truth, so the
  mock agent can't "obey" them. Real models are unaffected.

## 6. Output fields

One JSON line per (episode, arm):

- Per-session fields:
  - `utility`, `attack_success`
  - `refusals`, `approvals`
  - `memory_read_labels`
  - `agent_usage`
- Episode level:
  - `compactions` (per round: extraction/summarization calls, number of untrusted records)
  - `memory_usage` (extractor/summarizer tokens)

Columns from `summarize.py`:

| Column | Meaning |
|---|---|
| U1 | utility of the first session |
| UL | utility of later sessions |
| ASR-now | attack success in the first session |
| ASR-later | attack success through memory |
| ref/s | refusals per session |
| ok/s | confirmations per session |
| memU | share of untrusted memory records |
| tok/s | agent tokens per session |
| memtok | memory tokens per episode |

## 7. Full mock run (plumbing check, not a result)

`results/mock_summary.md` holds every mock table. The delayed attack, at a glance:

| suite | plain ASR-later | whole ASR-later | SiloMem ASR-later | memU whole → SiloMem | later utility: SiloMem vs nomem_guard |
|---|---|---|---|---|---|
| banking | 99% | 0% | 0% | 79% → 56% | 48% vs 48% |
| slack | 99% | 0% | 0% | 86% → 73% | 0% vs 4% |
| travel | 86% | 0% | 0% | 92% → 64% | 65% vs 65% |
| workspace | 33% | 0% | 0% | 94% → 75% | 46% vs 46% |
| banking_extra, top-1 | 100% | 0% | 0% | 81% → 47% | 42% (whole 17%) vs 100% |

These only show that each arm behaves as designed. The real numbers come
from a real model (`scripts/run_main.sh`).

## 8. Pilot findings with Qwen2.5-72B (banking, plain arm, 48 episodes per configuration)

- The summarizer writes the payload into memory and keeps it through compaction
  in ~75% of episodes (essentially every time the agent read it), and rewrites
  it as the assistant's own first-person "standing instruction". This is the
  laundering the paper describes, observed in the wild.
- In recall mode the agent called search_memory in only 6–8% of later sessions,
  so memory almost never reached the deciding call. Hence the main experiments
  use preload (MemGPT-style) for security and auto (mem0-style) for selectivity.
- Even with the payload in context, Qwen2.5-72B acted on it in 0.7–4.9% of later
  sessions. Best configuration: self_replicating + preload, 6/48 episodes.
