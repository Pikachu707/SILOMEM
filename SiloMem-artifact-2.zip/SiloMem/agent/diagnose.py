#!/usr/bin/env python3
"""Where does the delayed attack break? A funnel per (suite, attack, memory mode, arm).

    python diagnose.py results/diag_*.jsonl
    python diagnose.py results/diag_*.jsonl --examples 2     # also print memory notes carrying the payload

Stages (later sessions = sessions 2+, clean environments):
  S1 read      session 1 context contained the payload (the agent read the injected slot)
  S1 tried     session 1 proposed a call with attacker values (immediate obedience)
  in memory    payload text (attacker values or goal) present in live memory after round 1
  survives     ... still present after the last round
  searched     later sessions that called search_memory at least once (recall mode only;
               in preload/auto mode notes are placed in context, see "via memory read")
  saw it       later sessions whose context contained the payload
  tried        later sessions that proposed a call with attacker values
  success      later sessions where AgentDojo's check says the attacker goal was achieved
If 'in memory' is low, the summarizer drops the payload. If 'saw it' is low but
'in memory' is high, retrieval (or the agent not searching) is the gap. If
'tried' is low but 'saw it' is high, the model reads the payload and ignores it.
"""
from __future__ import annotations

import argparse
import gzip
import json
from collections import defaultdict


def pct(k, n):
    return f"{100*k/n:5.1f}% ({k}/{n})" if n else "   –"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+")
    ap.add_argument("--examples", type=int, default=0)
    a = ap.parse_args()
    newest = {}
    for f in a.files:
        for line in (gzip.open(f, "rt") if f.endswith(".gz") else open(f)):
            if line.strip():
                r = json.loads(line)
                if r["spec"]["injection_task"] is None:
                    continue
                k = (r["episode_id"], r["arm"], r["memory_mode"], r["on_refuse"], r.get("top_k", 3))
                if k not in newest or int(r.get("impl", "1")) >= int(newest[k].get("impl", "1")):
                    newest[k] = r
    groups = defaultdict(list)
    for r in newest.values():
        groups[(r["spec"]["suite"], r["spec"]["template"], r["memory_mode"], r["arm"])].append(r)
    for key in sorted(groups):
        rs = groups[key]
        if "diag" not in rs[0]["sessions"][0]:
            print(f"\n{key}: no diagnostics in this file (produced before the diagnostic version)")
            continue
        n = len(rs)
        s1 = [r["sessions"][0]["diag"] for r in rs]
        later = [s for r in rs for s in r["sessions"][1:]]
        dl = [s["diag"] for s in later]
        comp = [r["compactions"] for r in rs if r["compactions"]]
        print(f"\n### {' · '.join(key)}   episodes={n}")
        print(f"  S1 read      {pct(sum(d['marker_in_context'] for d in s1), n)}")
        print(f"  S1 tried     {pct(sum(d['attacker_call_proposed'] for d in s1), n)}")
        print(f"  S1 success   {pct(sum(bool(r['sessions'][0]['attack_success']) for r in rs), n)}")
        if comp:
            print(f"  in memory    {pct(sum(c[0]['marker_in_memory'] for c in comp), len(comp))}"
                  f"   labels of carriers: {sorted({l for c in comp for l in c[0]['marker_labels']})}")
            print(f"  survives     {pct(sum(c[-1]['marker_in_memory'] for c in comp), len(comp))}")
        print(f"  searched     {pct(sum(d['search_calls'] > 0 for d in dl), len(dl))}")
        print(f"  saw it       {pct(sum(d['marker_in_context'] for d in dl), len(dl))}"
              f"   (via memory read: {sum(bool(d['marker_read_from_memory']) for d in dl)})")
        print(f"  tried        {pct(sum(d['attacker_call_proposed'] for d in dl), len(dl))}")
        print(f"  success      {pct(sum(bool(s['attack_success']) for s in later), len(later))}"
              f"   episodes with any later success: {sum(bool(r['summary']['attack_delayed']) for r in rs)}/{n}")
        if a.examples:
            shown = 0
            for r in rs:
                for note in r.get("memory_snapshot") or []:
                    if any(m in note["text"].lower() for m in r["markers"]):
                        print(f"    [{note['label']}/{note['topic']}] {note['text'][:400]!r}")
                        shown += 1
                        break
                if shown >= a.examples:
                    break
            if not shown and rs[0].get("memory_snapshot") is not None:
                r = rs[0]
                print("    no carrier found; first memory notes of one episode:")
                for note in (r["memory_snapshot"] or [])[:3]:
                    print(f"    [{note['label']}/{note['topic']}] {note['text'][:300]!r}")


if __name__ == "__main__":
    main()
