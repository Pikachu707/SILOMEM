"""A tiny OpenAI-compatible server for testing the real-model code path offline.

Agent requests (with tools): on the first turn of a session it calls
search_memory if offered, otherwise the first tool whose name starts with
"get_"; then, once a tool result is present, it answers in text.
Memory requests (no tools): echoes the notes back, so injected text survives.
Responses carry `usage`, so token accounting is exercised.
"""
from __future__ import annotations

import json
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


def _reply(body: dict) -> dict:
    msgs = body.get("messages", [])
    tools = body.get("tools") or []
    names = [t["function"]["name"] for t in tools]
    has_tool_result = any(m.get("role") == "tool" for m in msgs)
    if tools and not has_tool_result:
        name = "search_memory" if "search_memory" in names else next(
            (n for n in names if n.startswith("get_")), names[0])
        args = {"query": "user asked returned"} if name == "search_memory" else {}
        msg = {"role": "assistant", "content": None, "tool_calls": [{
            "id": f"call_{uuid.uuid4().hex[:8]}", "type": "function",
            "function": {"name": name, "arguments": json.dumps(args)}}]}
        finish = "tool_calls"
    else:
        last = msgs[-1]["content"] if msgs else ""
        if isinstance(last, list):
            last = " ".join(b.get("text", "") for b in last if isinstance(b, dict))
        text = "Done." if tools else (last.split("Notes:\n")[-1].split("Record:\n")[-1])[:1500]
        msg = {"role": "assistant", "content": text}
        finish = "stop"
    pt = sum(len(json.dumps(m)) for m in msgs) // 4
    return {"id": "chatcmpl-fake", "object": "chat.completion", "created": 0, "model": body.get("model"),
            "choices": [{"index": 0, "message": msg, "finish_reason": finish}],
            "usage": {"prompt_tokens": pt, "completion_tokens": 7, "total_tokens": pt + 7}}


class _H(BaseHTTPRequestHandler):
    def log_message(self, *a):  # silence
        pass

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        out = json.dumps(_reply(body)).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out)))
        self.end_headers()
        self.wfile.write(out)

    def do_GET(self):
        out = json.dumps({"object": "list", "data": [{"id": "fake", "object": "model"}]}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out)))
        self.end_headers()
        self.wfile.write(out)


def serve(port: int = 0):
    srv = ThreadingHTTPServer(("127.0.0.1", port), _H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


if __name__ == "__main__":
    s = serve(8009)
    print("fake OpenAI server on http://127.0.0.1:8009/v1")
    threading.Event().wait()
