#!/usr/bin/env bash
# Main experiments. Every command resumes; re-run after any interruption.
# Usage: M=Qwen/Qwen2.5-72B-Instruct-AWQ bash scripts/run_main.sh
set -euo pipefail
: "${M:?set M to the served model name}"
export OPENAI_API_KEY=${OPENAI_API_KEY:-local}
BASE=${BASE:-http://localhost:8000/v1}
W=${W:-8}
TAG=$(echo "$M" | tr '/:' '__')
R() { python run.py --backend openai --base-url "$BASE" --model "$M" --workers "$W" "$@"; }

# 1. Main table: delayed attack, four AgentDojo suites
R --suite banking slack travel workspace --attack delayed --out results/${TAG}_delayed.jsonl
# 2. Self-replicating payload
R --suite banking slack --attack self_replicating --out results/${TAG}_selfrep.jsonl
# 3. Standard immediate attack (comparable with published AgentDojo numbers)
R --suite banking slack travel workspace --attack important_instructions --arms nomem nomem_guard silomem \
  --out results/${TAG}_immediate.jsonl
# 4. Benign utility and false refusals
R --suite banking slack travel workspace --attack none --out results/${TAG}_benign.jsonl
# 5. Selectivity (Prop. 4.3): supplementary tasks, retrieval depth sweep
for k in 1 2 3; do
  R --suite banking_extra --attack delayed --arms nomem_guard whole silomem --top-k $k \
    --out results/${TAG}_extra_topk.jsonl
done
# 6. Confirmation cost
R --suite banking slack --attack delayed --on-refuse confirm --out results/${TAG}_confirm.jsonl

python summarize.py results/${TAG}_*.jsonl --csv results/${TAG}_summary.csv | tee results/${TAG}_summary.md
