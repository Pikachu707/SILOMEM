#!/usr/bin/env bash
# Pilot: check that the delayed injection lands through memory with this model before the full run.
# Usage: M=Qwen/Qwen2.5-72B-Instruct-AWQ bash scripts/run_pilot.sh
set -euo pipefail
: "${M:?set M to the served model name}"
export OPENAI_API_KEY=${OPENAI_API_KEY:-local}
BASE=${BASE:-http://localhost:8000/v1}
W=${W:-8}
python run.py --backend openai --base-url "$BASE" --model "$M" --suite banking \
  --attack delayed --injection-tasks injection_task_0 injection_task_5 injection_task_7 \
  --workers "$W" --out results/pilot.jsonl
python summarize.py results/pilot.jsonl
echo
echo "Check the plain row: if ASR-later is close to 0, the attack is not landing through memory."
echo "Try --attack self_replicating before running the main experiments."
