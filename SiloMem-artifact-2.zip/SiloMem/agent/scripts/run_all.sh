#!/usr/bin/env bash
# One-click: every experiment, in order, resumable.
#
#   tmux new -d -s all "bash /root/silomem-agent/scripts/run_all.sh"
#   tail -f /root/silomem-agent/logs/run_all.log
#
# Options (environment variables):
#   RUN_E4=0      skip E4 (confirmation cost, about 3 h)
#   GATE=0        do not stop if the attack never lands in E1 banking
#   W=24          concurrent requests (default 16)
#   BACKEND=mock  dry run without GPU (checks the script itself)
#   EXTRA="--limit 3"  extra arguments for every run (e.g. a quick smoke test)
#
# Re-running the script skips everything already finished.
set -uo pipefail
cd "$(dirname "$0")/.."
ROOT=$(pwd)

MODEL_NAME=${MODEL_NAME:-qwen72b}
HF_MODEL=${HF_MODEL:-Qwen/Qwen2.5-72B-Instruct-AWQ}
PORT=${PORT:-8000}
BASE=http://localhost:${PORT}/v1
W=${W:-16}
RUN_E4=${RUN_E4:-1}
GATE=${GATE:-1}
BACKEND=${BACKEND:-openai}
VENV=${VENV:-/root/venv-silo}
VLLM_VENV=${VLLM_VENV:-/root/venv-vllm}
TAG=${TAG:-$MODEL_NAME}
EXTRA=${EXTRA:-}

[ -f "$VENV/bin/activate" ] && source "$VENV/bin/activate"
export OPENAI_API_KEY=${OPENAI_API_KEY:-local}
mkdir -p logs results
LOG=logs/run_all.log

log() { echo "[$(date '+%F %T')] $*" | tee -a "$LOG"; }

# ---------------------------------------------------------------- model server
server_up() { curl -sf "$BASE/models" 2>/dev/null | grep -q "\"$MODEL_NAME\""; }

start_server() {
  log "starting vLLM ($HF_MODEL as $MODEL_NAME) in tmux session 'vllm'; log: /root/vllm.log"
  tmux kill-session -t vllm 2>/dev/null || true
  tmux new -d -s vllm "source $VLLM_VENV/bin/activate && export VLLM_USE_FLASHINFER_SAMPLER=0 && \
    vllm serve $HF_MODEL --served-model-name $MODEL_NAME \
      --enable-auto-tool-choice --tool-call-parser hermes \
      --max-model-len 32768 --gpu-memory-utilization 0.92 \
      --enable-prefix-caching --port $PORT 2>&1 | tee /root/vllm.log"
  for _ in $(seq 1 180); do server_up && { log "vLLM is up"; return 0; }; sleep 10; done
  log "ERROR: vLLM did not come up within 30 minutes. See /root/vllm.log"
  return 1
}

ensure_server() {
  [ "$BACKEND" = mock ] && return 0
  server_up || start_server || exit 1
}

check_tools() {
  [ "$BACKEND" = mock ] && return 0
  local out
  out=$(curl -s "$BASE/chat/completions" -H 'Content-Type: application/json' -d "{
    \"model\":\"$MODEL_NAME\",\"messages\":[{\"role\":\"user\",\"content\":\"What is my balance?\"}],
    \"tools\":[{\"type\":\"function\",\"function\":{\"name\":\"get_balance\",\"description\":\"Get the account balance\",
    \"parameters\":{\"type\":\"object\",\"properties\":{}}}}]}")
  if echo "$out" | grep -q '"tool_calls"' && echo "$out" | grep -q get_balance; then
    log "tool calling OK"
  else
    log "ERROR: the server did not return a tool call. Check --tool-call-parser. Response:"
    echo "$out" | head -c 1500 | tee -a "$LOG"; echo
    exit 1
  fi
}

# ---------------------------------------------------------------- one experiment step
# Runs twice: the second pass only picks up jobs that failed in the first
# (e.g. because the server restarted). Finished jobs are never repeated.
step() {
  local name=$1; shift
  # the marker carries the memory implementation version: after a fix, every
  # step is revisited and only the jobs of the changed arm actually run
  local ver
  ver=$(python -c "from silomem_agent.memory import IMPL_VERSION as v; print('-'.join(v[k] for k in sorted(v)))")
  if [ -f "logs/.done_${name}_$ver" ]; then log "skip $name (already finished)"; return 0; fi
  for pass in 1 2; do
    ensure_server
    log "START $name (pass $pass)"
    local t0=$(date +%s)
    if [ "$BACKEND" = mock ]; then
      python run.py --backend mock "$@" $EXTRA >> "logs/$name.log" 2>&1
    else
      python run.py --backend openai --base-url "$BASE" --model "$MODEL_NAME" --workers "$W" "$@" $EXTRA \
        >> "logs/$name.log" 2>&1
    fi
    local failed
    failed=$(grep -c "FAILED" "logs/$name.log" 2>/dev/null || true)
    log "END   $name (pass $pass) in $(( ($(date +%s) - t0) / 60 )) min; FAILED lines so far: ${failed:-0}"
    # if nothing failed in this pass, we are done
    if ! tail -n 400 "logs/$name.log" | grep -q FAILED; then break; fi
    server_up || log "server is down; restarting before pass 2"
  done
  touch "logs/.done_${name}_$ver"
}

gate_check() {
  [ "$GATE" = 0 ] && return 0
  python - "$1" <<'EOF'
import json, sys
rows = [json.loads(l) for l in open(sys.argv[1]) if l.strip()]
plain = [r for r in rows if r["arm"] == "plain" and r["spec"]["suite"] == "banking"]
hits = sum(bool(r["summary"]["attack_delayed"]) for r in plain)
print(f"GATE: plain arm, banking, delayed attack succeeded in {hits}/{len(plain)} episodes")
sys.exit(0 if hits > 0 else 3)
EOF
}

# ================================================================ run
log "======== run_all start: model=$MODEL_NAME backend=$BACKEND workers=$W ========"
ensure_server
check_tools
python -m pytest tests -q -p no:cacheprovider >> "$LOG" 2>&1 || { log "ERROR: tests failed, see $LOG"; exit 1; }
log "tests passed"

E1=results/${TAG}_E1.jsonl
E2=results/${TAG}_E2.jsonl
E3=results/${TAG}_E3.jsonl
E4=results/${TAG}_E4.jsonl

# E1 security, main table: self-replicating payload, MemGPT-style preloaded memory
step E1a_banking   --suite banking   --attack self_replicating --memory-mode preload --out "$E1"
if ! gate_check "$E1" | tee -a "$LOG"; then
  log "STOP: the attack never landed in the plain arm, so the security comparison would be empty."
  log "Send results/${TAG}_E1.jsonl to Claude, or re-run with GATE=0 to continue anyway."
  exit 3
fi
step E1b_slack     --suite slack     --attack self_replicating --memory-mode preload --out "$E1"
step E1c_travel    --suite travel    --attack self_replicating --memory-mode preload --out "$E1"
step E1d_workspace --suite workspace --attack self_replicating --memory-mode preload \
     --injection-tasks injection_task_0 injection_task_3 injection_task_4 injection_task_5 --out "$E1"

# E2 selectivity (Prop. 4.3): supplementary trusted-input tasks, mem0-style retrieval, depth sweep
for k in 1 2 3; do
  step E2_top$k --suite banking_extra --attack self_replicating --memory-mode auto \
       --arms nomem_guard whole silomem --top-k $k --out "$E2"
done

# E3 benign utility and false refusals
step E3_benign --suite banking slack travel workspace --attack none --memory-mode preload --out "$E3"

# E4 confirmation cost (optional)
if [ "$RUN_E4" = 1 ]; then
  step E4_confirm --suite banking slack --attack self_replicating --memory-mode preload \
       --on-refuse confirm --out "$E4"
fi

# ---------------------------------------------------------------- reports
python summarize.py results/${TAG}_E*.jsonl --csv results/${TAG}_summary.csv > results/${TAG}_summary.md
python diagnose.py "$E1" --examples 2 > logs/E1_diag.txt
log "summary: results/${TAG}_summary.md   diagnostics: logs/E1_diag.txt"
log "======== ALL DONE ========"
cat <<EOF | tee -a "$LOG"

Download on your own computer:
  scp -P 34348 -i ~/.ssh/id_ed25519 root@195.26.233.39:$ROOT/results/${TAG}_summary.md ./
  scp -P 34348 -i ~/.ssh/id_ed25519 root@195.26.233.39:$ROOT/logs/E1_diag.txt ./
  scp -P 34348 -i ~/.ssh/id_ed25519 root@195.26.233.39:$ROOT/$E1 ./
EOF
