"""Suite loading, including the supplementary banking_extra suite."""
from __future__ import annotations

import copy
from collections import defaultdict
from functools import lru_cache

from agentdojo.task_suite.load_suites import get_suite

VERSION = "v1.2.2"


def base(name: str) -> str:
    return name.split("_")[0]


@lru_cache(maxsize=None)
def load_suite(name: str):
    if name == "banking_extra":
        from .extra_tasks import EXTRA_TASKS
        orig = get_suite(VERSION, "banking")
        s = copy.copy(orig)
        s._user_tasks = defaultdict(dict, {k: dict(v) for k, v in orig._user_tasks.items()})
        for cls in EXTRA_TASKS:
            s.register_user_task(cls)
        return s
    return get_suite(VERSION, name)


def task_pools(name: str) -> tuple[list[str], list[str]]:
    """(first-session pool, later-session pool)."""
    s = load_suite(name)
    ids = sorted(s.user_tasks, key=lambda x: int(x.split("_")[-1]))
    if name == "banking_extra":
        from .extra_tasks import EXTRA_IDS
        return [i for i in ids if i not in EXTRA_IDS], [i for i in ids if i in EXTRA_IDS]
    return ids, ids
