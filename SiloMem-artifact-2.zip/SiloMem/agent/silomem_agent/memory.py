"""Long-term memory with compaction, in three variants.

  plain    entries are grouped by topic and summarized together; labels are
           computed for the audit but nothing enforces them (the usual design,
           e.g. a MemGPT/Letta-style recursive summary).
  whole    same grouping; each summary is labeled with the meet over its whole
           group (whole-cluster propagation).
  silomem  each entry is extracted alone (read set = that entry), claims are
           routed by (topic, label) so no summarization call mixes labels, and
           each summary is labeled with the meet over the read set the
           orchestrator recorded (Algorithm 1).

The authoritative layer is `live`: the records retrieval and the action check
use. Handles are content hash + counter, assigned here and never placed in a
prompt.
"""
from __future__ import annotations

import hashlib
import math
import re
from collections import Counter
from dataclasses import dataclass, field

from .labels import Level, meet

ARMS_WITH_MEMORY = ("plain", "whole", "silomem")

# Bumped when an arm's memory pipeline changes, so stale results are re-run
# (run.py) and superseded (summarize.py). silomem v2: extraction keeps one
# statement per item with all its fields, and the claims of one source record
# are never split across summarization calls.
IMPL_VERSION = {"plain": "1", "whole": "1", "silomem": "2"}


@dataclass(frozen=True)
class Record:
    handle: str
    text: str
    label: Level
    topic: str
    origins: frozenset
    kind: str            # entry | claim | summary
    round: int
    read_set: tuple = ()  # handles placed in the prompt of the call that wrote it


STOPWORDS = set("""a about above after again all am an and any are as at be because been before
being below between both but by can could did do does doing down during each few for from further
had has have having he her here hers herself him himself his how i if in into is it its itself just
me more most my myself no nor not now of off on once only or other our ours ourselves out over own
please same she should so some such than that the their theirs them themselves then there these
they this those through to too under until up very was we were what when where which while who
whom why will with would you your yours yourself yourselves""".split())


def _tok(s: str) -> list[str]:
    return [t for t in re.findall(r"[a-z0-9]+", s.lower()) if t not in STOPWORDS]


@dataclass
class MemoryStore:
    arm: str
    model: object
    bucket_cap: int = 8
    top_k: int = 3
    max_entry_chars: int = 2000
    counter: int = 0
    pending: list = field(default_factory=list)
    live: dict = field(default_factory=dict)
    archive: dict = field(default_factory=dict)
    rounds: int = 0

    def __post_init__(self) -> None:
        if self.arm not in ARMS_WITH_MEMORY:
            raise ValueError(f"no memory for arm {self.arm!r}")

    # -- handles -------------------------------------------------------
    def _new(self, text, label, topic, origins, kind, read_set=()) -> Record:
        self.counter += 1
        h = hashlib.sha1(text.encode()).hexdigest()[:10]
        r = Record(f"{h}#{self.counter}", text, Level(label), topic,
                   frozenset(origins), kind, self.rounds, tuple(read_set))
        self.archive[r.handle] = r
        return r

    def resolve(self, handle: str) -> Record | None:
        return self.archive.get(handle)

    # -- writes ----------------------------------------------------------
    def write(self, text: str, label: Level, topic: str, origin: str) -> Record:
        text = text[: self.max_entry_chars]
        r = self._new(text, label, topic, {origin}, "entry")
        self.pending.append(r)
        return r

    # -- compaction --------------------------------------------------------
    def _bucket(self, r: Record):
        return (r.topic, int(r.label)) if self.arm == "silomem" else (r.topic,)

    def compact(self) -> dict:
        """One compaction round over live records plus new entries."""
        self.rounds += 1
        new: list[Record] = []
        n_extract = 0
        if self.arm == "silomem":
            for e in self.pending:
                claims = self.model.extract(e.text)          # read set = {e}
                n_extract += 1
                if not claims:
                    claims = [e.text]
                for c in claims:
                    new.append(self._new(c, e.label, e.topic, e.origins, "claim", (e.handle,)))
        else:
            new = list(self.pending)
        self.pending = []

        items = list(self.live.values()) + new
        buckets: dict = {}
        for r in items:
            buckets.setdefault(self._bucket(r), []).append(r)

        out: dict[str, Record] = {}
        n_sum = 0
        for key in sorted(buckets, key=str):
            group = sorted(buckets[key], key=lambda r: int(r.handle.split("#")[1]))
            for chunk in self._chunks(group):
                if len(chunk) == 1 and chunk[0].kind == "summary":
                    out[chunk[0].handle] = chunk[0]
                    continue
                text = self.model.summarize([r.text for r in chunk])
                n_sum += 1
                lab = meet(r.label for r in chunk)                 # recorded read set
                origins = frozenset().union(*(r.origins for r in chunk))
                s = self._new(text, lab, chunk[0].topic, origins, "summary",
                              tuple(r.handle for r in chunk))
                out[s.handle] = s
        self.live = out
        return {"round": self.rounds, "extract_calls": n_extract, "summarize_calls": n_sum,
                "live": len(out), "live_U": sum(r.label == Level.U for r in out.values())}

    def _chunks(self, group: list[Record]):
        """Split one bucket into summarization calls.

        plain/whole: at most bucket_cap records per call (records are whole entries).
        silomem: the claims extracted from one source record stay together, and
        calls are capped by the same total length a plain/whole call can reach
        (bucket_cap entries of max_entry_chars), so no call sees more text than
        the baselines and no record's claims are scattered over several calls.
        """
        if self.arm != "silomem":
            for i in range(0, len(group), self.bucket_cap):
                yield group[i:i + self.bucket_cap]
            return
        units: list[list[Record]] = []
        by_src: dict[str, list[Record]] = {}
        for r in group:
            src = r.read_set[0] if (r.kind == "claim" and r.read_set) else r.handle
            if src not in by_src:
                by_src[src] = []
                units.append(by_src[src])
            by_src[src].append(r)
        budget = self.bucket_cap * self.max_entry_chars
        cur: list[Record] = []
        size = 0
        for u in units:
            usize = sum(len(r.text) for r in u)
            if cur and size + usize > budget:
                yield cur
                cur, size = [], 0
            if usize > budget:                      # one huge record: split it alone
                part, psize = [], 0
                for r in u:
                    if part and psize + len(r.text) > budget:
                        yield part
                        part, psize = [], 0
                    part.append(r)
                    psize += len(r.text)
                cur, size = part, psize
                continue
            cur += u
            size += usize
        if cur:
            yield cur

    # -- retrieval -----------------------------------------------------------
    def search(self, query: str) -> list[Record]:
        """Deterministic BM25 over the live layer. No model, no learned index."""
        docs = list(self.live.values())
        if not docs:
            return []
        q = _tok(query)
        toks = [_tok(d.text) for d in docs]
        n = len(docs)
        avg = sum(map(len, toks)) / n or 1.0
        df = Counter(t for ts in toks for t in set(ts))
        scored = []
        for d, ts in zip(docs, toks):
            tf = Counter(ts)
            s = 0.0
            for t in set(q):
                if t in tf:
                    idf = math.log(1 + (n - df[t] + 0.5) / (df[t] + 0.5))
                    s += idf * tf[t] * 2.2 / (tf[t] + 1.2 * (0.25 + 0.75 * len(ts) / avg))
            if s > 0:
                scored.append((-s, int(d.handle.split("#")[1]), d))
        scored.sort(key=lambda x: (x[0], x[1]))
        return [d for _, _, d in scored[: self.top_k]]

    def all_live(self) -> list[Record]:
        return sorted(self.live.values(), key=lambda r: int(r.handle.split("#")[1]))

    def stats(self) -> dict:
        live = list(self.live.values())
        return {"live": len(live), "live_U": sum(r.label == Level.U for r in live),
                "rounds": self.rounds}
