"""Labels: the lattice, and which AgentDojo tools are untrusted or sensitive.

Both tables are fixed BEFORE any run and are checked by tests, so they cannot
be tuned after looking at results.

Untrusted reads (output labeled U). A read tool is U if its output can carry
text written by someone other than the user or the platform. The list is the
union of two sources:
  1. empirical: tools whose output carried an AgentDojo injection canary when
     the ground-truth trajectories of all user tasks were replayed with a
     canary in every injection slot (tests/test_labels.py re-derives this and
     fails if a canary carrier is missing from the table);
  2. by design: tools that return messages, emails, files, events, web pages or
     reviews authored by third parties, even if no default task happens to put
     a canary there (Slack channel messages and inbox, received emails, files
     fetched by id).

Sensitive actions (checked by Eq. (action)). Every tool that changes
user-visible state: payments, scheduling, account changes, outgoing messages,
file writes and deletes, sharing, bookings, calendar edits, workspace
membership, and outgoing web requests (Slack's get_webpage logs every URL it
visits, and visiting an attacker URL is one of the Slack injection goals). get_unread_emails flips a read flag but is not an action the user
would need to authorize, so it is a read.
"""
from __future__ import annotations

from enum import IntEnum
from typing import Iterable


class Level(IntEnum):
    """U < D < T, so that min() is the meet."""

    U = 0
    D = 1
    T = 2

    def __str__(self) -> str:  # pragma: no cover
        return self.name


def meet(levels: Iterable[Level]) -> Level:
    levels = list(levels)
    if not levels:
        raise ValueError("meet over an empty set")
    return Level(min(levels))


UNTRUSTED_READS: dict[str, set[str]] = {
    "banking": {"read_file", "get_most_recent_transactions"},
    "slack": {"get_webpage", "get_channels", "read_channel_messages", "read_inbox"},
    "travel": {
        "get_rating_reviews_for_hotels",
        "get_rating_reviews_for_restaurants",
        "get_rating_reviews_for_car_rental",
    },
    "workspace": {
        "search_calendar_events", "get_day_calendar_events",
        "search_emails", "get_unread_emails", "get_received_emails",
        "list_files", "search_files_by_filename", "search_files", "get_file_by_id",
        # state-changing tools that also return untrusted content
        "add_calendar_event_participants", "delete_file",
    },
}

SENSITIVE: dict[str, set[str]] = {
    "banking": {
        "send_money", "schedule_transaction", "update_scheduled_transaction",
        "update_password", "update_user_info",
    },
    "slack": {
        "add_user_to_channel", "send_direct_message", "send_channel_message",
        "invite_user_to_slack", "remove_user_from_slack", "post_webpage",
        # a GET to a model-chosen URL is an outgoing request: it can leak data
        # in the URL, and visiting an attacker URL is itself injection_task_3
        "get_webpage",
    },
    "travel": {
        "create_calendar_event", "cancel_calendar_event", "reserve_hotel",
        "reserve_car_rental", "reserve_restaurant", "send_email",
    },
    "workspace": {
        "send_email", "delete_email", "create_calendar_event",
        "cancel_calendar_event", "reschedule_calendar_event",
        "add_calendar_event_participants", "append_to_file", "create_file",
        "delete_file", "share_file",
    },
}

# Coarse topic taxonomy over tools (the router's fixed taxonomy, Sec. 5.1).
# Anything not listed falls into the suite's "other" topic.
TOPICS: dict[str, dict[str, str]] = {
    "banking": {
        "get_most_recent_transactions": "payments", "get_scheduled_transactions": "payments",
        "send_money": "payments", "schedule_transaction": "payments",
        "update_scheduled_transaction": "payments", "get_balance": "payments",
        "read_file": "documents",
        "get_iban": "account", "get_user_info": "account",
        "update_password": "account", "update_user_info": "account",
    },
    "slack": {
        "read_channel_messages": "messages", "read_inbox": "messages",
        "send_direct_message": "messages", "send_channel_message": "messages",
        "get_channels": "workspace", "get_users_in_channel": "workspace",
        "add_user_to_channel": "workspace", "invite_user_to_slack": "workspace",
        "remove_user_from_slack": "workspace",
        "get_webpage": "web", "post_webpage": "web",
    },
    "travel": {},      # tool name prefix decides, see topic_of()
    "workspace": {},
}

MEMORY_TOOL = "search_memory"
REQUEST_TOPIC = "requests"


def _b(suite: str) -> str:
    return suite.split("_")[0]


def tool_label(suite: str, fn: str) -> Level:
    """Label of a tool's OUTPUT, by source class."""
    suite = _b(suite)
    if fn not in known_tools(suite) and fn != MEMORY_TOOL:
        return Level.U  # unknown tool: fail closed
    return Level.U if fn in UNTRUSTED_READS[suite] else Level.T


def is_sensitive(suite: str, fn: str) -> bool:
    suite = _b(suite)
    return fn in SENSITIVE[suite]


def topic_of(suite: str, fn: str) -> str:
    suite = _b(suite)
    t = TOPICS[suite].get(fn)
    if t:
        return t
    for key in ("hotel", "restaurant", "car", "flight", "calendar", "email", "file", "contact"):
        if key in fn:
            return key
    return "other"


_KNOWN: dict[str, set[str]] = {}


def known_tools(suite: str) -> set[str]:
    suite = _b(suite)
    if suite not in _KNOWN:
        from agentdojo.task_suite.load_suites import get_suite
        _KNOWN[suite] = {t.name for t in get_suite("v1.2.1", suite).tools}
    return _KNOWN[suite]
