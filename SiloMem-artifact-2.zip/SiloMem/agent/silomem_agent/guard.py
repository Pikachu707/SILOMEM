"""The orchestrator side of one session: it records the read set and enforces
the action check (Eq. (action)).

Everything the model sees enters the context through this module or through
the system/user message it builds, so the recorded read set is exactly the
context. The model cannot add to it or remove from it: tool outputs are
recorded when they are executed, memory notes when they are retrieved, and no
handle ever appears in text the model sees.
"""
from __future__ import annotations

from ast import literal_eval
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field

from agentdojo.agent_pipeline.base_pipeline_element import BasePipelineElement
from agentdojo.agent_pipeline.tool_execution import is_string_list, tool_result_to_str
from agentdojo.functions_runtime import EmptyEnv, Env, FunctionsRuntime, make_function
from agentdojo.types import ChatMessage, ChatToolResultMessage, text_content_block_from_string

from .labels import MEMORY_TOOL, Level, is_sensitive, meet, tool_label, topic_of
from .memory import MemoryStore
from .models import Usage

REFUSAL = ("Blocked by the memory provenance policy: this session's context contains "
           "content from an untrusted source, so this action needs the user's direct "
           "confirmation. Tell the user what you wanted to do and why.")


def search_memory(query: str) -> str:
    """Search your long-term memory of earlier sessions with this user and return the most relevant notes.

    :param query: what to look for, in a few words
    """
    return ""  # executed by SessionGuard, never by the runtime


SEARCH_MEMORY_FN = make_function(search_memory)


@dataclass
class Observation:
    fn: str
    args: dict
    output: str
    label: Level
    topic: str
    error: str | None


@dataclass
class SessionState:
    suite: str
    arm: str
    store: MemoryStore | None
    guard_on: bool
    on_refuse: str = "deny"                     # deny | confirm
    approve: Callable[[str, dict], bool] | None = None
    # recorded read set: handle -> label for session-local items; memory
    # records are resolved through the store at action time
    local: dict = field(default_factory=dict)
    read_set: list = field(default_factory=list)
    observations: list = field(default_factory=list)
    refusals: list = field(default_factory=list)
    approvals: list = field(default_factory=list)
    memory_reads: list = field(default_factory=list)
    n_local: int = 0
    agent_usage: Usage = field(default_factory=Usage)

    def add_local(self, label: Level, what: str) -> str:
        self.n_local += 1
        h = f"ctx:{what}#{self.n_local}"
        self.local[h] = Level(label)
        self.read_set.append(h)
        return h

    def add_memory(self, handle: str) -> None:
        self.read_set.append(handle)
        self.memory_reads.append(handle)

    def resolve(self, h: str) -> Level | None:
        if h in self.local:
            return self.local[h]
        if self.store is not None:
            r = self.store.resolve(h)
            if r is not None:
                return r.label
        return None

    def context_label(self) -> Level | None:
        """Meet over the recorded read set; None if any handle is unresolvable."""
        labs = []
        for h in self.read_set:
            lab = self.resolve(h)
            if lab is None:
                return None
            labs.append(lab)
        return meet(labs) if labs else Level.T


class SessionGuard(BasePipelineElement):
    """Drop-in replacement for AgentDojo's ToolsExecutor."""

    name = "silomem_guard"

    def query(self, query: str, runtime: FunctionsRuntime, env: Env = EmptyEnv(),
              messages: Sequence[ChatMessage] = [], extra_args: dict = {}):
        if not messages or messages[-1]["role"] != "assistant" or not messages[-1]["tool_calls"]:
            return query, runtime, env, messages, extra_args
        st: SessionState = extra_args["state"]
        results = []
        for call in messages[-1]["tool_calls"]:
            fn = call.function
            for k, v in list(call.args.items()):
                if isinstance(v, str) and is_string_list(v):
                    call.args[k] = literal_eval(v)

            def reply(text: str, error: str | None = None):
                results.append(ChatToolResultMessage(
                    role="tool", content=[text_content_block_from_string(text)],
                    tool_call_id=call.id, tool_call=call, error=error))

            if fn == MEMORY_TOOL and st.store is not None:
                recs = st.store.search(str(call.args.get("query", "")))
                for r in recs:
                    st.add_memory(r.handle)
                reply("\n".join(f"- {r.text}" for r in recs) if recs else "No relevant notes.")
                continue
            if fn not in runtime.functions:
                reply("", f"Invalid tool {fn} provided.")
                continue

            ctx = st.context_label()
            if st.guard_on and is_sensitive(st.suite, fn) and ctx is not Level.T:
                legit = st.on_refuse == "confirm" and st.approve is not None and st.approve(fn, dict(call.args))
                if legit:
                    st.approvals.append({"fn": fn, "args": _jsonable(call.args)})
                else:
                    st.refusals.append({"fn": fn, "args": _jsonable(call.args),
                                        "context": None if ctx is None else ctx.name})
                    reply("", REFUSAL)
                    continue

            out, err = runtime.run_function(env, fn, call.args)
            text = tool_result_to_str(out)
            lab = tool_label(st.suite, fn)
            if call.args:                      # arguments were chosen by the model
                lab = meet([lab, ctx if ctx is not None else Level.U])
            st.add_local(lab, fn)
            st.observations.append(Observation(fn, _jsonable(call.args), text, lab,
                                               topic_of(st.suite, fn), err))
            reply(text, err)
        return query, runtime, env, [*messages, *results], extra_args


def _jsonable(d: dict) -> dict:
    out = {}
    for k, v in d.items():
        out[k] = v if isinstance(v, (str, int, float, bool, type(None), list, dict)) else str(v)
    return out
