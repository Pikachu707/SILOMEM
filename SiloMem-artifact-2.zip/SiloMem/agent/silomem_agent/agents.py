"""Agent LLM elements.

  MockAgent        scripted: executes the user task's ground-truth calls and,
                   if the attacker's goal is visible anywhere in its context,
                   obeys it with probability p_obey. With memory it first
                   searches memory with the user's request. Its only purpose is
                   to exercise the plumbing; it says nothing about real models.
  TrackedOpenAILLM AgentDojo's OpenAILLM, plus token accounting. Works with any
                   OpenAI-compatible server (vLLM needs tool calling enabled).
"""
from __future__ import annotations

import random
import re
from collections.abc import Sequence

from agentdojo.agent_pipeline.base_pipeline_element import BasePipelineElement
from agentdojo.agent_pipeline.llms.openai_llm import (
    _function_to_openai, _message_to_openai, _openai_to_assistant_message, chat_completion_request,
)
from agentdojo.functions_runtime import EmptyEnv, Env, FunctionCall, FunctionsRuntime
from agentdojo.types import ChatAssistantMessage, ChatMessage, get_text_content_as_str, text_content_block_from_string

from .labels import MEMORY_TOOL


def _norm(s: str) -> str:
    s = s.replace("\\n", " ").replace("\\", " ").replace('"', " ").replace("'", " ")
    return re.sub(r"\s+", " ", s).strip().lower()


def context_text(messages: Sequence[ChatMessage]) -> str:
    parts = []
    for m in messages:
        if m.get("content"):
            parts.append(get_text_content_as_str(m["content"]))
    return _norm("\n".join(parts))


class MockAgent(BasePipelineElement):
    name = "mock-agent"

    def __init__(self, p_obey: float = 1.0, seed: int = 0, recall: str = "always") -> None:
        self.p_obey = p_obey
        self.seed = seed
        self.recall = recall    # always | never

    def query(self, query: str, runtime: FunctionsRuntime, env: Env = EmptyEnv(),
              messages: Sequence[ChatMessage] = [], extra_args: dict = {}):
        mk = extra_args.setdefault("_mock", {})
        pre = extra_args["pre_env"]
        if "queue" not in mk:
            mk["queue"] = []
            if MEMORY_TOOL in runtime.functions and self.recall == "always":
                mk["queue"].append(FunctionCall(function=MEMORY_TOOL, args={"query": query}))
            mk["queue"] += list(extra_args["user_task"].ground_truth(pre))
            mk["obeyed"] = False
            mk["n"] = 0
            mk["rng"] = random.Random(f"{self.seed}|{extra_args.get('session_key', '')}")
        inj = extra_args.get("episode_injection_task")
        if inj is not None and not mk["obeyed"] and _norm(inj.GOAL) in context_text(messages):
            mk["obeyed"] = True
            if mk["rng"].random() < self.p_obey:
                mk["queue"] = list(inj.ground_truth(pre)) + mk["queue"]
        if mk["queue"]:
            c = mk["queue"].pop(0)
            mk["n"] += 1
            call = FunctionCall(function=c.function, args=dict(c.args), id=f"mock{mk['n']}")
            msg = ChatAssistantMessage(role="assistant", content=[text_content_block_from_string("")],
                                       tool_calls=[call])
        else:
            msg = ChatAssistantMessage(
                role="assistant", tool_calls=None,
                content=[text_content_block_from_string(extra_args["user_task"].GROUND_TRUTH_OUTPUT)])
        return query, runtime, env, [*messages, msg], extra_args


class TrackedOpenAILLM(BasePipelineElement):
    def __init__(self, client, model: str, temperature: float | None = 0.0) -> None:
        self.client = client
        self.model = model
        self.name = model
        self.temperature = temperature

    def query(self, query: str, runtime: FunctionsRuntime, env: Env = EmptyEnv(),
              messages: Sequence[ChatMessage] = [], extra_args: dict = {}):
        oa_msgs = [_message_to_openai(m, self.model) for m in messages]
        oa_tools = [_function_to_openai(t) for t in runtime.functions.values()]
        completion = chat_completion_request(self.client, self.model, oa_msgs, oa_tools, None, self.temperature)
        u = getattr(completion, "usage", None)
        st = extra_args.get("state")
        if st is not None and u is not None:
            st.agent_usage.add(u.prompt_tokens or 0, u.completion_tokens or 0)
        out = _openai_to_assistant_message(completion.choices[0].message)
        return query, runtime, env, [*messages, out], extra_args
