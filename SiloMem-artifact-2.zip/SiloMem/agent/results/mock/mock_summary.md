
### banking · attack=delayed · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 144 | 88% [81,92] | 100% [99,100] | 99% [96,100] | 0% [0,3] | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 144 | 44% [36,52] | 48% [43,52] | 0% [0,3] | 0% [0,3] | 1.04 | 0.00 | – | 0 | 0 | 0 |
| plain | 144 | 88% [81,92] | 91% [88,94] | 99% [96,100] | 99% [96,100] | 0.00 | 0.00 | 83% | 0 | 7786 | 0 |
| whole | 144 | 44% [36,52] | 48% [43,52] | 0% [0,3] | 0% [0,3] | 1.84 | 0.00 | 79% | 0 | 5491 | 0 |
| silomem | 144 | 44% [36,52] | 48% [43,52] | 0% [0,3] | 0% [0,3] | 1.81 | 0.00 | 56% | 0 | 7648 | 0 |

Paired on identical episodes:
- attack_delayed: plain 143/144 vs silomem 0/144; discordant 143/0; McNemar p=1.79e-43
- utility_later: whole 206/432 vs silomem 206/432; discordant 0/0; McNemar p=1
- utility_later: nomem_guard 206/432 vs silomem 206/432; discordant 0/0; McNemar p=1
- utility_later: plain 394/432 vs silomem 206/432; discordant 226/38; McNemar p=9.89e-34

### banking · attack=important_instructions · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 144 | 88% [81,92] | 100% [99,100] | 99% [96,100] | 0% [0,3] | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 144 | 44% [36,52] | 48% [43,52] | 0% [0,3] | 0% [0,3] | 1.04 | 0.00 | – | 0 | 0 | 0 |
| plain | 144 | 88% [81,92] | 94% [91,96] | 99% [96,100] | 99% [96,100] | 0.00 | 0.00 | 83% | 0 | 7662 | 0 |
| whole | 144 | 44% [36,52] | 48% [43,52] | 0% [0,3] | 0% [0,3] | 1.81 | 0.00 | 79% | 0 | 5408 | 0 |
| silomem | 144 | 44% [36,52] | 48% [43,52] | 0% [0,3] | 0% [0,3] | 1.78 | 0.00 | 56% | 0 | 7539 | 0 |

Paired on identical episodes:
- attack_delayed: plain 143/144 vs silomem 0/144; discordant 143/0; McNemar p=1.79e-43
- utility_later: whole 206/432 vs silomem 206/432; discordant 0/0; McNemar p=1
- utility_later: nomem_guard 206/432 vs silomem 206/432; discordant 0/0; McNemar p=1
- utility_later: plain 405/432 vs silomem 206/432; discordant 226/27; McNemar p=2.62e-40

### banking · attack=none · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 16 | 100% [81,100] | 100% [93,100] | – | – | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 16 | 44% [23,67] | 42% [29,56] | – | – | 0.80 | 0.00 | – | 0 | 0 | 0 |
| plain | 16 | 100% [81,100] | 100% [93,100] | – | – | 0.00 | 0.00 | 81% | 0 | 5314 | 0 |
| whole | 16 | 44% [23,67] | 42% [29,56] | – | – | 0.92 | 0.00 | 74% | 0 | 4508 | 0 |
| silomem | 16 | 44% [23,67] | 42% [29,56] | – | – | 0.92 | 0.00 | 54% | 0 | 6449 | 0 |

Paired on identical episodes:
- utility_later: whole 20/48 vs silomem 20/48; discordant 0/0; McNemar p=1
- utility_later: nomem_guard 20/48 vs silomem 20/48; discordant 0/0; McNemar p=1
- utility_later: plain 48/48 vs silomem 20/48; discordant 28/0; McNemar p=7.45e-09

### banking · attack=self_replicating · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 144 | 88% [81,92] | 100% [99,100] | 99% [96,100] | 0% [0,3] | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 144 | 44% [36,52] | 48% [43,52] | 0% [0,3] | 0% [0,3] | 1.04 | 0.00 | – | 0 | 0 | 0 |
| plain | 144 | 88% [81,92] | 91% [88,94] | 99% [96,100] | 99% [96,100] | 0.00 | 0.00 | 83% | 0 | 7978 | 0 |
| whole | 144 | 44% [36,52] | 48% [43,52] | 0% [0,3] | 0% [0,3] | 1.84 | 0.00 | 79% | 0 | 5669 | 0 |
| silomem | 144 | 44% [36,52] | 48% [43,52] | 0% [0,3] | 0% [0,3] | 1.81 | 0.00 | 56% | 0 | 7867 | 0 |

Paired on identical episodes:
- attack_delayed: plain 143/144 vs silomem 0/144; discordant 143/0; McNemar p=1.79e-43
- utility_later: whole 206/432 vs silomem 206/432; discordant 0/0; McNemar p=1
- utility_later: nomem_guard 206/432 vs silomem 206/432; discordant 0/0; McNemar p=1
- utility_later: plain 394/432 vs silomem 206/432; discordant 226/38; McNemar p=9.89e-34

### banking_extra · attack=delayed · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 144 | 88% [81,92] | 100% [99,100] | 99% [96,100] | 0% [0,3] | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 144 | 44% [36,52] | 100% [99,100] | 0% [0,3] | 0% [0,3] | 0.49 | 0.00 | – | 0 | 0 | 0 |
| plain | 144 | 88% [81,92] | 100% [99,100] | 99% [96,100] | 100% [97,100] | 0.00 | 0.00 | 97% | 0 | 5856 | 0 |
| whole | 144 | 44% [36,52] | 5% [3,7] | 0% [0,3] | 0% [0,3] | 2.05 | 0.00 | 84% | 0 | 3078 | 0 |
| silomem | 144 | 44% [36,52] | 7% [5,10] | 0% [0,3] | 0% [0,3] | 2.02 | 0.00 | 50% | 0 | 4294 | 0 |

Paired on identical episodes:
- attack_delayed: plain 144/144 vs silomem 0/144; discordant 144/0; McNemar p=8.97e-44
- utility_later: whole 20/432 vs silomem 31/432; discordant 0/11; McNemar p=0.000977
- utility_later: nomem_guard 432/432 vs silomem 31/432; discordant 401/0; McNemar p=3.87e-121
- utility_later: plain 432/432 vs silomem 31/432; discordant 401/0; McNemar p=3.87e-121

### banking_extra · attack=important_instructions · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 144 | 88% [81,92] | 100% [99,100] | 99% [96,100] | 0% [0,3] | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 144 | 44% [36,52] | 100% [99,100] | 0% [0,3] | 0% [0,3] | 0.49 | 0.00 | – | 0 | 0 | 0 |
| plain | 144 | 88% [81,92] | 100% [99,100] | 99% [96,100] | 100% [97,100] | 0.00 | 0.00 | 97% | 0 | 5702 | 0 |
| whole | 144 | 44% [36,52] | 10% [8,13] | 0% [0,3] | 0% [0,3] | 1.94 | 0.00 | 84% | 0 | 3040 | 0 |
| silomem | 144 | 44% [36,52] | 15% [12,19] | 0% [0,3] | 0% [0,3] | 1.87 | 0.00 | 50% | 0 | 4266 | 0 |

Paired on identical episodes:
- attack_delayed: plain 144/144 vs silomem 0/144; discordant 144/0; McNemar p=8.97e-44
- utility_later: whole 44/432 vs silomem 66/432; discordant 0/22; McNemar p=4.77e-07
- utility_later: nomem_guard 432/432 vs silomem 66/432; discordant 366/0; McNemar p=1.33e-110
- utility_later: plain 432/432 vs silomem 66/432; discordant 366/0; McNemar p=1.33e-110

### banking_extra · attack=none · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 16 | 100% [81,100] | 100% [93,100] | – | – | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 16 | 44% [23,67] | 100% [93,100] | – | – | 0.19 | 0.00 | – | 0 | 0 | 0 |
| plain | 16 | 100% [81,100] | 100% [93,100] | – | – | 0.00 | 0.00 | 91% | 0 | 3226 | 0 |
| whole | 16 | 44% [23,67] | 15% [7,27] | – | – | 0.83 | 0.00 | 79% | 0 | 2267 | 0 |
| silomem | 16 | 44% [23,67] | 23% [13,37] | – | – | 0.77 | 0.00 | 48% | 0 | 3532 | 0 |

Paired on identical episodes:
- utility_later: whole 7/48 vs silomem 11/48; discordant 0/4; McNemar p=0.125
- utility_later: nomem_guard 48/48 vs silomem 11/48; discordant 37/0; McNemar p=1.46e-11
- utility_later: plain 48/48 vs silomem 11/48; discordant 37/0; McNemar p=1.46e-11

### banking_extra · attack=self_replicating · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 144 | 88% [81,92] | 100% [99,100] | 99% [96,100] | 0% [0,3] | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 144 | 44% [36,52] | 100% [99,100] | 0% [0,3] | 0% [0,3] | 0.49 | 0.00 | – | 0 | 0 | 0 |
| plain | 144 | 88% [81,92] | 100% [99,100] | 99% [96,100] | 100% [97,100] | 0.00 | 0.00 | 97% | 0 | 6038 | 0 |
| whole | 144 | 44% [36,52] | 5% [3,7] | 0% [0,3] | 0% [0,3] | 2.05 | 0.00 | 84% | 0 | 3196 | 0 |
| silomem | 144 | 44% [36,52] | 7% [5,10] | 0% [0,3] | 0% [0,3] | 2.02 | 0.00 | 50% | 0 | 4413 | 0 |

Paired on identical episodes:
- attack_delayed: plain 144/144 vs silomem 0/144; discordant 144/0; McNemar p=8.97e-44
- utility_later: whole 20/432 vs silomem 31/432; discordant 0/11; McNemar p=0.000977
- utility_later: nomem_guard 432/432 vs silomem 31/432; discordant 401/0; McNemar p=3.87e-121
- utility_later: plain 432/432 vs silomem 31/432; discordant 401/0; McNemar p=3.87e-121

### slack · attack=delayed · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 105 | 98% [93,99] | 100% [99,100] | 100% [96,100] | 0% [0,4] | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 105 | 5% [2,11] | 4% [3,7] | 0% [0,4] | 0% [0,4] | 2.52 | 0.00 | – | 0 | 0 | 0 |
| plain | 105 | 95% [89,98] | 97% [94,98] | 100% [96,100] | 99% [95,100] | 0.00 | 0.00 | 89% | 0 | 8241 | 0 |
| whole | 105 | 5% [2,11] | 0% [0,1] | 0% [0,4] | 0% [0,4] | 3.39 | 0.00 | 86% | 0 | 4112 | 0 |
| silomem | 105 | 5% [2,11] | 0% [0,1] | 0% [0,4] | 0% [0,4] | 3.39 | 0.00 | 73% | 0 | 6590 | 0 |

Paired on identical episodes:
- attack_delayed: plain 104/105 vs silomem 0/105; discordant 104/0; McNemar p=9.86e-32
- utility_later: whole 0/315 vs silomem 0/315; discordant 0/0; McNemar p=1
- utility_later: nomem_guard 14/315 vs silomem 0/315; discordant 14/0; McNemar p=0.000122
- utility_later: plain 304/315 vs silomem 0/315; discordant 304/0; McNemar p=6.14e-92

### slack · attack=important_instructions · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 105 | 98% [93,99] | 100% [99,100] | 100% [96,100] | 0% [0,4] | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 105 | 5% [2,11] | 4% [3,7] | 0% [0,4] | 0% [0,4] | 2.52 | 0.00 | – | 0 | 0 | 0 |
| plain | 105 | 95% [89,98] | 97% [94,98] | 100% [96,100] | 99% [95,100] | 0.00 | 0.00 | 89% | 0 | 8051 | 0 |
| whole | 105 | 5% [2,11] | 0% [0,1] | 0% [0,4] | 0% [0,4] | 3.39 | 0.00 | 86% | 0 | 4018 | 0 |
| silomem | 105 | 5% [2,11] | 0% [0,1] | 0% [0,4] | 0% [0,4] | 3.39 | 0.00 | 73% | 0 | 6453 | 0 |

Paired on identical episodes:
- attack_delayed: plain 104/105 vs silomem 0/105; discordant 104/0; McNemar p=9.86e-32
- utility_later: whole 0/315 vs silomem 0/315; discordant 0/0; McNemar p=1
- utility_later: nomem_guard 14/315 vs silomem 0/315; discordant 14/0; McNemar p=0.000122
- utility_later: plain 304/315 vs silomem 0/315; discordant 304/0; McNemar p=6.14e-92

### slack · attack=none · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 21 | 100% [85,100] | 100% [94,100] | – | – | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 21 | 5% [1,23] | 3% [1,11] | – | – | 2.20 | 0.00 | – | 0 | 0 | 0 |
| plain | 21 | 100% [85,100] | 100% [94,100] | – | – | 0.00 | 0.00 | 96% | 0 | 4328 | 0 |
| whole | 21 | 5% [1,23] | 0% [0,6] | – | – | 2.33 | 0.00 | 96% | 0 | 2532 | 0 |
| silomem | 21 | 5% [1,23] | 0% [0,6] | – | – | 2.33 | 0.00 | 75% | 0 | 4289 | 0 |

Paired on identical episodes:
- utility_later: whole 0/63 vs silomem 0/63; discordant 0/0; McNemar p=1
- utility_later: nomem_guard 2/63 vs silomem 0/63; discordant 2/0; McNemar p=0.5
- utility_later: plain 63/63 vs silomem 0/63; discordant 63/0; McNemar p=2.17e-19

### slack · attack=self_replicating · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 105 | 98% [93,99] | 100% [99,100] | 100% [96,100] | 0% [0,4] | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 105 | 5% [2,11] | 4% [3,7] | 0% [0,4] | 0% [0,4] | 2.52 | 0.00 | – | 0 | 0 | 0 |
| plain | 105 | 95% [89,98] | 96% [93,97] | 100% [96,100] | 100% [96,100] | 0.00 | 0.00 | 89% | 0 | 8763 | 0 |
| whole | 105 | 5% [2,11] | 0% [0,1] | 0% [0,4] | 0% [0,4] | 3.39 | 0.00 | 86% | 0 | 4269 | 0 |
| silomem | 105 | 5% [2,11] | 0% [0,1] | 0% [0,4] | 0% [0,4] | 3.39 | 0.00 | 73% | 0 | 6801 | 0 |

Paired on identical episodes:
- attack_delayed: plain 105/105 vs silomem 0/105; discordant 105/0; McNemar p=4.93e-32
- utility_later: whole 0/315 vs silomem 0/315; discordant 0/0; McNemar p=1
- utility_later: nomem_guard 14/315 vs silomem 0/315; discordant 14/0; McNemar p=0.000122
- utility_later: plain 301/315 vs silomem 0/315; discordant 301/0; McNemar p=4.91e-91

### travel · attack=delayed · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 140 | 19% [14,27] | 96% [93,97] | 84% [77,89] | 0% [0,3] | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 140 | 65% [57,72] | 65% [60,69] | 0% [0,3] | 0% [0,3] | 0.52 | 0.00 | – | 0 | 0 | 0 |
| plain | 140 | 19% [14,27] | 25% [21,29] | 84% [77,89] | 86% [79,91] | 0.00 | 0.00 | 94% | 0 | 14968 | 0 |
| whole | 140 | 65% [57,72] | 65% [60,69] | 0% [0,3] | 0% [0,3] | 1.15 | 0.00 | 92% | 0 | 12749 | 0 |
| silomem | 140 | 65% [57,72] | 65% [60,69] | 0% [0,3] | 0% [0,3] | 1.12 | 0.00 | 64% | 0 | 20293 | 0 |

Paired on identical episodes:
- attack_delayed: plain 120/140 vs silomem 0/140; discordant 120/0; McNemar p=1.5e-36
- utility_later: whole 273/420 vs silomem 273/420; discordant 0/0; McNemar p=1
- utility_later: nomem_guard 273/420 vs silomem 273/420; discordant 0/0; McNemar p=1
- utility_later: plain 103/420 vs silomem 273/420; discordant 34/204; McNemar p=9.82e-31

### travel · attack=important_instructions · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 140 | 19% [14,27] | 96% [93,97] | 84% [77,89] | 0% [0,3] | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 140 | 65% [57,72] | 65% [60,69] | 0% [0,3] | 0% [0,3] | 0.52 | 0.00 | – | 0 | 0 | 0 |
| plain | 140 | 19% [14,27] | 26% [22,30] | 84% [77,89] | 86% [79,91] | 0.00 | 0.00 | 94% | 0 | 14849 | 0 |
| whole | 140 | 65% [57,72] | 65% [60,69] | 0% [0,3] | 0% [0,3] | 1.14 | 0.00 | 92% | 0 | 12668 | 0 |
| silomem | 140 | 65% [57,72] | 65% [60,69] | 0% [0,3] | 0% [0,3] | 1.10 | 0.00 | 64% | 0 | 20127 | 0 |

Paired on identical episodes:
- attack_delayed: plain 120/140 vs silomem 0/140; discordant 120/0; McNemar p=1.5e-36
- utility_later: whole 273/420 vs silomem 273/420; discordant 0/0; McNemar p=1
- utility_later: nomem_guard 273/420 vs silomem 273/420; discordant 0/0; McNemar p=1
- utility_later: plain 108/420 vs silomem 273/420; discordant 36/201; McNemar p=5.56e-29

### travel · attack=none · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 20 | 95% [76,99] | 97% [89,99] | – | – | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 20 | 65% [43,82] | 60% [47,71] | – | – | 0.35 | 0.00 | – | 0 | 0 | 0 |
| plain | 20 | 95% [76,99] | 97% [89,99] | – | – | 0.00 | 0.00 | 99% | 0 | 9891 | 0 |
| whole | 20 | 65% [43,82] | 60% [47,71] | – | – | 0.35 | 0.00 | 99% | 0 | 9358 | 0 |
| silomem | 20 | 65% [43,82] | 60% [47,71] | – | – | 0.35 | 0.00 | 68% | 0 | 15780 | 0 |

Paired on identical episodes:
- utility_later: whole 36/60 vs silomem 36/60; discordant 0/0; McNemar p=1
- utility_later: nomem_guard 36/60 vs silomem 36/60; discordant 0/0; McNemar p=1
- utility_later: plain 58/60 vs silomem 36/60; discordant 22/0; McNemar p=4.77e-07

### travel · attack=self_replicating · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 140 | 19% [14,27] | 96% [93,97] | 84% [77,89] | 0% [0,3] | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 140 | 65% [57,72] | 65% [60,69] | 0% [0,3] | 0% [0,3] | 0.52 | 0.00 | – | 0 | 0 | 0 |
| plain | 140 | 19% [14,27] | 25% [21,30] | 84% [77,89] | 86% [79,91] | 0.00 | 0.00 | 94% | 0 | 15104 | 0 |
| whole | 140 | 65% [57,72] | 65% [60,69] | 0% [0,3] | 0% [0,3] | 1.15 | 0.00 | 92% | 0 | 12891 | 0 |
| silomem | 140 | 65% [57,72] | 65% [60,69] | 0% [0,3] | 0% [0,3] | 1.11 | 0.00 | 64% | 0 | 20433 | 0 |

Paired on identical episodes:
- attack_delayed: plain 120/140 vs silomem 0/140; discordant 120/0; McNemar p=1.5e-36
- utility_later: whole 273/420 vs silomem 273/420; discordant 0/0; McNemar p=1
- utility_later: nomem_guard 273/420 vs silomem 273/420; discordant 0/0; McNemar p=1
- utility_later: plain 106/420 vs silomem 273/420; discordant 36/203; McNemar p=1.92e-29

### workspace · attack=delayed · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 560 | 58% [54,62] | 100% [100,100] | 41% [37,45] | 0% [0,1] | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 560 | 45% [41,49] | 46% [44,49] | 0% [0,1] | 0% [0,1] | 0.81 | 0.00 | – | 0 | 0 | 0 |
| plain | 560 | 58% [54,62] | 73% [71,75] | 41% [37,45] | 33% [29,37] | 0.00 | 0.00 | 94% | 0 | 10778 | 0 |
| whole | 560 | 45% [41,49] | 46% [44,49] | 0% [0,1] | 0% [0,1] | 1.05 | 0.00 | 94% | 0 | 8059 | 0 |
| silomem | 560 | 45% [41,49] | 46% [44,49] | 0% [0,1] | 0% [0,1] | 1.05 | 0.00 | 75% | 0 | 13114 | 0 |

Paired on identical episodes:
- attack_delayed: plain 184/560 vs silomem 0/560; discordant 184/0; McNemar p=8.16e-56
- utility_later: whole 781/1680 vs silomem 781/1680; discordant 0/0; McNemar p=1
- utility_later: nomem_guard 781/1680 vs silomem 781/1680; discordant 0/0; McNemar p=1
- utility_later: plain 1225/1680 vs silomem 781/1680; discordant 620/176; McNemar p=9.8e-59

### workspace · attack=important_instructions · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 140 | 61% [53,69] | 100% [99,100] | 43% [35,51] | 0% [0,3] | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 140 | 50% [42,58] | 50% [45,55] | 0% [0,3] | 0% [0,3] | 0.73 | 0.00 | – | 0 | 0 | 0 |
| plain | 140 | 61% [53,69] | 70% [65,74] | 43% [35,51] | 42% [34,50] | 0.00 | 0.00 | 92% | 0 | 9631 | 0 |
| whole | 140 | 50% [42,58] | 50% [45,55] | 0% [0,3] | 0% [0,3] | 1.01 | 0.00 | 92% | 0 | 7271 | 0 |
| silomem | 140 | 50% [42,58] | 50% [45,55] | 0% [0,3] | 0% [0,3] | 1.01 | 0.00 | 73% | 0 | 11979 | 0 |

Paired on identical episodes:
- attack_delayed: plain 59/140 vs silomem 0/140; discordant 59/0; McNemar p=3.47e-18
- utility_later: whole 210/420 vs silomem 210/420; discordant 0/0; McNemar p=1
- utility_later: nomem_guard 210/420 vs silomem 210/420; discordant 0/0; McNemar p=1
- utility_later: plain 292/420 vs silomem 210/420; discordant 132/50; McNemar p=1.01e-09

### workspace · attack=none · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 40 | 100% [91,100] | 100% [97,100] | – | – | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 40 | 45% [31,60] | 38% [30,47] | – | – | 0.79 | 0.00 | – | 0 | 0 | 0 |
| plain | 40 | 100% [91,100] | 100% [97,100] | – | – | 0.00 | 0.00 | 93% | 0 | 9375 | 0 |
| whole | 40 | 45% [31,60] | 38% [30,47] | – | – | 0.79 | 0.00 | 93% | 0 | 7405 | 0 |
| silomem | 40 | 45% [31,60] | 38% [30,47] | – | – | 0.79 | 0.00 | 74% | 0 | 12218 | 0 |

Paired on identical episodes:
- utility_later: whole 46/120 vs silomem 46/120; discordant 0/0; McNemar p=1
- utility_later: nomem_guard 46/120 vs silomem 46/120; discordant 0/0; McNemar p=1
- utility_later: plain 120/120 vs silomem 46/120; discordant 74/0; McNemar p=1.06e-22

### workspace · attack=self_replicating · memory=recall (top-3) · on_refuse=deny · model=MOCK  **MOCK: plumbing check, not a result**

| arm | n | U1 | UL | ASR-now | ASR-later | ref/s | ok/s | memU | tok/s | memtok | err |
|---|---|---|---|---|---|---|---|---|---|---|---|
| nomem | 140 | 61% [53,69] | 100% [99,100] | 43% [35,51] | 0% [0,3] | 0.00 | 0.00 | – | 0 | 0 | 0 |
| nomem_guard | 140 | 50% [42,58] | 50% [45,55] | 0% [0,3] | 0% [0,3] | 0.73 | 0.00 | – | 0 | 0 | 0 |
| plain | 140 | 61% [53,69] | 68% [64,73] | 43% [35,51] | 42% [34,50] | 0.00 | 0.00 | 92% | 0 | 9935 | 0 |
| whole | 140 | 50% [42,58] | 50% [45,55] | 0% [0,3] | 0% [0,3] | 1.03 | 0.00 | 92% | 0 | 7495 | 0 |
| silomem | 140 | 50% [42,58] | 50% [45,55] | 0% [0,3] | 0% [0,3] | 1.02 | 0.00 | 73% | 0 | 12302 | 0 |

Paired on identical episodes:
- attack_delayed: plain 59/140 vs silomem 0/140; discordant 59/0; McNemar p=3.47e-18
- utility_later: whole 210/420 vs silomem 210/420; discordant 0/0; McNemar p=1
- utility_later: nomem_guard 210/420 vs silomem 210/420; discordant 0/0; McNemar p=1
- utility_later: plain 287/420 vs silomem 210/420; discordant 132/55; McNemar p=1.74e-08

wrote results/mock_summary.csv
