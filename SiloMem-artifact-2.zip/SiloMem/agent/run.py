#!/usr/bin/env python3
"""Run multi-session SiloMem episodes on AgentDojo.

Mock (no GPU, no network) -- proves the plumbing:
    python run.py --backend mock --suite banking --attack delayed --out results/mock.jsonl

Real model behind an OpenAI-compatible server (vLLM example in README):
    export OPENAI_API_KEY=local
    python run.py --backend openai --base-url http://localhost:8000/v1 \
        --model Qwen/Qwen2.5-72B-Instruct-AWQ --suite banking slack \
        --attack delayed --arms plain whole silomem nomem_guard nomem \
        --workers 8 --out results/qwen72b_delayed.jsonl

Results are appended one JSON line per (episode, arm); re-running the same
command resumes where it stopped.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import threading
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from silomem_agent.attacks import TEMPLATES  # noqa: E402
from silomem_agent.memory import IMPL_VERSION  # noqa: E402
from silomem_agent.runner import ARMS, RunConfig, build_episodes, run_episode  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--suite", nargs="+", default=["banking"],
                    choices=["banking", "slack", "travel", "workspace", "banking_extra"])
    ap.add_argument("--arms", nargs="+", default=list(ARMS), choices=list(ARMS))
    ap.add_argument("--attack", default="delayed", choices=["none", *TEMPLATES])
    ap.add_argument("--n-later", type=int, default=3, help="sessions after the first")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--limit", type=int, default=None, help="max episodes per suite")
    ap.add_argument("--user-tasks", nargs="*", default=None)
    ap.add_argument("--injection-tasks", nargs="*", default=None)
    ap.add_argument("--memory-mode", default="recall", choices=["recall", "preload", "auto"],
                    help="recall: agent calls search_memory; preload: all notes in context (MemGPT); "
                         "auto: orchestrator puts the top-k notes for the request in context (mem0)")
    ap.add_argument("--on-refuse", default="deny", choices=["deny", "confirm"])
    ap.add_argument("--max-iters", type=int, default=15)
    ap.add_argument("--top-k", type=int, default=3, help="memory notes returned per search")
    ap.add_argument("--mock-recall", default="always", choices=["always", "never"])
    ap.add_argument("--backend", default="mock", choices=["mock", "openai"])
    ap.add_argument("--base-url", default=os.environ.get("OPENAI_BASE_URL", "http://localhost:8000/v1"))
    ap.add_argument("--api-key-env", default="OPENAI_API_KEY")
    ap.add_argument("--model", default=None, help="agent model")
    ap.add_argument("--memory-model", default=None, help="extractor/summarizer model (default: --model)")
    ap.add_argument("--temperature", type=float, default=0.0)
    ap.add_argument("--summary-tokens", type=int, default=512)
    ap.add_argument("--p-obey", type=float, default=1.0, help="mock only")
    ap.add_argument("--workers", type=int, default=1)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    if a.backend == "openai" and not a.model:
        ap.error("--model is required with --backend openai")

    client = None
    if a.backend == "openai":
        import openai
        client = openai.OpenAI(base_url=a.base_url, api_key=os.environ.get(a.api_key_env, "local"),
                               timeout=300, max_retries=3)

    def make_agent():
        if a.backend == "mock":
            from silomem_agent.agents import MockAgent
            return MockAgent(p_obey=a.p_obey, seed=a.seed, recall=a.mock_recall)
        from silomem_agent.agents import TrackedOpenAILLM
        return TrackedOpenAILLM(client, a.model, temperature=a.temperature)

    def make_memory_model():
        if a.backend == "mock":
            from silomem_agent.models import MockMemoryModel
            return MockMemoryModel()
        from silomem_agent.models import OpenAIMemoryModel
        return OpenAIMemoryModel(client, a.memory_model or a.model, temperature=a.temperature,
                                 summary_tokens=a.summary_tokens)

    episodes = []
    for s in a.suite:
        episodes += build_episodes(s, attack=a.attack, n_later=a.n_later, seed=a.seed,
                                   user_tasks=a.user_tasks, injection_tasks=a.injection_tasks,
                                   limit=a.limit)

    def key(ep_id, arm):
        return (f"{ep_id}|{arm}|{a.memory_mode}|{a.on_refuse}|{a.top_k}|{a.model or 'mock'}|"
                f"{IMPL_VERSION.get(arm, '1')}")

    done = set()
    if os.path.exists(a.out):
        for line in open(a.out):
            try:
                r = json.loads(line)
            except json.JSONDecodeError:
                continue
            done.add(f"{r['episode_id']}|{r['arm']}|{r['memory_mode']}|{r['on_refuse']}|"
                     f"{r.get('top_k', 3)}|{r.get('cli_model') or 'mock'}|{r.get('impl', '1')}")
    jobs = [(ep, arm) for ep in episodes for arm in a.arms if key(ep.episode_id, arm) not in done]
    print(f"{len(episodes)} episodes x {len(a.arms)} arms; {len(jobs)} to run, "
          f"{len(episodes) * len(a.arms) - len(jobs)} already in {a.out}")
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    lock = threading.Lock()

    def job(ep, arm):
        cfg = RunConfig(arm=arm, memory_mode=a.memory_mode, on_refuse=a.on_refuse,
                        max_iters=a.max_iters, top_k=a.top_k, mock=a.backend == "mock")
        r = run_episode(ep, cfg, make_agent(), make_memory_model())
        r["cli_model"] = a.model
        with lock:
            with open(a.out, "a") as f:
                f.write(json.dumps(r, default=str) + "\n")
        return r

    n = 0
    with ThreadPoolExecutor(max_workers=max(1, a.workers)) as pool:
        futs = [pool.submit(job, ep, arm) for ep, arm in jobs]
        for fut in as_completed(futs):
            n += 1
            try:
                r = fut.result()
                s = r["summary"]
                print(f"[{n}/{len(jobs)}] {r['arm']:<12} {r['episode_id']:<55} "
                      f"imm={s['attack_immediate']} del={s['attack_delayed']} "
                      f"u1={s['utility_first']} uL={s['utility_later']:.2f} ref={s['refusals']}",
                      flush=True)
            except Exception as e:  # noqa: BLE001
                print(f"[{n}/{len(jobs)}] FAILED: {type(e).__name__}: {e}", flush=True)
    print(f"wrote {a.out}; summarize with: python summarize.py {a.out}")


if __name__ == "__main__":
    main()
