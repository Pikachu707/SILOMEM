#!/usr/bin/env bash
# Sweep the rephrasing attack across summarisers with the judge held fixed.
#
# ONE H100 HOLDS ONE MODEL, so this cannot be done in a single pass: serving
# a second model while the first is up fails with "Free memory on device
# cuda:0 (6.55/79.22 GiB) is less than desired GPU memory utilization", which
# reads as a configuration error and is not one.
#
# So: collect summaries per backend, then judge them all under one model.
# The alternative -- letting the judge change with the summariser -- makes a
# difference in laundering unreadable, since it confounds "this summariser
# quotes identifiers more" with "this judge is stricter".
set -uo pipefail

JUDGE="${JUDGE:-Qwen/Qwen2.5-7B-Instruct}"
CLUSTERS="${CLUSTERS:-60}"
# A 70B is here because the paper's first claim is that estimator quality is
# a property of the served model, and the obvious reply is that a stronger
# model is simply a better attributor. Four models topping out at 32B cannot
# answer that. If the 70B is a good attributor the claim narrows to small
# models, which is worth knowing and worth saying; if it is not, the claim
# holds across an order of magnitude of capability.
#
# AWQ at 70B fits one 80GB card with room for the KV cache. It is a
# quantised model and that is a caveat, not a disqualification: the same
# quantisation is applied to the 32B, so the comparison across the pair is
# internally consistent.
MODELS=(
  "allenai/OLMo-2-1124-7B-Instruct"
  "microsoft/Phi-3.5-mini-instruct"
  "Qwen/Qwen2.5-7B-Instruct"
  "Qwen/Qwen2.5-32B-Instruct-AWQ"
  "Qwen/Qwen2.5-72B-Instruct-AWQ"
)

serve() {
  # a 72B AWQ needs most of the card, so the usual 0.92 leaves nothing for
  # the KV cache and the engine dies on startup with a free-memory error
  case "$1" in
    *72B*) UTIL=0.95; WAIT=600 ;;
    *32B*) UTIL=0.90; WAIT=420 ;;
    *)     UTIL=0.85; WAIT=300 ;;
  esac
  pkill -f vllm.entrypoints 2>/dev/null
  # wait for the card to actually drain; pkill returns before the process
  # releases its allocation and the next server then fails on free memory
  for _ in $(seq 1 30); do
    used=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits)
    [ "$used" -lt 2000 ] && break
    sleep 5
  done
  nohup python -m vllm.entrypoints.openai.api_server --model "$1" \
    --port 8000 --max-num-seqs 64 \
    --gpu-memory-utilization "$UTIL" > /tmp/vllm.log 2>&1 &
  # the wait scales with the model: a 72B loads far slower than a 7B and a
  # fixed timeout silently reports the big one as a failure to start
  for _ in $(seq 1 $((WAIT / 10))); do
    curl -s http://localhost:8000/v1/models 2>/dev/null | grep -q "${1##*/}" \
      && return 0
    sleep 10
  done
  echo "FATAL: $1 did not come up. tail /tmp/vllm.log"; return 1
}

mkdir -p results
for M in "${MODELS[@]}"; do
  echo "=== collecting: $M"
  serve "$M" || exit 1
  python -u harness/run_adversarial.py --model "$M" --summarise-only \
    --clusters "$CLUSTERS" --out "results/adv_sum_${M##*/}.json" || exit 1
done

echo "=== judging all of them under $JUDGE"
serve "$JUDGE" || exit 1
python -u harness/run_adversarial.py --model "$JUDGE" \
  --judge-stored 'results/adv_sum_*.json' \
  --out results/adv_backends.json
