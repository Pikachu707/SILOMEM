"""Unit tests for the guarantees. These run with no model and no data."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest

from provenire.lattice import (Level, Item, meet, label_source,
                               label_generated, SourceClass, Provenance)
from provenire.influence import estimate, EstimatorConfig, EstimatorStats
from provenire.compaction import taint_preserving_compaction, trivial_compaction
from provenire.policy import ActionClass, Decision, decide
from provenire.declassify import (Budget, Ledger, d1_principal, d2_corroborate,
                                  DeclassificationRefused)
from analysis.prop2 import fixed_point, collapse_threshold, required_d


# ---- lattice --------------------------------------------------------
def test_meet_is_bottom_absorbing():
    assert meet([Level.T, Level.T, Level.U]) is Level.U
    assert meet([Level.T, Level.D]) is Level.D
    assert meet([Level.T]) is Level.T


def test_empty_meet_refuses():
    """An empty meet must be a loud error, not a silent U: returning U would
    mask an estimator bug rather than surfacing it."""
    with pytest.raises(ValueError):
        meet([])


def test_user_split():
    """Instructions are trusted, pasted content is not. Collapsing the two
    would make the principal a laundering channel -- MINJA's setting."""
    ins = label_source("i1", "do X", SourceClass.USER_INSTRUCTION, "e1")
    pst = label_source("i2", "<pasted>", SourceClass.USER_PASTED, "e2")
    assert ins.level is Level.T and not ins.origins
    assert pst.level is Level.U and pst.origins == {"e2"}


# ---- Theorem 2: no laundering ---------------------------------------
class _Cluster1:
    def __init__(self, items): self.items = items
    def cluster(self, items): return [list(items)]
    def summarise(self, cluster): return "summary of " + str(len(cluster))


def test_no_laundering_across_many_rounds():
    """One U item at the root keeps every descendant U for as long as the
    derivation runs, with no declassification anywhere."""
    items = [label_source(f"t{i}", "tool", SourceClass.TRUSTED_TOOL, "e")
             for i in range(4)]
    items.append(label_source("w", "web", SourceClass.RETRIEVED, "adv"))
    for _ in range(20):
        res = taint_preserving_compaction(items, _Cluster1(items))
        items = res.items
        assert all(i.level is Level.U for i in items)
    assert "adv" in items[0].origins


def test_generation_inherits_meet():
    ctx = [label_source("a", "x", SourceClass.TRUSTED_TOOL, "e1"),
           label_source("b", "y", SourceClass.RETRIEVED, "e2")]
    g = label_generated("g", "note", ctx)
    assert g.level is Level.U
    assert g.origins == {"e2"}
    assert g.how is Provenance.BY_MEET


# ---- fail-closed ----------------------------------------------------
def test_estimator_never_returns_empty():
    ctx = [label_source("a", "x", SourceClass.RETRIEVED, "e")]
    st = EstimatorStats()
    out = estimate("gen", ctx, cfg=EstimatorConfig(enable_loo=False), stats=st)
    assert out == ctx           # collapsed onto the whole context
    assert st.fallbacks == 1    # and it was counted, so it can be reported


# ---- policy ---------------------------------------------------------
def test_read_act_split():
    assert decide(Level.U, ActionClass.A1_ANSWER) is Decision.ALLOW
    assert decide(Level.U, ActionClass.A4_OUTBOUND) is Decision.DENY
    assert decide(Level.D, ActionClass.A3_LOCAL) is Decision.CONFIRM
    assert decide(Level.D, ActionClass.A3_LOCAL, permissive=True) is Decision.ALLOW
    # permissive must not touch the U row -- that is the guarantee
    assert decide(Level.U, ActionClass.A3_LOCAL, permissive=True) is Decision.DENY


# ---- declassification ------------------------------------------------
def test_budget_binds():
    b, led = Budget(2), Ledger()
    tool = label_source("c", "corr", SourceClass.TRUSTED_TOOL, "e")
    it = label_source("x", "u", SourceClass.RETRIEVED, "adv")
    d2_corroborate(it, tool, True, b, led)
    d2_corroborate(it, tool, True, b, led)
    with pytest.raises(DeclassificationRefused):
        d2_corroborate(it, tool, True, b, led)
    assert len(led.events) == 2


def test_declassified_item_cannot_corroborate():
    """This is what forbids adaptive strategy A1: launder one item, then use
    it to launder the next."""
    b, led = Budget(10), Ledger()
    tool = label_source("c", "corr", SourceClass.TRUSTED_TOOL, "e")
    laundered = d2_corroborate(
        label_source("x", "u", SourceClass.RETRIEVED, "adv"),
        tool, True, b, led)
    promoted = d1_principal(laundered, b, led)   # now T, but flagged
    victim = label_source("y", "u2", SourceClass.RETRIEVED, "adv2")
    with pytest.raises(DeclassificationRefused):
        d2_corroborate(victim, promoted, True, b, led)


def test_d2_cannot_skip_a_level():
    b, led = Budget(10), Ledger()
    tool = label_source("c", "corr", SourceClass.TRUSTED_TOOL, "e")
    it = label_source("x", "u", SourceClass.RETRIEVED, "adv")
    out = d2_corroborate(it, tool, True, b, led)
    assert out.level is Level.D          # U -> D only, never U -> T


# ---- Proposition 2 ---------------------------------------------------
def test_saturation_without_declassification():
    for a in (1.5, 2.0, 3.0, 5.0):
        assert fixed_point(a, 0.0) == pytest.approx(1.0, abs=1e-6)


def test_collapse_threshold_is_sharp():
    for a in (1.5, 2.0, 3.0, 5.0):
        d = collapse_threshold(a)
        assert fixed_point(a, d + 1e-3) == 0.0
        assert fixed_point(a, d - 1e-2) > 0.0


def test_required_d_monotone_in_a():
    ds = [required_d(a, 0.20) for a in (1.5, 2.0, 3.0, 5.0)]
    assert ds == sorted(ds)          # bigger clusters need more declassing
