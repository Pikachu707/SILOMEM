import sys, os, random
sys.path.insert(0, os.path.abspath('.'))
from harness.run_pfrac import CHANNELS, draw_channel

def test_channel_shares_sum_to_one():
    assert abs(sum(c[2] for c in CHANNELS) - 1.0) < 1e-9

def test_every_channel_has_a_class():
    assert all(c[1] in ("T", "U") for c in CHANNELS)

def test_draw_respects_the_shares():
    """p is a function of the channel mix, so a sampler that does not follow
    the declared shares silently reports a different deployment's p."""
    rng = random.Random(0)
    n = 20000
    seen = {}
    for _ in range(n):
        name, _ = draw_channel(rng)
        seen[name] = seen.get(name, 0) + 1
    for name, cls, share in CHANNELS:
        got = seen.get(name, 0) / n
        assert abs(got - share) < 0.02, f"{name}: {got:.3f} vs {share}"

def test_untrusted_share_is_what_the_mix_says():
    want = sum(c[2] for c in CHANNELS if c[1] == "U")
    rng = random.Random(1)
    u = sum(1 for _ in range(20000) if draw_channel(rng)[1] == "U")
    assert abs(u / 20000 - want) < 0.02


def test_omission_trials_vary_the_vendor_and_the_numbers():
    """Sixty trials over four shuffled fixed strings is twenty-four distinct
    prompts at temperature zero, counted two or three times each. The same
    defect in run_memgpt made twenty trials one trial and cost three rounds
    of wrong diagnosis."""
    import random, os
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    src = open(os.path.join(here, "harness", "run_omission.py")).read()
    assert "VENDORS" in src, "no vendor pool"
    assert "{v}" in src and "{inv}" in src, "prompt is not templated"
    ns = {}
    exec(src[src.index("TRUSTED_T ="):src.index("PROMPT_PRESSURED")], {}, ns)
    seen = set()
    for i in range(8):
        rng = random.Random(f"omit|0|{i}")
        v = rng.choice(ns["VENDORS"])
        ln = rng.randint(1000, 9999)
        seen.add((v, ln))
    assert len(seen) >= 7, f"only {len(seen)} distinct setups in 8 trials"


def test_batched_compaction_preserves_order():
    """summarise_many indexes results against the caller's item lists, so a
    reordering would mis-attribute every summary silently. ThreadPoolExecutor
    .map preserves input order; this pins that the code uses .map and not
    as_completed, which does not."""
    import os
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    src = open(os.path.join(here, "harness", "observe_q1.py")).read()
    fn = src[src.index("def summarise_many"):]
    assert "ex.map(" in fn, "must use .map, which preserves order"
    assert "as_completed" not in fn, "as_completed would reorder results"


def test_ablation_still_counts_one_probe_per_item():
    """Batching changed how fast the probes are issued, not how many a
    deployment pays for. The reported cost must not move."""
    import os
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    src = open(os.path.join(here, "harness", "run_selectivity.py")).read()
    fn = src[src.index("def round_ablation"):src.index("def round_silomem")]
    assert "calls += 1" in fn, "the per-item cost is no longer counted"


def test_no_tautological_columns_in_selectivity():
    """A column that selects items by label and then reports how many carry
    the other label is zero by definition. One was printed as evidence for
    Eq. (7) and would have reached the paper."""
    import os
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    src = open(os.path.join(here, "harness", "run_selectivity.py")).read()
    assert 'for x in items if x["label"] == T]' not in src or \
           'sum(1 for x in tr if x["label"] == U)' not in src, \
           "a label-selected set is being scored on the opposite label"
