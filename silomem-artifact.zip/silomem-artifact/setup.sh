#!/usr/bin/env bash
# One-shot setup. Run from the artifact root on the server.
set -euo pipefail

echo ">> creating venv"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -q --upgrade pip

echo ">> core deps (no accelerator needed)"
pip install -q numpy scipy pytest httpx

echo ">> retrieval embedder, CPU (Section 5: a small sentence encoder on CPU"
echo "   is ample for corpora of a few thousand memory items)"
pip install -q --extra-index-url https://download.pytorch.org/whl/cpu \
    torch --index-url https://download.pytorch.org/whl/cpu || \
    echo "   torch install failed -- retry manually, it is only needed in Phase 3"
pip install -q sentence-transformers || \
    echo "   sentence-transformers failed -- same, Phase 3 only"

echo
echo ">> preflight"
python preflight.py || true

echo
echo ">> unit tests"
python -m pytest tests/ -q

echo
echo ">> pilot on the mock backend (no network, no cost)"
python harness/run_pilot.py --seeds 5

echo
echo "Setup done. Read RUNBOOK.md, then Phase 2."
