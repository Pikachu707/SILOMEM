#!/usr/bin/env bash
# Every experiment the repositioned paper needs, in dependency order.
#
#   export GROQ_API_KEY=...
#   screen -S all
#   bash run_all_groq.sh 2>&1 | tee all_groq.log
#
# Resumable: each phase skips if its output JSON already exists, and the
# on-disk LLM cache survives interruption. Kill it and restart at any time.
#
# BUDGET. Groq's free tier is 30 requests per MINUTE, so the wall clock is
# set by request count, not by model size or token count. The whole run is
# roughly 13k calls, about 7 hours. Phases 1 and 5 are nearly free because
# they reuse Phase 2's cached summaries: declassification and policy are
# applied AFTER compaction and do not change any prompt.
set -uo pipefail
source .venv/bin/activate 2>/dev/null || true

MODEL="${MODEL:-Qwen/Qwen2.5-7B-Instruct}"
OUT="${OUT:-results}"
mkdir -p "$OUT"
hr() { printf '%.0s=' {1..70}; echo; }
say() { echo; hr; echo "$*"; hr; }

# skip a phase whose output already exists
run() {   # run <outfile> <args...>
  local f="$OUT/$1"; shift
  if [ -s "$f" ]; then echo "  skip (exists): $f"; return 0; fi
  python harness/run_rq2.py --backend "${BK:-vllm}" --model "$MODEL" \
      --keep-frac 0 --max-calls 0 --loo-workers ${W:-32} --out "$f" "$@" || {
    echo "  FAILED: $f -- rerun this script to resume"; return 1; }
}

say "Preflight -- serve each RQ4 model separately; vLLM holds one at a time"
PORT="${PORT:-8000}"
export VLLM_KEY="${VLLM_KEY:-local}"
python harness/check_backend.py --base-url "http://localhost:$PORT/v1" \
    --api-key-env VLLM_KEY --model "$MODEL" || exit 1

# =====================================================================
say "RQ1  does measured TER follow Prop 2 at the measured (a,d)?"
# Fixed workload, sweep d. Nearly free after the first run: declassification
# is applied to labels after compaction and changes no prompt, so every d
# beyond the first is a cache hit.
for d in 0.0 0.2 0.4 0.6; do
  echo "-- d=$d"
  run "rq1_d$d.json" --seeds 5 --horizon 96 --budget-items 32 \
      --sweep-u 0.3 --declass-rate "$d" --loo-max-cluster 16
done

# =====================================================================
say "RQ2a  iota as a function of the untrusted-source fraction u"
# The headline curve. Each u is a different workload, so none of this is
# cached -- it is the bulk of the run.
run "rq2_usweep.json" --seeds 5 --horizon 96 --budget-items 32 \
    --sweep-u 0.05,0.1,0.2,0.3,0.4 --declass-rate 0.5 --loo-max-cluster 16

say "RQ2b  does iota follow phi*(1-(1-u)^m)?  sweep m"
# The real test of Eq. (iota): the formula fixes the dependence on m, so
# this can only confirm or refute it. If iota does not move with m, phi was
# a coincidence of one parameter setting and the criterion does not hold.
for m in 3 5 8; do
  echo "-- m=$m sources per session"
  run "rq2_m$m.json" --seeds 3 --horizon 48 --budget-items 24 \
      --n-items "$m" --sweep-u 0.1,0.2 --declass-rate 0.5 --loo-max-cluster 16
done

# =====================================================================
say "RQ4  skipped here -- run rq4_models.sh separately"
echo "vLLM serves ONE model at a time, so the capability sweep needs the"
echo "server restarted between models. bash rq4_models.sh does that."

# =====================================================================
say "RQ6  ablations"
echo "-- A. leave-one-out vs the trivial estimator"
# The one that can change the design: leave-one-out is ~80% of the compute.
# If the trivial estimator gives the same a, it buys nothing.
run "rq6_loo_on.json"  --seeds 3 --horizon 48 --budget-items 24 \
    --sweep-u 0.1,0.2,0.4 --declass-rate 0.5 --loo-max-cluster 16
run "rq6_loo_off.json" --seeds 3 --horizon 48 --budget-items 24 \
    --sweep-u 0.1,0.2,0.4 --declass-rate 0.5 --loo-max-cluster 0

echo "-- B. the leave-one-out cap, which trades a against cost"
for cap in 4 8; do
  run "rq6_cap$cap.json" --seeds 3 --horizon 48 --budget-items 24 \
      --sweep-u 0.2 --declass-rate 0.5 --loo-max-cluster "$cap"
done

echo "-- C. strict vs permissive (free: a lookup after the run)"
run "rq6_strict.json"     --seeds 3 --horizon 48 --budget-items 24 \
    --sweep-u 0.2 --declass-rate 0.5 --loo-max-cluster 16 --config strict
run "rq6_permissive.json" --seeds 3 --horizon 48 --budget-items 24 \
    --sweep-u 0.2 --declass-rate 0.5 --loo-max-cluster 16 --config permissive

# =====================================================================
say "Done"
echo "python3 show.py             # the table"
echo "python3 analysis/fit_iota.py $OUT   # Eq. (iota) and the crossing"
echo
echo "RQ3 is not here. It asks where the workloads of published defenses"
echo "sit relative to the crossing, which is a reading task: extract u and"
echo "m from their evaluation setups and apply Eq. (iota). No compute."
