#!/usr/bin/env bash
# RQ4: does the attributed cluster size rise with backend capability?
#
# This is the most surprising claim in the paper -- if a rises with model
# capability then a better backend makes the utility floor HIGHER, not lower.
# An earlier 0.5B-vs-20B comparison suggested it, but the two runs differed in
# horizon and budget as well as model, so it could not be read. Here the
# config is identical and only the model changes.
#
# vLLM holds one model at a time, so the server is restarted between them.
# 80GB fits all three, including the 32B at 4-bit.
set -uo pipefail
source .venv/bin/activate 2>/dev/null || true
export VLLM_KEY=local
PORT="${PORT:-8000}"
OUT="${OUT:-results}"; mkdir -p "$OUT"
hr() { printf '%.0s=' {1..70}; echo; }

MODELS="${MODELS:-Qwen/Qwen2.5-0.5B-Instruct Qwen/Qwen2.5-7B-Instruct Qwen/Qwen2.5-32B-Instruct-AWQ}"

# vLLM's flag names drift between releases (--disable-log-requests became
# --no-enable-log-requests). Ask the installed version rather than guessing.
QUIET=""
if python -m vllm.entrypoints.openai.api_server --help 2>&1 | grep -q -- "--no-enable-log-requests"; then
  QUIET="--no-enable-log-requests"
elif python -m vllm.entrypoints.openai.api_server --help 2>&1 | grep -q -- "--disable-log-requests"; then
  QUIET="--disable-log-requests"
fi

serve() {
  pkill -f "vllm.entrypoints" 2>/dev/null; sleep 5
  echo "  loading $1 ..."
  nohup python -m vllm.entrypoints.openai.api_server --model "$1" \
      --port "$PORT" --max-num-seqs 64 $QUIET \
      > "/tmp/vllm_$(echo "$1" | tr '/' '_').log" 2>&1 &
  for i in $(seq 1 360); do
    pgrep -f "vllm.entrypoints" >/dev/null || {
      echo "  server died; tail -30 /tmp/vllm_*.log"; return 1; }
    curl -s "http://localhost:$PORT/v1/models" >/dev/null 2>&1 && return 0
    sleep 5
  done
  echo "  server did not come up; see /tmp/vllm_*.log"; return 1
}

for M in $MODELS; do
  tag=$(echo "$M" | tr '/:.' '___')
  f="$OUT/rq4_$tag.json"
  hr; echo "RQ4  $M"; hr
  if [ -s "$f" ]; then echo "  skip (exists)"; continue; fi
  serve "$M" || continue
  python harness/probe_models.py --backend ollama \
      --base-url "http://localhost:$PORT/v1" --api-key-env VLLM_KEY \
      --models "$M" --gap 0.2
  python harness/run_rq2.py --backend vllm --model "$M" \
      --loo-workers 32 --keep-frac 0 --max-calls 0 \
      --seeds 3 --horizon 48 --budget-items 24 \
      --sweep-u 0.1,0.2,0.4 --declass-rate 0.5 --loo-max-cluster 16 \
      --out "$f"
done

pkill -f "vllm.entrypoints" 2>/dev/null
hr; echo "done.  python3 show.py   # compare the `a` column across models"; hr
