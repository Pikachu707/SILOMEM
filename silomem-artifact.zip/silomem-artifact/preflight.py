#!/usr/bin/env python3
"""Preflight. Run this first, on the server, before anything else.

It answers one question: what will stop me today? Everything it checks is
something that has blocked a real run of this kind of evaluation. It exits
non-zero if a hard blocker is present, and prints a WARN for anything that
only costs you time.
"""
from __future__ import annotations

import importlib
import os
import shutil
import subprocess
import sys

# Colour only when attached to a terminal. day1.sh tees into a report file
# that gets pasted around, and escape codes make it unreadable.
_C = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None
OK   = "\033[32m  OK \033[0m" if _C else "  OK "
WARN = "\033[33mWARN \033[0m" if _C else "WARN "
FAIL = "\033[31mFAIL \033[0m" if _C else "FAIL "
hard_fail = False


def check(label: str, ok: bool, detail: str = "", hard: bool = True) -> None:
    global hard_fail
    tag = OK if ok else (FAIL if hard else WARN)
    print(f"[{tag}] {label}" + (f"  -- {detail}" if detail else ""))
    if not ok and hard:
        hard_fail = True


print("=" * 68)
print("PROVENIRE preflight")
print("=" * 68)

# ---- interpreter ----------------------------------------------------
v = sys.version_info
check("Python >= 3.10", v >= (3, 10), f"found {v.major}.{v.minor}.{v.micro}")

# ---- packages -------------------------------------------------------
for mod, hard in [("numpy", True), ("scipy", True), ("pytest", True),
                  ("sentence_transformers", False), ("torch", False),
                  ("httpx", False)]:
    try:
        importlib.import_module(mod)
        check(f"import {mod}", True, hard=hard)
    except Exception as e:  # noqa: BLE001
        check(f"import {mod}", False, str(e)[:44], hard=hard)

# ---- disk -----------------------------------------------------------
try:
    free_gb = shutil.disk_usage(".").free / 2**30
    check("disk free >= 50 GB", free_gb >= 50, f"{free_gb:.0f} GB free")
except Exception as e:  # noqa: BLE001
    check("disk check", False, str(e)[:44], hard=False)

# ---- memory ---------------------------------------------------------
try:
    with open("/proc/meminfo") as f:
        kb = int(next(l for l in f if l.startswith("MemTotal")).split()[1])
    gb = kb / 2**20
    check("RAM >= 32 GB", gb >= 32, f"{gb:.0f} GB total", hard=False)
except Exception:  # noqa: BLE001
    check("RAM check", False, "could not read /proc/meminfo", hard=False)

# ---- cores ----------------------------------------------------------
cores = os.cpu_count() or 1
check("CPU cores >= 8", cores >= 8, f"{cores} cores", hard=False)

# ---- accelerator (optional by design) -------------------------------
has_gpu = shutil.which("nvidia-smi") is not None
if has_gpu:
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total",
                              "--format=csv,noheader"],
                             capture_output=True, text=True, timeout=10)
        check("GPU present (optional)", True, out.stdout.strip().splitlines()[0],
              hard=False)
    except Exception:  # noqa: BLE001
        check("GPU present (optional)", False, "nvidia-smi failed", hard=False)
else:
    check("GPU present (optional)", False,
          "none -- fine, the design is CPU + hosted API", hard=False)

# ---- API credentials ------------------------------------------------
keys = [k for k in ("OPENAI_API_KEY", "ANTHROPIC_API_KEY",
                    "TOGETHER_API_KEY", "OPENROUTER_API_KEY")
        if os.environ.get(k)]
check("at least one inference API key in env", bool(keys),
      ", ".join(keys) if keys else "set one before Phase 2", hard=False)

# ---- outbound network -----------------------------------------------
try:
    import socket
    socket.create_connection(("pypi.org", 443), timeout=5).close()
    check("outbound HTTPS", True)
except Exception as e:  # noqa: BLE001
    check("outbound HTTPS", False, str(e)[:44], hard=False)

# ---- the artifact itself --------------------------------------------
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from provenire import Level, meet  # noqa: F401
    check("provenire imports", True)
except Exception as e:  # noqa: BLE001
    check("provenire imports", False, str(e)[:44])

print("=" * 68)
if hard_fail:
    print("Hard blockers above. Fix those first; the rest can wait.")
    sys.exit(1)
print("No hard blockers. Next: `python -m pytest tests/ -q`")
print("Then:            `python harness/run_pilot.py --mock`")
sys.exit(0)
