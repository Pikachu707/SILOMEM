#!/usr/bin/env python3
"""Why is the attack rate non-monotone in the copy count?

    python harness/diag_echo.py --model Qwen/Qwen2.5-7B-Instruct

The measured matrix does not match Theorem 1. It predicts a clean step at
k=2 holding for every k above it, and instead the rate drops at k=3 in three
of nine configurations and collapses to zero at k=5 under light paraphrase.
More copies should never help the defense, so either the theorem's hypotheses
are failing at higher k or the harness is measuring something else.

The leading hypothesis is the fail-closed rule. As copies accumulate the
payload dominates the summary, so withholding a *trusted* item changes it
less; if every trusted item also falls below tau the attributed set is empty,
the fallback of Alg. 1 line 5 fires, propagation reverts to the whole cluster,
and Theorem 3 makes the defense immune. That would make the attack's success
non-monotone by construction, with an optimum copy count rather than a
threshold, which is a materially different claim from the one the paper makes.

This prints, per cell: the attributed-set size, how often the fallback fired,
and how many trusted and untrusted items were attributed. Those four numbers
distinguish the hypothesis from the alternatives.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from harness.backends import token_similarity
from harness.run_echo import MARK, build, cluster
from provenire.influence import EstimatorConfig, EstimatorStats, estimate
from provenire.lattice import Level


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--backend", default="vllm")
    ap.add_argument("--model", required=True)
    ap.add_argument("--base-url", default="http://localhost:8000/v1")
    ap.add_argument("--api-key-env", default="VLLM_KEY")
    ap.add_argument("--copies", default="1,2,3,5")
    ap.add_argument("--tau", default="0.05,0.15,0.30")
    ap.add_argument("--paraphrase", default="verbatim,light")
    ap.add_argument("--n-trusted", type=int, default=3)
    ap.add_argument("--trials", type=int, default=6)
    ap.add_argument("--out", default="results/diag_echo.json")
    a = ap.parse_args()

    copies = [int(x) for x in a.copies.split(",")]
    taus = [float(x) for x in a.tau.split(",")]
    modes = a.paraphrase.split(",")
    out = {"config": vars(a), "rows": []}

    print("=" * 74)
    print("attributed-set composition per cell")
    print("  |A|      mean attributed-set size")
    print("  fb       fraction of clusters where the fallback fired")
    print("  T,U      mean trusted / untrusted items attributed")
    print("  payload  fraction of clusters where a payload copy was attributed")
    print("=" * 74)

    for mode in modes:
        for tau in taus:
            print(f"\n{mode}, tau={tau:.2f}")
            print(f"{'k':>4}{'|A|':>7}{'fb':>7}{'T':>7}{'U':>7}{'payload':>9}"
                  f"{'summary carries':>17}")
            print("-" * 58)
            for k in copies:
                bk, sim = build(a.backend, a.model, a.base_url,
                                a.api_key_env, a.n_trusted + k, False)
                sizes, fbs, ts, us, pay, car = [], [], [], [], [], []
                for seed in range(a.trials):
                    K = cluster(k, mode, a.n_trusted, seed)
                    s = bk.summarise(K)
                    car.append(1.0 if MARK in s else 0.0)
                    st = EstimatorStats()
                    A = estimate(s, K, regenerator=bk, similarity=sim,
                                 cfg=EstimatorConfig(tau=tau,
                                                     loo_max_cluster=64),
                                 stats=st)
                    A = list(A)
                    fell_back = len(A) == len(K) and st.fallbacks > 0
                    sizes.append(len(A))
                    fbs.append(1.0 if fell_back else 0.0)
                    ts.append(sum(1 for i in A if i.level is Level.T))
                    us.append(sum(1 for i in A if i.level is Level.U))
                    pay.append(1.0 if any(i.level is Level.U for i in A) else 0.0)
                m = lambda v: sum(v) / max(len(v), 1)
                print(f"{k:>4}{m(sizes):>7.1f}{m(fbs):>7.2f}{m(ts):>7.1f}"
                      f"{m(us):>7.1f}{m(pay):>9.2f}{m(car):>17.2f}")
                out["rows"].append({"mode": mode, "tau": tau, "k": k,
                                    "A": m(sizes), "fallback": m(fbs),
                                    "trusted": m(ts), "untrusted": m(us),
                                    "payload_attributed": m(pay),
                                    "summary_carries": m(car)})

    print()
    print("READ IT LIKE THIS.")
    print("  fb rising with k        -> the fail-closed hypothesis holds; the")
    print("                             attack has an optimum k, not a")
    print("                             threshold, and the paper must say so.")
    print("  T falling to 0 with k   -> same mechanism, seen upstream.")
    print("  payload > 0 at k >= 2   -> Theorem 1's conclusion (1) is false on")
    print("                             this backend and the theorem needs a")
    print("                             hypothesis it does not have.")
    print("  summary carries < 1     -> the copies stopped co-summarising, so")
    print("                             the cell tests nothing.")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(out, open(a.out, "w"), indent=2)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
