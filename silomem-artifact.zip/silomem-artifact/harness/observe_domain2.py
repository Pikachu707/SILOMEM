#!/usr/bin/env python3
"""Does the exclusion bound transfer to a domain where topics are adjacent?

    python harness/observe_domain2.py --model Qwen/Qwen2.5-7B-Instruct

The invoice domain of observe_q1.py is the easy case for a location test: the
on-topic items form a tight semantic cluster and the off-topic items are far
from it and from each other, so embedding similarity separates them with room
to spare. A bound found there tells us little about a corpus where the
distinction is finer.

This builds the hard case. The agent's task is incident triage for a service:
on-topic items are incidents affecting availability, off-topic items are
operational notes about the same service that do not. Both talk about the same
systems, the same components, and the same week. They are neighbours in
embedding space, and the summariser distinguishes them by consequence rather
than by subject.

If the bound found on the invoice domain still works here, it transfers across
a real change in geometry. If it does not, the paper's limitation is
confirmed and quantified: a deployment must find its own bound, and we say so
with a number attached.

The comparison to make is not "does the AUC hold" but "does lo=0.20 still
exclude a useful fraction without excluding contributors", since that is the
parameter a deployment would carry over.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from harness.observe_q1 import key_token, summarise

# Both pools are about the same service, the same components, the same week.
# What separates them is whether the event affected availability, which is
# what the summarising instruction asks for. A bag-of-words view cannot tell
# them apart; an embedding barely can.
ONTOPIC = [
    "checkout service {n} returned errors to users for eleven minutes",
    "database replica {n} fell behind and queries began timing out",
    "the payment gateway {n} rejected transactions during the deploy",
    "cache node {n} evicted early and latency doubled for an hour",
    "auth service {n} refused logins after the certificate rotation",
    "queue worker {n} stalled and orders were delayed downstream",
]
OFFTOPIC = [
    "checkout service {n} had its logging verbosity raised on Tuesday",
    "database replica {n} was added to the nightly backup rotation",
    "the payment gateway {n} received a routine dependency bump",
    "cache node {n} was relabelled during the inventory cleanup",
    "auth service {n} had its runbook updated with new contacts",
    "queue worker {n} was migrated to the newer instance type",
]
TASK = ("Summarise these notes for an on-call engineer in ONE entry of at "
        "most 40 words. Keep what affected availability. Entry only.\n")


def _check_pools():
    bad = [t for t in ONTOPIC + OFFTOPIC if not key_token(t.format(n=1234))]
    if bad:
        raise SystemExit("templates with no key token:\n  " + "\n  ".join(bad))


def make_cluster(rng, n_on, n_off):
    items = []
    for pool, role, k in ((ONTOPIC, "ontopic", n_on),
                          (OFFTOPIC, "offtopic", n_off)):
        for t in rng.sample(pool, min(k, len(pool))):
            items.append({"role": role,
                          "text": t.format(n=rng.randint(1000, 9999))})
    rng.shuffle(items)
    return items


def summ(url, model, key, items):
    import httpx
    r = httpx.post(f"{url}/chat/completions", timeout=180,
                   headers={"Authorization": f"Bearer {key}"},
                   json={"model": model, "max_tokens": 90, "temperature": 0.0,
                         "messages": [{"role": "user", "content":
                             TASK + "\n".join("- " + i["text"]
                                              for i in items)}]})
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"].strip()


def encode(texts):
    from sentence_transformers import SentenceTransformer
    m = SentenceTransformer("all-MiniLM-L6-v2")
    uniq = sorted(set(texts))
    v = m.encode(uniq, normalize_embeddings=True, batch_size=128,
                 show_progress_bar=False)
    return {t: v[i] for i, t in enumerate(uniq)}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://localhost:8000/v1")
    ap.add_argument("--api-key-env", default="VLLM_KEY")
    ap.add_argument("--model", required=True)
    ap.add_argument("--clusters", type=int, default=60)
    ap.add_argument("--carried-lo", type=float, default=0.20,
                    help="the bound found on the invoice domain, carried over")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default="results/domain2.json")
    a = ap.parse_args()
    key = os.environ.get(a.api_key_env, "local")
    _check_pools()

    mixes = [(4, 2), (3, 3), (2, 4)]
    obs = []
    total = len(mixes) * a.clusters
    print(f"{total} clusters, incident triage, adjacent topics\n")
    done = 0
    for n_on, n_off in mixes:
        for c in range(a.clusters):
            rng = random.Random(f"d2|{a.seed}|{n_on}|{n_off}|{c}")
            items = make_cluster(rng, n_on, n_off)
            s = summ(a.base_url, a.model, key, items)
            obs.append({"summary": s,
                        "items": [{"role": it["role"], "text": it["text"]}
                                  for it in items]})
            done += 1
            if done % 30 == 0:
                print(f"  {done}/{total}")

    print("\nencoding")
    vec = encode([o["summary"] for o in obs]
                 + [it["text"] for o in obs for it in o["items"]])
    for o in obs:
        sv = vec[o["summary"]]
        for it in o["items"]:
            it["sim"] = float(vec[it["text"]] @ sv)

    items = [it for o in obs for it in o["items"]]
    n = len(items)
    on = [it["sim"] for it in items if it["role"] == "ontopic"]
    off = [it["sim"] for it in items if it["role"] == "offtopic"]
    import statistics as st
    print("\n" + "=" * 66)
    print("Is this domain actually harder?")
    print("=" * 66)
    print(f"  on-topic  mean similarity {st.fmean(on):.3f}")
    print(f"  off-topic mean similarity {st.fmean(off):.3f}")
    print(f"  gap                        {st.fmean(on)-st.fmean(off):.3f}")
    print("  invoice domain gap was 0.297 (0.545 against 0.248)")
    if st.fmean(on) - st.fmean(off) > 0.25:
        print("\n  NOT HARDER. The topics separate as widely as in the invoice")
        print("  domain, so this does not test transfer across a change in")
        print("  geometry. Write a pool whose classes are closer before")
        print("  reading anything below.")

    print("\n" + "=" * 66)
    print(f"Carrying lo = {a.carried_lo:.2f} over from the invoice domain")
    print("=" * 66)
    exc = [it for it in items if it["sim"] < a.carried_lo]
    on_exc = sum(1 for it in exc if it["role"] == "ontopic")
    n_on = sum(1 for it in items if it["role"] == "ontopic")
    print(f"  excluded            {100*len(exc)/n:.0f}% of items")
    print(f"  on-topic excluded   {on_exc} / {n_on} "
          f"({100*on_exc/max(n_on,1):.1f}%)")
    print(f"  invoice domain      30% excluded, 1 / 540 on-topic")

    print("\nsweep on this domain:")
    sims = sorted(it["sim"] for it in items)
    print(f"{'lo':>7}{'excluded':>11}{'on-topic excl.':>17}")
    rows = []
    for p in (10, 20, 30, 40, 50):
        lo = sims[int(n * p / 100) - 1]
        e = [it for it in items if it["sim"] < lo]
        oe = sum(1 for it in e if it["role"] == "ontopic")
        print(f"{lo:>7.2f}{100*len(e)/n:>10.0f}%{oe:>11} / {n_on}")
        rows.append({"lo": round(lo, 3), "excluded_frac": len(e)/n,
                     "ontopic_excluded": oe})

    print()
    exc_frac = len(exc) / n
    fn_frac = on_exc / max(n_on, 1)
    # matched target: the source domain excluded 30% at lo=0.20
    matched = [r for r in rows if r["excluded_frac"] >= 0.28][:1]
    if fn_frac > 0.05:
        print("THE BOUND DOES NOT TRANSFER, and it fails unsafely. Carried")
        print(f"over it excludes {100*fn_frac:.0f}% of on-topic items where the source")
        print("domain lost one in 540.")
    elif exc_frac < 0.15:
        print("THE BOUND DOES NOT TRANSFER, but it fails SAFELY. Carried over")
        print(f"it excludes only {100*exc_frac:.0f}% of items against 30% in the source")
        print("domain, so it has degenerated toward whole-cluster")
        print("propagation: sound, free, and no longer selective. The")
        print("similarity scale has shifted, not the method.")
        if matched:
            m = matched[0]
            print(f"\n  To recover 30% exclusion here, lo must rise to "
                  f"{m['lo']:.2f},")
            print(f"  and there {m['ontopic_excluded']} / {n_on} on-topic items are lost")
            print(f"  ({100*m['ontopic_excluded']/n_on:.1f}%) against 0.2% in the source domain.")
            print("  So the bound is domain-specific and the search for it is")
            print("  what the monotonicity of Section 5.4 makes safe: erring")
            print("  low costs selectivity, never soundness.")
    else:
        print("THE BOUND TRANSFERS on this pair of domains: it excludes a")
        print(f"comparable fraction ({100*exc_frac:.0f}% against 30%) at a comparable")
        print("false-negative rate. One data point, not a general claim.")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump({"config": vars(a), "gap": st.fmean(on) - st.fmean(off),
               "carried": {"lo": a.carried_lo, "excluded_frac": len(exc)/n,
                           "ontopic_excluded": on_exc, "ontopic_n": n_on},
               "sweep": rows,
               "observations": [{"summary": o["summary"],
                                 "items": [{"role": it["role"],
                                            "text": it["text"],
                                            "sim": it["sim"],
                                            "verdict": "absent"
                                            if it["sim"] < a.carried_lo
                                            else "present"}
                                           for it in o["items"]]}
                                for o in obs]},
              open(a.out, "w"), indent=1)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
