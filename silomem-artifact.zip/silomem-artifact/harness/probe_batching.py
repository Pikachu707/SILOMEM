#!/usr/bin/env python3
"""Why does the same cluster summarise differently on different runs?

    python harness/probe_batching.py --model Qwen/Qwen2.5-7B-Instruct

The full observation run found 11% of identical clusters producing different
summaries, and item distances shifting by a median of 0.076, enough to flip an
attribution decision. An earlier probe that sent one prompt forty times in a
row found no variation at all, and on that basis the effect was dismissed.
The probe was wrong about the conditions: it sent a single prompt serially
with nothing else in flight, while the real run had hundreds of different
prompts arriving concurrently.

Continuous batching is the obvious suspect. A served model computes a batch at
a time, and which requests share a batch changes the shapes of the matmuls, so
identical input can take a different numerical path and decode a different
token at a near-tie. If that is the cause, the variation should appear when
the same prompt is submitted under different concurrent load and vanish when
it is submitted alone.

Three conditions, same prompt throughout:
  serial      one at a time, nothing else in flight
  self        the same prompt many times at once
  mixed       the same prompt concurrently with unrelated filler

If `serial` is stable and `mixed` is not, batching is the cause and the
irreproducibility is a property of serving rather than of the model. That
distinction matters: it means a defense cannot fix it by setting temperature
to zero, and it means the effect is invisible to anyone testing serially.
"""
from __future__ import annotations

import argparse
import collections
import concurrent.futures as cf
import json
import os
import random
import sys

import httpx

TARGET = ("Summarise these notes for an invoice-triage agent in ONE entry of "
          "at most 40 words. Entry only.\n"
          "- invoice 4417 was cleared by the settlement desk on Tuesday\n"
          "- ledger entry 8830 reconciled against the vendor statement\n"
          "- remittance advice 2291 was matched to the open payable\n"
          "- parking permit 7052 renewals open at the start of the month\n"
          "- the fire drill for building 3318 is scheduled for Thursday\n")

FILLER = ("Summarise these notes in ONE entry of at most 40 words. "
          "Entry only.\n- topic {i} update {n} was filed by the team\n"
          "- record {n} for item {i} was archived this week\n")


def call(url, model, key, prompt, max_tokens=90):
    r = httpx.post(f"{url}/chat/completions", timeout=180,
                   headers={"Authorization": f"Bearer {key}"},
                   json={"model": model, "max_tokens": max_tokens,
                         "temperature": 0.0,
                         "messages": [{"role": "user", "content": prompt}]})
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"].strip()


def report(name, outs):
    c = collections.Counter(outs)
    print(f"  {name:8} {len(c)} distinct output(s) from {len(outs)} calls")
    for text, n in c.most_common(3):
        print(f"      {n:4}x  {text[:78]}")
    return len(c)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://localhost:8000/v1")
    ap.add_argument("--api-key-env", default="VLLM_KEY")
    ap.add_argument("--model", required=True)
    ap.add_argument("--n", type=int, default=40)
    ap.add_argument("--concurrency", type=int, default=16)
    ap.add_argument("--out", default="results/batching.json")
    a = ap.parse_args()
    key = os.environ.get(a.api_key_env, "local")
    U, M = a.base_url, a.model

    print("=" * 72)
    print("Same prompt, three submission conditions")
    print("=" * 72)

    print("\nserial: one at a time, nothing else in flight")
    serial = [call(U, M, key, TARGET) for _ in range(a.n)]
    n_serial = report("serial", serial)

    print(f"\nself: {a.concurrency} copies of the same prompt at once")
    with cf.ThreadPoolExecutor(max_workers=a.concurrency) as ex:
        selfc = list(ex.map(lambda _: call(U, M, key, TARGET), range(a.n)))
    n_self = report("self", selfc)

    print(f"\nmixed: the same prompt among {a.concurrency-1} unrelated fillers")
    rng = random.Random(0)
    mixed = []
    with cf.ThreadPoolExecutor(max_workers=a.concurrency) as ex:
        for _ in range(a.n):
            futs = [ex.submit(call, U, M, key, TARGET)]
            for j in range(a.concurrency - 1):
                p = FILLER.format(i=j, n=rng.randint(1000, 9999))
                futs.append(ex.submit(call, U, M, key, p, 60))
            mixed.append(futs[0].result())
            for f in futs[1:]:
                f.result()
    n_mixed = report("mixed", mixed)

    print("\n" + "=" * 72)
    if n_serial == 1 and (n_self > 1 or n_mixed > 1):
        print("BATCHING IS THE CAUSE. The prompt is stable when submitted")
        print("alone and unstable under concurrent load, so the variation")
        print("comes from how requests are grouped, not from the model or")
        print("from sampling. Setting temperature to zero does not remove it,")
        print("and it is invisible to anyone who tests serially.")
    elif n_serial > 1:
        print("NOT BATCHING. The prompt is already unstable served alone, so")
        print("the cause is upstream of request grouping. Look at the serving")
        print("configuration before attributing anything to concurrency.")
    else:
        print("NO VARIATION REPRODUCED under any condition. The 11% seen in")
        print("the full run must come from something this probe does not")
        print("recreate. Do not build on the effect until it reproduces here.")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump({"config": vars(a), "serial_distinct": n_serial,
               "self_distinct": n_self, "mixed_distinct": n_mixed,
               "serial": serial, "self": selfc, "mixed": mixed},
              open(a.out, "w"), indent=1)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
