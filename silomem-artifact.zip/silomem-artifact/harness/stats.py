"""Statistical protocol of Section 6.1.

Two things here are not optional. Trials per cell are fixed by a power
analysis on a pilot rather than chosen ad hoc, and cross-horizon comparisons
are PAIRED, because the four horizons are snapshots of one trajectory and are
therefore statistically dependent. Bootstrapping over snapshots instead of
over trajectories would understate the interval.
"""
from __future__ import annotations

import math
import random
from statistics import NormalDist


def bootstrap_ci(values, *, reps: int = 10_000, alpha: float = 0.05,
                 seed: int = 0) -> tuple[float, float]:
    """Percentile bootstrap. Resample TRAJECTORIES, not snapshots."""
    values = list(values)
    if not values:
        return (float("nan"), float("nan"))
    rng = random.Random(seed)
    n = len(values)
    means = []
    for _ in range(reps):
        means.append(sum(rng.choice(values) for _ in range(n)) / n)
    means.sort()
    lo = means[int(alpha / 2 * reps)]
    hi = means[int((1 - alpha / 2) * reps) - 1]
    return (lo, hi)


def paired_permutation_p(a, b, *, reps: int = 10_000, seed: int = 0) -> float:
    """Two-sided paired permutation test on the mean difference.

    Use this for every cross-horizon comparison. a[i] and b[i] must come from
    the SAME trajectory.
    """
    a, b = list(a), list(b)
    if len(a) != len(b):
        raise ValueError("paired test needs equal-length, aligned samples")
    diffs = [x - y for x, y in zip(a, b)]
    obs = abs(sum(diffs) / len(diffs))
    rng = random.Random(seed)
    hits = 0
    for _ in range(reps):
        flipped = [d if rng.random() < 0.5 else -d for d in diffs]
        if abs(sum(flipped) / len(flipped)) >= obs:
            hits += 1
    return (hits + 1) / (reps + 1)


def holm(pvalues, alpha: float = 0.01):
    """Holm correction. The canary probe fires at every compaction epoch, so
    an uncorrected test at a plausible epoch count produces a false alarm by
    construction (Section 4.10)."""
    pvalues = list(pvalues)
    idx = sorted(range(len(pvalues)), key=lambda i: pvalues[i])
    m = len(pvalues)
    out = [False] * m
    for rank, i in enumerate(idx):
        if pvalues[i] <= alpha / (m - rank):
            out[i] = True
        else:
            break
    return out


def trials_per_cell(p_pilot: float, mde: float, *, power: float = 0.80,
                    alpha: float = 0.05) -> int:
    """Two-proportion power analysis. Feed it the pilot rate and the smallest
    effect worth detecting; it returns n per arm. Report the pilot and the
    MDE alongside the number, or the sample size looks arbitrary.
    """
    z_a = NormalDist().inv_cdf(1 - alpha / 2)
    z_b = NormalDist().inv_cdf(power)
    p1 = p_pilot
    p2 = max(min(p_pilot + mde, 1.0), 0.0)
    pbar = (p1 + p2) / 2
    num = (z_a * math.sqrt(2 * pbar * (1 - pbar))
           + z_b * math.sqrt(p1 * (1 - p1) + p2 * (1 - p2))) ** 2
    return math.ceil(num / (p2 - p1) ** 2)
