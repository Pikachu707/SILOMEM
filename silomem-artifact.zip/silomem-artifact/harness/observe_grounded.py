#!/usr/bin/env python3
"""Content-grounded attribution: sound by construction, and free.

    python harness/observe_grounded.py --model Qwen/Qwen2.5-7B-Instruct

THE IDEA. Leave-one-out asks "does withholding this item move the summary?",
which is a noisy score compared against a threshold, and a threshold can err
in both directions. The direction that matters drops a true contributor from
the meet and breaks the guarantee.

Content-grounded attribution asks a different question: "is this item's
content present in the summary?" and resolves the uncertain case toward
inclusion. Three outcomes per item:

  PRESENT      the item's content is located in the summary   -> attribute
  ABSENT       the summary demonstrably covers the cluster and this item's
               content is not in it                            -> exclude
  UNLOCATABLE  we cannot tell                                  -> attribute

Because UNLOCATABLE resolves to attribute, a true contributor is never
dropped for want of evidence. Soundness comes from the construction, not from
tuning. And it costs no model calls: the summary already exists, and locating
content in it is string work.

WHAT DECIDES WHETHER IT IS USEFUL. If most items land in UNLOCATABLE the
method degenerates to whole-cluster propagation. That is still sound and still
free, but it is no better than the coarse baseline, and the paper must say so.
The gate is set in advance: below `--useful-rate` located items, we report it
as degenerate rather than as a contribution.

WHAT THIS CANNOT SHOW. An item can shape a summary's phrasing while leaving no
locatable trace. Such an item is a true contributor that we classify
UNLOCATABLE, so it is attributed and the guarantee holds; it just costs
precision. We report the rate so the reader can see how much.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import re
import statistics as st
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from harness.observe_q1 import (OFFTOPIC, ONTOPIC, TASK, key_token,
                                make_cluster, summarise, _check_pools)


def locate(item_text: str, summary: str):
    """Classify one item against a summary.

    Returns "present", "absent", or "unlocatable". The three-way split is the
    whole point: an earlier version of this measurement had only two classes,
    which silently folded "we could not tell" into "not a contributor" and so
    manufactured exactly the confidence the method must not have.
    """
    tok = key_token(item_text)
    if not tok:
        # no identifier to search for; we genuinely cannot tell
        return "unlocatable"
    if tok in summary:
        return "present"
    # The identifier is missing. That is evidence of absence only if the
    # summary preserves identifiers at all. If the summary carries no
    # identifiers whatsoever, it has paraphrased past our ability to check
    # and we must not read the absence as exclusion.
    if not re.search(r"\b\d{4}\b", summary):
        return "unlocatable"
    return "absent"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://localhost:8000/v1")
    ap.add_argument("--api-key-env", default="VLLM_KEY")
    ap.add_argument("--model", required=True)
    ap.add_argument("--clusters", type=int, default=60)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--useful-rate", type=float, default=0.60,
                    help="below this fraction of locatable items the method "
                         "is reported as degenerate, not as a contribution")
    ap.add_argument("--out", default="results/grounded.json")
    a = ap.parse_args()
    key = os.environ.get(a.api_key_env, "local")
    _check_pools()

    mixes = [(4, 2), (3, 3), (2, 4)]
    obs = []
    total = len(mixes) * a.clusters
    print(f"{total} clusters. One summary per cluster, no probing calls.\n")

    done = 0
    for n_on, n_off in mixes:
        for c in range(a.clusters):
            rng = random.Random(f"{a.seed}|{n_on}|{n_off}|{c}")
            items = make_cluster(rng, n_on, n_off)
            s = summarise(a.base_url, a.model, key, items)
            rows = [{"role": it["role"], "text": it["text"],
                     "verdict": locate(it["text"], s)} for it in items]
            obs.append({"n_on": n_on, "n_off": n_off, "cluster": c,
                        "summary": s, "items": rows})
            done += 1
            if done % 30 == 0:
                print(f"  {done}/{total}")

    items = [it for o in obs for it in o["items"]]
    n = len(items)
    counts = {v: sum(1 for i in items if i["verdict"] == v)
              for v in ("present", "absent", "unlocatable")}
    attributed = counts["present"] + counts["unlocatable"]

    print("\n" + "=" * 68)
    print("Content-grounded attribution")
    print("=" * 68)
    for v in ("present", "absent", "unlocatable"):
        print(f"  {v:12} {counts[v]:5}  {100*counts[v]/n:5.1f}%")
    print(f"\n  attributed (present + unlocatable): {100*attributed/n:.1f}%")
    print(f"  whole-cluster attributes           : 100.0%")
    print(f"  extra model calls                  : 0 "
          f"(leave-one-out needs one per item)")

    # Soundness check. An earlier version asked whether any ON-TOPIC item
    # was excluded, assuming on-topic implies contributor. It does not: the
    # summary has a word budget, the summariser selects a few items from the
    # cluster, and an on-topic item it did not select genuinely contributed
    # nothing. That gate was measuring selection, not soundness, and it
    # reported 4.4% "false negatives" that were correct exclusions.
    #
    # Soundness requires only this: no item whose content reached the summary
    # may be excluded. By construction of `locate` an item is excluded only
    # when its identifier is absent from a summary that preserves
    # identifiers, so this should be zero, and we check rather than assume.
    violations = 0
    for o in obs:
        for it in o["items"]:
            tok = key_token(it["text"])
            if tok and tok in o["summary"] and it["verdict"] == "absent":
                violations += 1
    print(f"\n  items in the summary yet excluded: {violations}")
    print("    This is the false-negative count that matters. An item whose")
    print("    content reached the summary contributed to it, so excluding")
    print("    it drops a real ancestor from the meet.")

    on = [i for i in items if i["role"] == "ontopic"]
    on_excluded = sum(1 for i in on if i["verdict"] == "absent")
    print(f"\n  on-topic items excluded: {on_excluded}/{len(on)} "
          f"({100*on_excluded/max(len(on),1):.1f}%)")
    print("    Reported for context, not as errors: the summary has a word")
    print("    budget, so an on-topic item the summariser did not select")
    print("    contributed nothing and is correctly excluded.")
    dropped_on = violations

    print("\n" + "=" * 68)
    located = 1 - counts["unlocatable"] / n
    if located < a.useful_rate:
        print(f"DEGENERATE. Only {100*located:.0f}% of items are locatable, so")
        print("the method attributes nearly everything and is no better than")
        print("whole-cluster propagation. It remains sound and free, which is")
        print("more than leave-one-out manages, but it is not a contribution")
        print("on this workload and should not be presented as one.")
    elif dropped_on > 0:
        print(f"NOT SOUND HERE. {dropped_on} on-topic items were excluded, so")
        print("the construction argument fails on this workload: the locate")
        print("step is confident when it should not be. Tighten `locate` so")
        print("that ambiguity resolves to unlocatable, and re-measure.")
    else:
        print(f"SOUND AND SELECTIVE. Attributes {100*attributed/n:.0f}% against")
        print("whole-cluster's 100%, drops no true contributor, and costs no")
        print("model calls where leave-one-out costs one per item.")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump({"config": vars(a), "counts": counts, "n": n,
               "attributed_rate": attributed / n,
               "ontopic_excluded": dropped_on, "ontopic_n": len(on),
               "observations": obs}, open(a.out, "w"), indent=1)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
