#!/usr/bin/env python3
"""Storage amplification against horizon, not as a constant.

    python harness/run_storage.py --horizon 200

The $2.77\\times$ figure in the body is measured at the start of a run and is
the wrong shape to report. An item's side-table record holds its origin set,
which \\cref{alg:compact} builds as a union over the attributed inputs. Unions
are monotone, so the record grows as lineage accumulates and the amplification
is a function of how long the store has been running.

This needs no model. The origin set is determined by the source classes and
the attribution, not by what the compactor writes, so the growth curve is a
property of the labelling system. We use the mock backend and vary the
estimator, because the estimator is what decides how many origins each
summary inherits --- and \\cref{sec:eval:rq6} already shows the two arms
differ sharply on exactly that.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import statistics
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from harness.backends import MockBackend, token_similarity
from harness.workload import make_session, strip_marks
from provenire.compaction import taint_preserving_compaction
from provenire.influence import EstimatorConfig
from provenire.lattice import Item, label_generated


def record_bytes(it: Item) -> int:
    """The side-table record: level, origin set, provenance flag, version."""
    return len(json.dumps({"l": int(it.level), "rho": sorted(it.origins),
                           "pi": int(it.how), "v": 1}).encode())


def run(cfg, horizon, budget, u, m, seed, cluster=4):
    backend = MockBackend()
    rng = random.Random(seed)
    memory: list[Item] = []
    curve = []
    for k in range(horizon):
        spec = make_session(k, rng, untrusted_fraction=u, n_items=m)
        for it in spec.items:
            it.text = strip_marks(it.text)
        for j in range(2):
            memory.append(label_generated(
                f"g{k}_{j}", "note on " + spec.items[j].text[:80], spec.items))
        if len(memory) > budget:
            memory = taint_preserving_compaction(
                memory, backend, regenerator=backend,
                similarity=token_similarity, cfg=cfg).items
            text = sum(len(it.text.encode()) for it in memory)
            side = sum(record_bytes(it) for it in memory)
            origins = statistics.fmean(len(it.origins) for it in memory)
            curve.append({"round": len(curve) + 1, "n": len(memory),
                          "text": text, "side": side,
                          "amp": (text + side) / max(text, 1),
                          "origins": origins})
    return curve


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--horizon", type=int, default=200)
    ap.add_argument("--budget-items", type=int, default=32)
    ap.add_argument("--u", type=float, default=0.20)
    ap.add_argument("--n-items", type=int, default=5)
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--out", default="results/storage_curve.json")
    a = ap.parse_args()

    arms = {
        "leave-one-out": EstimatorConfig(tau=0.15, loo_max_cluster=16),
        "trivial": EstimatorConfig(enable_loo=False),
    }
    out = {"config": vars(a), "arms": {}}

    print("=" * 66)
    print(f"Storage amplification against horizon  (u={a.u}, m={a.n_items})")
    print("=" * 66)

    for name, cfg in arms.items():
        runs = [run(cfg, a.horizon, a.budget_items, a.u, a.n_items, s)
                for s in range(a.seeds)]
        n = min(len(r) for r in runs)
        print(f"\n{name}")
        print(f"{'round':>7}{'items':>7}{'origins/item':>14}"
              f"{'amplification':>15}")
        print("-" * 44)
        rows = []
        for r in range(n):
            amp = statistics.fmean(runs[s][r]["amp"] for s in range(a.seeds))
            org = statistics.fmean(runs[s][r]["origins"]
                                   for s in range(a.seeds))
            it = statistics.fmean(runs[s][r]["n"] for s in range(a.seeds))
            rows.append({"round": r + 1, "amp": amp, "origins": org,
                         "items": it})
            if r < 4 or r == n - 1 or r % max(n // 5, 1) == 0:
                print(f"{r+1:>7}{it:>7.0f}{org:>14.2f}{amp:>14.2f}x")
        out["arms"][name] = rows

    lo = out["arms"]["leave-one-out"]
    tr = out["arms"]["trivial"]
    print()
    print("=" * 66)
    print(f"{'':>16}{'first round':>14}{'last round':>13}{'growth':>10}")
    print("-" * 55)
    for name, rows in (("leave-one-out", lo), ("trivial", tr)):
        print(f"{name:>16}{rows[0]['amp']:>13.2f}x{rows[-1]['amp']:>12.2f}x"
              f"{rows[-1]['amp']/max(rows[0]['amp'],1e-9):>9.2f}x")
    print()
    print("The two arms diverge for the reason Section 6.6 gives: the trivial")
    print("estimator unions every origin in the cluster, so records grow; the")
    print("leave-one-out arm prunes them, so records stay small and lineage")
    print("is lost. Cheaper storage here is the same phenomenon as the lost")
    print("auditability, measured on the other axis.")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(out, open(a.out, "w"), indent=2)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
