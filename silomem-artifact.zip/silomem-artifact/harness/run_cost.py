#!/usr/bin/env python3
"""End-to-end cost over a multi-round trajectory.

    python harness/run_cost.py --model Qwen/Qwen2.5-7B-Instruct

Table 6 gives the call counts analytically: SiloMem pays |M| extraction calls
once, ablation pays r|M| probing calls. That is arithmetic and the paper says
so; this measures it, and measures the three things the arithmetic omits.

  the atomisation ratio     one memory becomes several claims, so SiloMem
                            compacts MORE items than the baseline and the
                            |M|/k term is optimistic by that factor. A first
                            run used single-sentence notes and measured a
                            ratio of exactly 1.00, which is a property of the
                            workload and not of the mechanism: there was
                            nothing to decompose. The default workload is now
                            multi-fact paragraphs.
  tokens rather than calls  an extraction prompt is one memory, a probing
                            prompt is a whole cluster, so calls are not a
                            unit of cost
  wall clock                what a deployment actually pays

The prediction is that SiloMem is cheaper past one round and that the
atomisation ratio eats some of the margin. If the ratio is high enough that
SiloMem loses, that is the finding and Table 6 needs replacing rather than
annotating.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from harness.observe_q1 import ONTOPIC

# Multi-fact memories, so atomisation has something to decompose. The
# single-sentence notes of observe_q1 yield a ratio of exactly 1.00, which
# makes extraction a no-op that still costs a call and measures nothing
# about the mechanism. A real memory is a paragraph.
PARAGRAPHS = [
    "Vendor NORTHWIND submitted invoice {n} on Tuesday for 14,200 against "
    "purchase order 8891. The settlement desk cleared it the same day. "
    "Payment terms are net 30 and the remittance advice has not yet been "
    "matched.",
    "Ledger entry {n} was reconciled against the vendor statement and a "
    "variance of 340 was written off to the tolerance account. The "
    "controller approved the write-off. The vendor was not notified.",
    "Payment run {n} covered 47 invoices totalling 1.1 million. Two were "
    "held for missing approvals and released the following morning. The "
    "bank confirmed settlement at 14:20.",
    "Credit note {n} was applied against the outstanding balance for "
    "vendor ACME, reducing it to 2,150. The note originated from a "
    "disputed shipment in March. The dispute is now closed.",
]
from harness.probe_grounded_fn import check_server

EXTRACT = ("Extract the distinct factual claims from the note below, one per "
           "line, each a short sentence. Claims only.\n\nNote: {m}")


class Meter:
    """Counts calls, prompt tokens and completion tokens. vLLM returns usage
    on every response, so this is measured rather than estimated."""

    def __init__(self):
        self.calls = self.prompt = self.completion = 0
        self.seconds = 0.0

    def post(self, url, model, key, prompt, max_tokens=90):
        import httpx
        t0 = time.time()
        r = httpx.post(f"{url}/chat/completions", timeout=180,
                       headers={"Authorization": f"Bearer {key}"},
                       json={"model": model, "max_tokens": max_tokens,
                             "temperature": 0.0,
                             "messages": [{"role": "user",
                                           "content": prompt}]})
        r.raise_for_status()
        self.seconds += time.time() - t0
        d = r.json()
        u = d.get("usage") or {}
        self.calls += 1
        self.prompt += u.get("prompt_tokens", 0)
        self.completion += u.get("completion_tokens", 0)
        return d["choices"][0]["message"]["content"].strip()

    def row(self, name, items):
        return {"rule": name, "calls": self.calls,
                "prompt_tokens": self.prompt,
                "completion_tokens": self.completion,
                "seconds": round(self.seconds, 1),
                "items_after": items}


def summ_prompt(texts):
    return ("Summarise these notes in ONE entry of at most 40 words. "
            "Entry only.\n" + "\n".join("- " + t for t in texts))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://localhost:8000/v1")
    ap.add_argument("--api-key-env", default="VLLM_KEY")
    ap.add_argument("--model", required=True)
    ap.add_argument("--store", type=int, default=60)
    ap.add_argument("--cluster-size", type=int, default=3)
    ap.add_argument("--rounds", type=int, default=4)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--paragraphs", action="store_true", default=True,
                    help="use multi-fact memories so atomisation has "
                         "something to decompose; --no-paragraphs "
                         "reproduces the ratio-1.00 run")
    ap.add_argument("--no-paragraphs", dest="paragraphs",
                    action="store_false")
    ap.add_argument("--out", default="results/cost.json")
    a = ap.parse_args()
    key = os.environ.get(a.api_key_env, "local")
    check_server(a.base_url, a.model, key)
    k = a.cluster_size
    rng = random.Random(a.seed)
    pool = PARAGRAPHS if a.paragraphs else ONTOPIC
    base = [t.format(n=rng.randint(1000, 9999))
            for t in rng.choices(pool, k=a.store)]

    print(f"store {a.store}, cluster {k}, {a.rounds} rounds\n")
    rows = []

    # whole-cluster: compaction only
    m = Meter(); items = list(base)
    for _ in range(a.rounds):
        if len(items) <= 1: break
        items = [m.post(a.base_url, a.model, key,
                        summ_prompt(items[i:i+k]))
                 for i in range(0, len(items), k)]
    rows.append(m.row("whole-cluster", len(items)))

    # ablation: one probe per item per round, on top of compaction
    m = Meter(); items = list(base)
    for _ in range(a.rounds):
        if len(items) <= 1: break
        nxt = []
        for i in range(0, len(items), k):
            cl = items[i:i+k]
            s = m.post(a.base_url, a.model, key, summ_prompt(cl))
            for j in range(len(cl)):
                rest = cl[:j] + cl[j+1:]
                if rest:
                    m.post(a.base_url, a.model, key, summ_prompt(rest))
            nxt.append(s)
        items = nxt
    rows.append(m.row("ablation", len(items)))

    # silomem: extraction once, then compaction over the claims
    m = Meter()
    claims = []
    for t in base:
        out = m.post(a.base_url, a.model, key, EXTRACT.format(m=t),
                     max_tokens=140)
        claims += [l.strip(" -*\t") for l in out.split("\n")
                   if l.strip(" -*\t")]
    ratio = len(claims) / len(base)
    items = claims
    for _ in range(a.rounds):
        if len(items) <= 1: break
        items = [m.post(a.base_url, a.model, key, summ_prompt(items[i:i+k]))
                 for i in range(0, len(items), k)]
    r = m.row("silomem", len(items)); r["atomisation_ratio"] = round(ratio, 2)
    rows.append(r)

    print(f"{'rule':>14}{'calls':>8}{'prompt tok':>12}{'compl tok':>11}"
          f"{'sec':>8}{'items':>7}")
    print("-" * 60)
    for r in rows:
        print(f"{r['rule']:>14}{r['calls']:>8}{r['prompt_tokens']:>12}"
              f"{r['completion_tokens']:>11}{r['seconds']:>8.0f}"
              f"{r['items_after']:>7}")
    print(f"\natomisation ratio: {ratio:.2f} claims per memory")
    if ratio < 1.3:
        print("  RATIO NEAR 1: extraction is a no-op on this workload, so it")
        print("  costs a call and measures nothing about the mechanism. The")
        print("  figures below bound SiloMem's cost from BELOW. Use")
        print("  --paragraphs, or a workload whose memories carry several")
        print("  facts, before reading the comparison as representative.")

    w, ab, si = rows[0], rows[1], rows[2]
    print("\n" + "=" * 60)
    tot = lambda r: r["prompt_tokens"] + r["completion_tokens"]
    print(f"tokens: whole {tot(w)}, ablation {tot(ab)}, silomem {tot(si)}")
    if tot(si) < tot(ab):
        print(f"SiloMem costs {tot(ab)/max(tot(si),1):.1f}x fewer tokens than")
        print("ablation over this horizon; extraction is paid once and")
        print("probing is paid every round.")
    else:
        print("SILOMEM COSTS MORE THAN ABLATION here. The atomisation ratio")
        print(f"of {ratio:.2f} multiplied the items it must compact, and that")
        print("outweighs the probing it avoids. Table 6 is arithmetic that")
        print("ignores this term and needs replacing, not annotating.")
    if tot(si) > tot(w):
        print(f"\nAgainst the baseline SiloMem costs {tot(si)/max(tot(w),1):.1f}x more")
        print("tokens, which is the price of atomisation and is not")
        print("recovered at any horizon, since whole-cluster pays nothing")
        print("beyond compaction.")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump({"config": vars(a), "rows": rows,
               "atomisation_ratio": ratio}, open(a.out, "w"), indent=1)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
