#!/usr/bin/env python3
"""Is controlled exposure actually more selective than the coarse baseline?

    python harness/run_selectivity.py --model Qwen/Qwen2.5-7B-Instruct

Theorem 1 settles security by construction, so the question that decides
whether SiloMem is worth building is this one. A design that labels everything
untrusted satisfies the theorem and is useless. Selectivity has to be measured,
and it is the one result the paper cannot claim without.

WHAT IS BEING COMPARED, over the same store and the same number of rounds:

  whole-cluster   cluster freely, meet over the whole cluster
  ablation        cluster freely, meet over an estimated subset, one model
                  call per item per round
  silomem         atomise per memory, route non-interferingly, meet over
                  each bucket's recorded read set

The metric is the fraction of the store that is labelled untrusted after n
compaction rounds. Lower is better, provided the labels are also correct,
which for whole-cluster and silomem is guaranteed and for ablation is not.

SATURATION IS STRUCTURAL AND THE FIRST VERSION OF THIS EXPERIMENT MISSED IT.
A cluster is tainted if any of its k items is, so after one round the tainted
fraction is 1-(1-p)^k for an untrusted fraction p. At p=0.25 and k=5 that is
0.76 after one round and 1.00 after two. EVERY rule that propagates a meet
over its read set saturates, SiloMem included, and the theorem does not
prevent it: Section 4.6 says exactly that it does not bound over-tainting.

So "is SiloMem more selective" is badly posed at fixed p. Every rule reaches
100% eventually and the only question is when. This measures the KNEE: the
untrusted fraction at which each rule crosses a usability threshold, and how
that moves with the read-set size. A smaller read set should push the knee
right, and by how much is the number that decides whether the architecture
earns itself.

READ THE ITEMS COLUMN FIRST. A store that has bottomed out to single digits
reports a tainted fraction quantised in steps of 1/n, and the first run of
this experiment compacted 120 items to 5 and reported 83% against 90%, which
is one item. Parameters must leave enough items after the last round for a
percentage to mean anything.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from harness.observe_grounded import locate
from harness.observe_q1 import ONTOPIC, key_token, summarise
from harness.probe_grounded_fn import check_server
from provenire.lattice import TRUSTED_POOL as T
from provenire.lattice import UNTRUSTED_POOL as U

# A fixed taxonomy over this workload's vocabulary. bucket(f) depends on f
# alone, which is Eq. (4). The terms were chosen by checking the spread: a
# first version used the bucket names themselves as keywords and dropped 4 of
# 6 templates into `other`, which would have made SiloMem identical to
# whole-cluster and the experiment vacuous. A router that does not spread the
# workload measures nothing, so the spread is asserted below.
BUCKETS = ("settlement", "ledger", "approval", "remittance", "other")
_TERMS = {
    "settlement": ("settlement", "cleared", "invoice"),
    "ledger":     ("ledger", "reconcil", "statement"),
    "approval":   ("approval", "approved", "controller", "authoris"),
    "remittance": ("remittance", "payable", "payment run", "matched"),
}


def bucket_of(text):
    """Non-interfering router: a function of the claim alone."""
    t = text.lower()
    for b in BUCKETS[:-1]:
        if any(term in t for term in _TERMS[b]):
            return b
    return "other"


def _check_router_spreads(items):
    """A router that puts everything in one bucket makes SiloMem identical to
    whole-cluster. Refuse to run rather than report a null result caused by
    the router."""
    from collections import Counter
    c = Counter(bucket_of(x["text"]) for x in items)
    if c.most_common(1)[0][1] > 0.6 * len(items):
        raise SystemExit(
            f"router puts {c.most_common(1)[0][1]}/{len(items)} items in one "
            f"bucket: {dict(c)}\nSiloMem would be whole-cluster and the "
            "comparison would be vacuous. Fix _TERMS for this workload.")
    return c


def make_store(rng, n, frac_untrusted):
    items = []
    for _ in range(n):
        u = rng.random() < frac_untrusted
        items.append({"label": U if u else T,
                      "text": rng.choice(ONTOPIC).format(
                          n=rng.randint(1000, 9999))})
    return items


def round_whole(items, k, url, model, key):
    from harness.observe_q1 import summarise_many
    cls = [items[i:i + k] for i in range(0, len(items), k)]
    texts = summarise_many(url, model, key,
                           [[{"text": x["text"]} for x in cl] for cl in cls])
    out = [{"label": U if any(x["label"] == U for x in cl) else T, "text": t}
           for cl, t in zip(cls, texts)]
    return out, 0


def round_ablation(items, k, url, model, key, tau=0.18):
    """One model call per item, then meet over the attributed subset.

    This is the most expensive rule in the paper by construction: k+1 calls
    per cluster where the others need one. Issuing them sequentially is what
    made the sweep take hours, so every call for the whole round is queued
    at once. The cost the paper REPORTS is unchanged -- `calls` still counts
    one probe per item -- because that number is about what a deployment
    pays, not about how fast a benchmark runs.
    """
    from harness.observe_q1 import summarise_many
    cls = [items[i:i + k] for i in range(0, len(items), k)]

    # every prompt for the round: the cluster summary, then each leave-one-out
    jobs, index = [], []
    for ci, cl in enumerate(cls):
        index.append(("full", ci, None))
        jobs.append([{"text": x["text"]} for x in cl])
        for xi, x in enumerate(cl):
            rest = [{"text": y["text"]} for y in cl if y is not x]
            if rest:
                index.append(("loo", ci, xi))
                jobs.append(rest)
    texts = summarise_many(url, model, key, jobs)

    full = {}
    loo = {}
    for (kind, ci, xi), t in zip(index, texts):
        if kind == "full":
            full[ci] = t
        else:
            loo[(ci, xi)] = t

    out, calls = [], 0
    for ci, cl in enumerate(cls):
        s = full[ci]
        attributed = []
        for xi, x in enumerate(cl):
            s2 = loo.get((ci, xi), "")
            calls += 1
            a, b = set(s.split()), set(s2.split())
            d = 1 - len(a & b) / max(len(a | b), 1)
            if d > tau:
                attributed.append(x)
        pool = attributed or cl          # empty estimate falls back to all
        out.append({"label": U if any(x["label"] == U for x in pool) else T,
                    "text": s})
    return out, calls


def round_silomem(items, k, url, model, key, separated=False):
    """Route by a non-interfering function, compact each bucket over its
    recorded read set.

    With `separated`, bucket(f) = (topic(f), label(f)) per Eq. (3), so a
    compaction call never mixes labels and the trusted compartment is
    produced by calls that never saw an untrusted claim. Eq. (7) predicts
    its tainted fraction is zero at every round; THIS IS THE EXPERIMENT
    THAT TESTS IT at the scale Table 12 reports, which the paper currently
    cannot show because these runs predate the mechanism.
    """
    groups = {}
    for x in items:
        b = bucket_of(x["text"])
        groups.setdefault((b, x["label"]) if separated else b, []).append(x)
    # Collect every read set first, then compact them together. They are
    # independent by construction, and issuing them one at a time left the
    # card idle between calls: a sweep that should take minutes took hours.
    read_sets = []
    for b, pool in groups.items():
        for i in range(0, len(pool), k):
            read_sets.append(pool[i:i + k])   # recorded, not estimated
    from harness.observe_q1 import summarise_many
    texts = summarise_many(url, model, key,
                           [[{"text": x["text"]} for x in rs]
                            for rs in read_sets])
    out = [{"label": U if any(x["label"] == U for x in rs) else T,
            "text": t}
           for rs, t in zip(read_sets, texts)]
    return out, 0


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://localhost:8000/v1")
    ap.add_argument("--api-key-env", default="VLLM_KEY")
    ap.add_argument("--model", required=True)
    ap.add_argument("--separated", action="store_true",
                    help="route on (topic, label) per Eq. (3) and report the "
                         "trusted compartment separately. Without this the "
                         "run reproduces Table 12, which predates the "
                         "mechanism the paper now turns on.")
    ap.add_argument("--store", type=int, default=600)
    ap.add_argument("--cluster-size", type=int, default=3)
    ap.add_argument("--rounds", type=int, default=2)
    ap.add_argument("--fracs", default="0.01,0.02,0.05,0.10,0.20",
                    help="sweep p to find the knee; a single p answers "
                         "nothing because every rule saturates")
    ap.add_argument("--seeds", type=int, default=2)
    ap.add_argument("--usable", type=float, default=0.50,
                    help="tainted fraction above which the store is called "
                         "unusable; the knee is where each rule crosses it")
    ap.add_argument("--out", default="results/selectivity.json")
    a = ap.parse_args()
    key = os.environ.get(a.api_key_env, "local")
    check_server(a.base_url, a.model, key)

    fracs = [float(x) for x in a.fracs.split(",")]
    rules = (("whole-cluster", round_whole),
             ("ablation", round_ablation),
             ("silomem", round_silomem))

    print(f"store {a.store}, cluster {a.cluster_size}, {a.rounds} rounds, "
          f"{a.seeds} seeds\n")
    print(f"{'untrusted':>10}{'rule':>15}{'items':>7}{'tainted':>9}"
          f"{'calls':>8}")
    print("-" * 50)
    out = {"config": vars(a), "rows": []}

    for frac in fracs:
        for name, fn in rules:
            taints, sizes, calls = [], [], []
            for seed in range(a.seeds):
                rng = random.Random(f"sel|{seed}|{frac}")
                items = make_store(rng, a.store, frac)
                if name == "silomem" and seed == 0:
                    spread = _check_router_spreads(items)
                    if frac == fracs[0]:
                        print(f"  router spread: {dict(spread)}")
                c = 0
                for _ in range(a.rounds):
                    if len(items) <= 1:
                        break
                    if name == "silomem" and a.separated:
                        items, ci = fn(items, a.cluster_size, a.base_url,
                                       a.model, key, separated=True)
                    else:
                        items, ci = fn(items, a.cluster_size, a.base_url,
                                       a.model, key)
                    c += ci
                taints.append(sum(1 for x in items if x["label"] == U)
                              / max(len(items), 1))
                sizes.append(len(items))
                calls.append(c)
            mt = sum(taints) / len(taints)
            # Under Eq. (3) the trusted compartment is the half a deployment
            # keeps using, and Eq. (7) says its tainted fraction is zero at
            # every round. Reporting only the store-wide figure hides that:
            # the untrusted compartment saturates immediately and correctly,
            # and averaging the two together makes a working separation look
            # like a failing one.
            if name == "silomem" and a.separated:
                # The useful quantity is how much of the store a deployment
                # can still act on, and how close the untrusted share stays
                # to p. Eq. (7) says separation keeps the second at p rather
                # than letting it grow by 1-(1-p)^k.
                #
                # AN EARLIER VERSION PRINTED A TAUTOLOGY HERE: it selected
                # the items labelled T and reported what fraction of them
                # were labelled U, which is zero by definition. It would
                # have gone into the paper as evidence for Eq. (7).
                usable = 1 - mt
                drift = mt - frac
                print(f"{'':>10}{'  usable share':>15}{'':>7}"
                      f"{100*usable:>8.0f}%{'':>8}")
                print(f"{'':>10}{'  above p by':>15}{'':>7}"
                      f"{100*drift:>+8.0f}%{'':>8}")
            print(f"{frac:>10.2f}{name:>15}{sum(sizes)/len(sizes):>7.0f}"
                  f"{100*mt:>8.0f}%{sum(calls)/len(calls):>8.0f}")
            out["rows"].append({"frac": frac, "rule": name,
                                "items": sum(sizes) / len(sizes),
                                "tainted": mt,
                                "calls": sum(calls) / len(calls)})
        print()

    print("=" * 50)
    small = [r for r in out["rows"] if r["items"] < 20]
    if small:
        print(f"UNREADABLE: {len(small)} configurations left fewer than 20")
        print("items after the last round, so the tainted fraction is")
        print("quantised too coarsely to compare. Raise --store, lower")
        print("--rounds, or lower --cluster-size, and rerun.")
    else:
        print("The knee: lowest untrusted fraction at which each rule's")
        print(f"tainted share exceeds {100*a.usable:.0f}%.")
        print()
        for rule in ("whole-cluster", "ablation", "silomem"):
            pts = sorted((x["frac"], x["tainted"]) for x in out["rows"]
                         if x["rule"] == rule)
            knee = next((f for f, t in pts if t > a.usable), None)
            if knee is None:
                print(f"  {rule:>14}: never crosses over the range tested")
            else:
                print(f"  {rule:>14}: crosses at p = {knee}")
        print()
        print("A rule whose knee sits at a higher p tolerates a dirtier")
        print("store before becoming useless. If SiloMem's knee is not to")
        print("the right of whole-cluster's, controlled exposure is not")
        print("buying selectivity and the paper cannot claim it does.")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(out, open(a.out, "w"), indent=1)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
