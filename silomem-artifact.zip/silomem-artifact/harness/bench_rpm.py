#!/usr/bin/env python3
"""Measure the SUSTAINABLE request rate of an endpoint, by pushing it.

For this evaluation the binding constraint is requests per minute, not price
and not latency. 7,500 calls at 30 RPM is 4.2 hours of mostly waiting; the
same calls at 300 RPM is 25 minutes. Published limits go stale and differ by
tier, so measure rather than read.

    python harness/bench_rpm.py --backend groq --model openai/gpt-oss-20b
    python harness/bench_rpm.py --base-url https://api.lambda.ai/v1 \\
        --api-key-env LAMBDA_API_KEY --model <tag>

It fires a burst, counts 429s, and reports the rate you can actually hold.
Costs a few cents at most.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

PRESETS = {
    "groq":   ("https://api.groq.com/openai/v1", "GROQ_API_KEY"),
    "lambda": ("https://api.lambda.ai/v1", "LAMBDA_API_KEY"),
    "gemini": ("https://generativelanguage.googleapis.com/v1beta/openai",
               "GEMINI_API_KEY"),
    "openai": ("https://api.openai.com/v1", "OPENAI_API_KEY"),
    "local":  ("http://localhost:8000/v1", "LOCAL_KEY"),   # vLLM default
    "ollama": ("http://localhost:11434/v1", "OLLAMA_KEY"),
}

PROMPT = ("Merge into ONE entry of at most 30 words, entry only:\n"
          "- invoice 4417 approved 12 March\n"
          "- vendor net-30 terms confirmed\n"
          "- file documents in the shared drive")


def one(url, model, key, timeout=120):
    import httpx
    t0 = time.perf_counter()
    try:
        r = httpx.post(f"{url}/chat/completions",
                       headers={"Authorization": f"Bearer {key}"},
                       json={"model": model,
                             "messages": [{"role": "user", "content": PROMPT}],
                             "temperature": 0.0, "max_tokens": 64},
                       timeout=timeout)
    except Exception as e:  # noqa: BLE001
        return ("error", time.perf_counter() - t0, str(e)[:80])
    dt = time.perf_counter() - t0
    if r.status_code == 429:
        m = re.search(r"try again in ([0-9.]+)\s*s", r.text)
        return ("429", dt, m.group(1) if m else r.headers.get("retry-after", "?"))
    if r.status_code >= 400:
        return ("error", dt, f"HTTP {r.status_code}: {r.text[:80]}")
    return ("ok", dt, r.json().get("usage", {}).get("completion_tokens", 0))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--backend", choices=sorted(PRESETS), default=None)
    ap.add_argument("--base-url", default=None)
    ap.add_argument("--api-key-env", default=None)
    ap.add_argument("--model", required=True)
    ap.add_argument("--burst", type=int, default=40)
    ap.add_argument("--parallel", type=int, default=8)
    ap.add_argument("--grid-calls", type=int, default=7500)
    a = ap.parse_args()

    url, env = PRESETS.get(a.backend, (None, None))
    url = a.base_url or url
    env = a.api_key_env or env
    if not url:
        print("give --backend or --base-url"); sys.exit(2)
    key = os.environ.get(env or "", "local")
    if env and not os.environ.get(env):
        print(f"warning: {env} is unset")

    print("=" * 66)
    print(f"{a.model} at {url}")
    print(f"firing {a.burst} requests, {a.parallel} at a time")
    print("=" * 66)

    t0 = time.perf_counter()
    with cf.ThreadPoolExecutor(max_workers=a.parallel) as ex:
        res = list(ex.map(lambda _: one(url, a.model, key), range(a.burst)))
    wall = time.perf_counter() - t0

    ok = [r for r in res if r[0] == "ok"]
    lim = [r for r in res if r[0] == "429"]
    err = [r for r in res if r[0] == "error"]

    print()
    print(f"  succeeded   {len(ok):>4}")
    print(f"  rate-limited{len(lim):>4}")
    print(f"  errors      {len(err):>4}")
    if err:
        print(f"    first: {err[0][2]}")
    if not ok:
        print("\nnothing succeeded; check the model tag and the key.")
        sys.exit(1)

    lat = sorted(r[1] for r in ok)
    print(f"  latency p50 {lat[len(lat)//2]:>6.2f}s   p95 "
          f"{lat[int(len(lat)*0.95)-1]:>6.2f}s")
    rate = len(ok) / wall
    print(f"  achieved    {rate*60:>6.1f} requests/min")

    if lim:
        print()
        print(f"  hit the limit after {len(ok)} requests in {wall:.0f}s.")
        print(f"  server said to wait: {lim[0][2]}s")
        print("  the sustainable rate is below what this burst attempted;")
        print("  re-run with a smaller --parallel to find the ceiling.")

    print()
    hrs = a.grid_calls / max(rate, 1e-9) / 3600
    print(f"{a.grid_calls:,} calls at this rate: {hrs:.1f} h")
    if hrs < 0.5:
        print("  -> no constraint. Run the full grid.")
    elif hrs < 3:
        print("  -> fine. Run it in screen.")
    else:
        print("  -> the rate limit dominates. A cheaper model will not help;")
        print("     RPM is per request, not per token. Options: a paid tier,")
        print("     or rent a GPU and serve it yourself with vLLM, which has")
        print("     no rate limit at all.")


if __name__ == "__main__":
    main()
