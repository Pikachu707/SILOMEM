#!/usr/bin/env python3
"""Does the leave-one-out distance track whether an item shaped the summary?

    python harness/observe_q1.py --model Qwen/Qwen2.5-7B-Instruct

WHY THIS EXISTS SEPARATELY. harness/observe.py cannot answer this question,
because in its generator an item's length and its survival into the summary
are the same variable: short items are one sentence and their key token always
survives, long items are two and often lose it. The apparent finding there
(AUC 0.16, the distance running backwards) is inseparable from the fact that
withholding a long item removes more text. The correlation between distance
and item length was +0.52, and every short item survived, so there were zero
negatives in that stratum.

Here length is held fixed and survival is varied by RELEVANCE instead. Each
item is one sentence of comparable length; on-topic items are about the
cluster's subject and a summariser keeps them, off-topic items are about
something else and it drops them. So an item's chance of shaping the summary
varies while the amount of text withheld does not.

The design is checked before it is used: the script reports the length
difference between surviving and dropped items and refuses to report an AUC
if the two groups differ in length by more than a tolerance, because that
would put us back where observe.py was.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import re
import statistics as st
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from harness.backends import token_similarity

# Every line is one clause of similar length. The difference is subject, not
# size: an invoice-triage summary keeps the finance lines and drops the rest.
ONTOPIC = [
    "invoice {n} was cleared by the settlement desk on Tuesday",
    "payment run {n} received controller approval this morning",
    "ledger entry {n} reconciled against the vendor statement",
    "remittance advice {n} was matched to the open payable",
    "credit note {n} was applied to the outstanding balance",
    "purchase order {n} was closed after final invoicing",
]
OFFTOPIC = [
    "the cafeteria menu {n} rotates to winter options on Tuesday",
    "parking permit {n} renewals open at the start of the month",
    "the fire drill for building {n} is scheduled for Thursday",
    "office plants on floor {n} are watered on alternate weekdays",
    "the staff photography club meets in room {n} after hours",
    "recycling collection for bin {n} moves to an earlier slot",
]
TASK = ("Summarise these notes for an invoice-triage agent in ONE entry of at "
        "most 40 words. Keep what matters for handling invoices. Entry only.\n")


def key_token(text: str) -> str:
    m = re.search(r"\b\d{4}\b", text)
    return m.group(0) if m else ""


def _check_pools():
    """Every template must carry an extractable token, or its survival is
    unmeasurable and it counts as dropped by default, which manufactures the
    very asymmetry this experiment is testing for."""
    bad = [t for t in ONTOPIC + OFFTOPIC if not key_token(t.format(n=1234))]
    if bad:
        raise SystemExit("templates with no key token:\n  "
                         + "\n  ".join(bad))


def make_cluster(rng, n_on, n_off):
    items = []
    for pool, role, k in ((ONTOPIC, "ontopic", n_on),
                          (OFFTOPIC, "offtopic", n_off)):
        for t in rng.sample(pool, min(k, len(pool))):
            items.append({"role": role,
                          "text": t.format(n=rng.randint(1000, 9999))})
    rng.shuffle(items)
    return items


def summarise(url, model, key, items):
    import httpx
    r = httpx.post(f"{url}/chat/completions", timeout=180,
                   headers={"Authorization": f"Bearer {key}"},
                   json={"model": model, "max_tokens": 90, "temperature": 0.0,
                         "messages": [{"role": "user", "content":
                             TASK + "\n".join("- " + i["text"]
                                              for i in items)}]})
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"].strip()


def auc(pos, neg):
    if not pos or not neg:
        return None
    p = len(pos) * len(neg)
    w = (sum(1 for a in pos for b in neg if a > b)
         + 0.5 * sum(1 for a in pos for b in neg if a == b))
    return w / p


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://localhost:8000/v1")
    ap.add_argument("--api-key-env", default="VLLM_KEY")
    ap.add_argument("--model", required=True)
    ap.add_argument("--clusters", type=int, default=60)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--length-tolerance", type=float, default=8.0,
                    help="max mean char difference between surviving and "
                         "dropped items before the AUC is refused")
    ap.add_argument("--out", default="results/q1.json")
    a = ap.parse_args()
    key = os.environ.get(a.api_key_env, "local")
    _check_pools()

    mixes = [(4, 2), (3, 3), (2, 4)]
    obs = []
    total = len(mixes) * a.clusters
    print(f"{total} clusters, length held fixed, survival varied by topic\n")

    done = 0
    for n_on, n_off in mixes:
        for c in range(a.clusters):
            rng = random.Random(f"{a.seed}|{n_on}|{n_off}|{c}")
            items = make_cluster(rng, n_on, n_off)
            s = summarise(a.base_url, a.model, key, items)
            rows = []
            for i, it in enumerate(items):
                alt = summarise(a.base_url, a.model, key,
                                items[:i] + items[i + 1:])
                tok = key_token(it["text"])
                rows.append({"role": it["role"],
                             "distance": 1.0 - token_similarity(s, alt),
                             "alt": alt,          # so similarity can be
                             "text": it["text"],  # recomputed offline
                             "in_summary": bool(tok) and tok in s,
                             "chars": len(it["text"])})
            obs.append({"n_on": n_on, "n_off": n_off, "cluster": c,
                        "summary": s, "items": rows})
            done += 1
            if done % 20 == 0:
                print(f"  {done}/{total}")

    items = [it for o in obs for it in o["items"]]
    inn = [it for it in items if it["in_summary"]]
    out = [it for it in items if not it["in_summary"]]

    print("\n" + "=" * 66)
    print("Design check, before any result")
    print("=" * 66)
    li = st.fmean(i["chars"] for i in inn) if inn else float("nan")
    lo = st.fmean(i["chars"] for i in out) if out else float("nan")
    print(f"  survived  n={len(inn):4}  mean {li:.1f} chars")
    print(f"  dropped   n={len(out):4}  mean {lo:.1f} chars")
    print(f"  difference {abs(li-lo):.1f} chars "
          f"(tolerance {a.length_tolerance})")
    ok = inn and out and abs(li - lo) <= a.length_tolerance

    print("\n" + "=" * 66)
    print("Q1  does distance track contribution?")
    print("=" * 66)
    if not ok:
        print("  DESIGN CHECK FAILED. Surviving and dropped items differ in")
        print("  length by more than the tolerance, so distance and survival")
        print("  are confounded exactly as they were in observe.py. No AUC is")
        print("  reported; fix the generator instead of reading a number.")
    else:
        di = [i["distance"] for i in inn]
        do = [i["distance"] for i in out]
        A = auc(di, do)
        print(f"  survived: mean d {st.fmean(di):.3f}")
        print(f"  dropped : mean d {st.fmean(do):.3f}")
        print(f"  AUC = {A:.3f}")
        print()
        if A is None:
            print("  one group empty; nothing to compare")
        elif A > 0.65:
            print("  The estimator works: items that shaped the summary do")
            print("  move it more when withheld. The high false-positive rate")
            print("  seen earlier is a threshold-placement problem.")
        elif A < 0.35:
            print("  The estimator is INVERTED. Items that shaped the summary")
            print("  move it LESS when withheld than items it discarded. Every")
            print("  label is then a meet over a set that systematically")
            print("  excludes the true contributors, with no adversary needed.")
        else:
            print("  No discriminative power either way. The distance carries")
            print("  essentially no information about contribution, so the")
            print("  attributed set is close to arbitrary.")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump({"config": vars(a), "observations": obs}, open(a.out, "w"),
              indent=1)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
