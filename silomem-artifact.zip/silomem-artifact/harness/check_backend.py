#!/usr/bin/env python3
"""Two-second check that the backend answers before you start a long run.

A wrong model tag currently surfaces twenty minutes into a run, after the
first compaction round. This catches it immediately, and prints the tags the
server will actually accept.
"""
from __future__ import annotations

import argparse
import os
import sys


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="qwen2.5:0.5b-instruct")
    ap.add_argument("--base-url", default="http://localhost:11434/v1")
    ap.add_argument("--api-key-env", default="OLLAMA_KEY")
    a = ap.parse_args()

    import httpx

    print(f"endpoint: {a.base_url}")
    key = os.environ.get(a.api_key_env, "local")
    if not os.environ.get(a.api_key_env):
        print(f"  note: {a.api_key_env} is unset; sending 'local' as the "
              f"token (fine for Ollama, not for a hosted API)")

    # Two different listing endpoints. Ollama serves /api/tags; every
    # OpenAI-compatible hosted API serves /v1/models. Try the standard one
    # first and fall back, instead of assuming Ollama and reporting an empty
    # list as "your model does not exist".
    tags = []
    for url, extract in (
        (a.base_url.rstrip("/") + "/models",
         lambda j: [m["id"] for m in j.get("data", [])]),
        (a.base_url.rsplit("/v1", 1)[0] + "/api/tags",
         lambda j: [m["name"] for m in j.get("models", [])]),
    ):
        try:
            r = httpx.get(url, headers={"Authorization": f"Bearer {key}"},
                          timeout=15)
            if r.status_code < 400:
                tags = extract(r.json())
                if tags:
                    print(f"models the server lists ({url}):")
                    break
        except Exception:  # noqa: BLE001
            continue

    if tags:
        for t in sorted(tags):
            print(f"  {t}" + ("  <-- requested" if t == a.model else ""))
        if a.model not in tags:
            print(f"\n{a.model!r} is not in that list. Pass one of the above.")
            sys.exit(1)
    else:
        print("could not list models; trying the completion anyway.")
        print("  (an empty list is not evidence the model is missing -- some")
        print("   endpoints do not expose a listing at all)")

    print("\nsending one completion ...")
    try:
        r = httpx.post(
            f"{a.base_url}/chat/completions",
            headers={"Authorization": f"Bearer {key}"},
            json={"model": a.model,
                  "messages": [{"role": "user", "content": "Reply with OK."}],
                  "temperature": 0.0},
            timeout=180.0,
        )
        if r.status_code >= 400:
            print(f"HTTP {r.status_code}: {r.text[:500]}")
            sys.exit(1)
        print("reply:", r.json()["choices"][0]["message"]["content"][:80])
        print("\nbackend OK. Safe to start the run.")
    except Exception as e:  # noqa: BLE001
        print("request failed:", e)
        sys.exit(1)


if __name__ == "__main__":
    main()
