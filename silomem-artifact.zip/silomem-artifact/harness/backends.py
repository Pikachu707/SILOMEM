"""Backends.

Two implementations of the same two protocols:

  MockBackend      deterministic, no network, no cost. Use it to prove the
                   plumbing before spending anything.
  HostedBackend    an OpenAI-compatible chat endpoint. Fill in the two
                   marked spots and it is live.

The point of MockBackend is not realism. It is that you can run the entire
harness -- multi-session protocol, metrics, statistics, CSV emission, table
filling -- end to end and find every plumbing bug for free, and only then
point it at a paid endpoint. Every number it produces is stamped MOCK.
"""
from __future__ import annotations

import hashlib
import os
import re
from dataclasses import dataclass, field
from typing import Sequence

from provenire.lattice import Item


# =====================================================================
#  Mock
# =====================================================================
def _h(s: str) -> int:
    return int(hashlib.blake2b(s.encode(), digest_size=8).hexdigest(), 16)


@dataclass
class MockBackend:
    """Deterministic stand-in.

    `summarise` concatenates a digest of each input, so a summary genuinely
    does depend on its inputs -- which means leave-one-out probing has
    something real to detect and the estimator is exercised rather than
    short-circuited. `influence_fraction` controls how many of a cluster's
    items actually move the summary, so you can sweep the attributed cluster
    size `a` and check the harness reproduces Proposition 2 before you have
    any real data.
    """

    influence_fraction: float = 0.5
    cluster_size: int = 4
    seed: int = 0
    calls: int = field(default=0, init=False)

    def _influential(self, cluster: Sequence[Item]) -> list[Item]:
        k = max(1, round(len(cluster) * self.influence_fraction))
        ranked = sorted(cluster, key=lambda it: _h(it.item_id + str(self.seed)))
        return ranked[:k]

    # -- Compactor -----------------------------------------------------
    def cluster(self, items: Sequence[Item]) -> list[list[Item]]:
        # This was hardcoded to 4, so --cluster-size never reached the mock
        # and the one sweep that would have tested whether `a` is simply a
        # fraction of the cluster size silently returned a constant.
        k = self.cluster_size
        items = list(items)
        return [items[i:i + k] for i in range(0, len(items), k)] or [[]]

    def summarise(self, cluster: Sequence[Item]) -> str:
        self.calls += 1
        parts = [it.text[:12] for it in self._influential(cluster)]
        return "SUMMARY[" + "|".join(sorted(parts)) + "]"

    # -- Regenerator ---------------------------------------------------
    def regenerate(self, context: Sequence[Item], withheld: Item) -> str:
        kept = [it for it in context if it.item_id != withheld.item_id]
        return self.summarise(kept)


def token_similarity(a: str, b: str) -> float:
    """Jaccard over tokens. Stands in for a sentence encoder while you are
    on the mock; swap in cosine over embeddings for real runs."""
    ta = set(re.findall(r"\w+", a.lower()))
    tb = set(re.findall(r"\w+", b.lower()))
    if not ta and not tb:
        return 1.0
    return len(ta & tb) / len(ta | tb)


# =====================================================================
#  Hosted
# =====================================================================
@dataclass
class HostedBackend:
    """OpenAI-compatible chat completions.

    Two things to fill in, both marked TODO below. Everything else -- caching,
    retry, rate limiting, cost accounting -- is here already, because on a run
    of this size you will re-run the same prompt thousands of times and an
    uncached harness turns a $40 experiment into a $400 one.

    This class is also the LOCAL backend. Ollama, vLLM and llama.cpp's server
    all speak the same OpenAI chat-completions API, so pointing base_url at
    localhost is the whole of the change:

        HostedBackend(model="qwen2.5:7b-instruct",
                      base_url="http://localhost:11434/v1",
                      api_key_env="OLLAMA_KEY")   # any non-empty value

    See ZERO_COST.md.
    """

    model: str
    base_url: str = "https://api.openai.com/v1"
    api_key_env: str = "OPENAI_API_KEY"
    cache_dir: str = ".cache/llm"
    max_retries: int = 5
    rps: float = 0.0          # requests/sec cap; set this for free tiers
    _last: float = field(default=0.0, init=False)
    calls: int = field(default=0, init=False)
    cached: int = field(default=0, init=False)
    prompt_tokens: int = field(default=0, init=False)
    completion_tokens: int = field(default=0, init=False)

    def __post_init__(self) -> None:
        os.makedirs(self.cache_dir, exist_ok=True)

    # -- the one network call -----------------------------------------
    def _complete(self, prompt: str) -> str:
        key = hashlib.blake2b(
            (self.model + "\0" + prompt).encode(), digest_size=16).hexdigest()
        path = os.path.join(self.cache_dir, key + ".txt")
        if os.path.exists(path):
            self.cached += 1
            return open(path).read()

        import time
        import httpx  # kept local so the mock path needs no dependency

        # Free tiers are rate-limited, not priced. Without a limiter you
        # spend the first hour collecting 429s instead of results.
        if self.rps > 0:
            gap = 1.0 / self.rps
            wait = gap - (time.monotonic() - self._last)
            if wait > 0:
                time.sleep(wait)
            self._last = time.monotonic()

        token = os.environ.get(self.api_key_env)
        if not token:
            raise RuntimeError(
                f"{self.api_key_env} is not set. Export it, or use --mock.")

        last = None
        for attempt in range(self.max_retries):
            try:
                r = httpx.post(
                    f"{self.base_url}/chat/completions",
                    headers={"Authorization": f"Bearer {token}"},
                    json={"model": self.model,
                          "messages": [{"role": "user", "content": prompt}],
                          "temperature": 0.0},   # determinism matters here
                    timeout=120.0,
                )
                r.raise_for_status()
                body = r.json()
                usage = body.get("usage", {})
                self.prompt_tokens += usage.get("prompt_tokens", 0)
                self.completion_tokens += usage.get("completion_tokens", 0)
                text = body["choices"][0]["message"]["content"]
                open(path, "w").write(text)
                self.calls += 1
                return text
            except Exception as e:  # noqa: BLE001
                last = e
                time.sleep(min(2 ** attempt, 30))
        raise RuntimeError(f"backend failed after {self.max_retries} tries: {last}")

    # -- Compactor -----------------------------------------------------
    def cluster(self, items: Sequence[Item]) -> list[list[Item]]:
        # TODO(you): delegate to the framework's own clusterer. The wrapper
        # deliberately sits OUTSIDE clustering (Section 4.7), so this should
        # call the unmodified compactor and return its groups untouched.
        raise NotImplementedError("wire this to your framework's clusterer")

    def summarise(self, cluster: Sequence[Item]) -> str:
        # TODO(you): use the framework's own summarisation prompt, not one of
        # your own. If you write a new prompt here you are measuring your
        # prompt, not the system under test.
        joined = "\n".join(f"- {it.text}" for it in cluster)
        return self._complete(
            "Summarise these memory items into one entry.\n" + joined)

    # -- Regenerator ---------------------------------------------------
    def regenerate(self, context: Sequence[Item], withheld: Item) -> str:
        return self.summarise([it for it in context
                               if it.item_id != withheld.item_id])

    # -- accounting ----------------------------------------------------
    def cost_report(self, usd_per_mtok_in: float, usd_per_mtok_out: float) -> str:
        cin = self.prompt_tokens / 1e6 * usd_per_mtok_in
        cout = self.completion_tokens / 1e6 * usd_per_mtok_out
        return (f"{self.calls} live calls, {self.cached} cache hits, "
                f"{self.prompt_tokens:,} in / {self.completion_tokens:,} out, "
                f"~${cin + cout:.2f}")
