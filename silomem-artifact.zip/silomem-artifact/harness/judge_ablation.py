#!/usr/bin/env python3
"""Score ablation with the judge, so the two methods share a ground truth.

    python harness/judge_ablation.py --model Qwen/Qwen2.5-7B-Instruct \
        --observations results/q1_Qwen_Qwen2_5-7B-Instruct.json --tau 0.18

Reviewer objection 3.2: the paper scores ablation against identifier survival
and attribution by content against a model judge, then puts the two rates side
by side. They are not on the same scale. Identifier survival misses influence
through paraphrase, structure and selection, so ablation's reported rate is a
lower bound, while the judge sees those cases.

This closes the gap in the direction that costs us something. It takes the
items ablation EXCLUDES at a given threshold and asks the same judge, with the
same prompt and the same control procedure, whether the summary reflects them.
The result is ablation's miss rate under the judge's definition, directly
comparable to Table 3.

We expect it to be higher than the identifier-based figure, since the judge
counts cases the identifier test cannot see. If it is not, that is worth
knowing too: it would mean the identifier ground truth was not as narrow as we
argued, and the comparison in the paper was less unfair to ablation than we
said.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from harness.observe_q1 import key_token
from harness.probe_grounded_fn import ask, check_server


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://localhost:8000/v1")
    ap.add_argument("--api-key-env", default="VLLM_KEY")
    ap.add_argument("--model", required=True,
                    help="the JUDGE model; use one model for every row so "
                         "judging ability is not confounded with the "
                         "summarising backend")
    ap.add_argument("--observations", required=True,
                    help="an observe_q1 file, which stores per-item distances")
    ap.add_argument("--tau", type=float, required=True,
                    help="the threshold whose exclusions are being judged")
    ap.add_argument("--sample", type=int, default=120)
    ap.add_argument("--out", default="results/ablation_judged.json")
    a = ap.parse_args()
    key = os.environ.get(a.api_key_env, "local")
    check_server(a.base_url, a.model, key)

    d = json.load(open(a.observations))
    backend = d["config"]["model"]
    pairs = [(o["summary"], it) for o in d["observations"] for it in o["items"]]
    excluded = [(s, it) for s, it in pairs if it["distance"] <= a.tau]
    # control selected independently of the method, as in probe_grounded_fn
    control = [(s, it) for s, it in pairs
               if key_token(it["text"]) and key_token(it["text"]) in s]

    rng = random.Random(0)
    exc = rng.sample(excluded, min(a.sample, len(excluded)))
    ctl = rng.sample(control, min(a.sample // 2, len(control)))

    print(f"summariser: {backend}")
    print(f"judge     : {a.model}")
    print(f"threshold : {a.tau}")
    print(f"excluded  : {len(excluded)} of {len(pairs)} items "
          f"({100*len(excluded)/len(pairs):.0f}%), judging {len(exc)}\n")

    miss = 0
    for i, (s, it) in enumerate(exc, 1):
        if ask(a.base_url, a.model, key, s, it["text"]).startswith("YES"):
            miss += 1
        if i % 40 == 0:
            print(f"  {i}/{len(exc)}")
    ok = sum(1 for s, it in ctl
             if ask(a.base_url, a.model, key, s, it["text"]).startswith("YES"))

    miss_rate = miss / len(exc)
    ctl_rate = ok / len(ctl) if ctl else float("nan")
    of_all = miss_rate * len(excluded) / len(pairs)

    print("\n" + "=" * 66)
    print("Ablation scored by the judge")
    print("=" * 66)
    print(f"  control                          {100*ctl_rate:.0f}%")
    print(f"  excluded items judged to matter  {100*miss_rate:.0f}%")
    print(f"  as a fraction of all items       {100*of_all:.1f}%")
    print()
    if ctl_rate < 0.8:
        print("JUDGE UNRELIABLE on this file; the run is void.")
    else:
        print("This is the number to place beside Table 3, since it uses the")
        print("same judge, prompt and control procedure. The identifier-based")
        print("figure in Table 1 is not comparable to it and the two should")
        print("not appear in the same column.")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump({"config": vars(a), "summariser": backend,
               "excluded_frac": len(excluded) / len(pairs),
               "miss_among_excluded": miss_rate, "control": ctl_rate,
               "miss_of_all_items": of_all}, open(a.out, "w"), indent=1)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
