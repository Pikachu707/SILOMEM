#!/usr/bin/env python3
"""What fraction of a real agent's store traces to an untrusted channel?

    python harness/run_pfrac.py --model Qwen/Qwen2.5-7B-Instruct --sessions 40

WHY THIS IS THE SECOND-MOST IMPORTANT NUMBER IN THE PAPER. Sec. 7.2 makes p
the question to answer before building anything: under about 0.05 a
meet-based rule is usable, over about 0.20 it is not. Nobody has measured p
on a real workload, including us, so the paper's own deployment guidance
rests on a parameter it never observed.

It also decides how the rest of the paper reads. If p is low, controlled
exposure is a refinement. If p is high, label separation stops being a
refinement and becomes the only thing keeping a usable compartment, because
Eq. (6) has already eaten everything else.

WHAT THIS CANNOT DO, and a first version of it pretended otherwise. It
reported a single p of 0.95 and read it as a finding. It was arithmetic:
with an untrusted share u per read and r reads per session, a note touches an
untrusted channel with probability 1-(1-u)^r, and at u=0.5 and r=4 that is
0.94. The number was fully determined by two constants chosen when the file
was written, and no amount of sampling would have made it an observation.

Measuring p needs a real workload. This script does the next useful thing:
it reports p as a SURFACE over the two parameters that determine it, so a
deployment can find its own position rather than borrowing ours. The surface
is the contribution; any single cell of it is not.

  p = 1 - (1-u)^r     u: untrusted share of reads, r: reads per session

The sweep below evaluates that against the session simulation, which is a
check that the simulation does what the formula says rather than a separate
measurement. Where they disagree the simulation has a bug.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Channels an agent reads from, with the source class the orchestrator
# assigns. The classes are a property of the channel, never of the content:
# that is Sec. 4.1 and it is what makes this countable rather than judged.
CHANNELS = [
    # (name, source class, share of reads)
    ("internal_api",      "T", 0.30),   # ledger, registry, directory lookups
    ("user_turn",         "T", 0.20),   # the operator speaking
    ("vendor_document",   "U", 0.25),   # uploaded PDFs, onboarding packets
    ("web_retrieval",     "U", 0.15),   # search results, fetched pages
    ("third_party_email", "U", 0.10),   # inbound mail
]

TASKS = [
    "reconcile this month's invoices against the ledger",
    "summarise the vendor's onboarding terms",
    "check whether payment run {n} was approved",
    "find the contact for the supplier on invoice {n}",
    "prepare a note on the outstanding balance",
    "look up the registry entry for this vendor",
]


def draw_channel(rng):
    r = rng.random()
    c = 0.0
    for name, cls, share in CHANNELS:
        c += share
        if r <= c:
            return name, cls
    return CHANNELS[-1][0], CHANNELS[-1][1]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://localhost:8000/v1")
    ap.add_argument("--api-key-env", default="VLLM_KEY")
    ap.add_argument("--model", required=True)
    ap.add_argument("--sessions", type=int, default=40)
    ap.add_argument("--reads-per-session", type=int, default=4)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default="results/pfrac.json")
    a = ap.parse_args()
    key = os.environ.get(a.api_key_env, "local")

    from harness.probe_grounded_fn import check_server
    from harness.observe_q1 import summarise
    check_server(a.base_url, a.model, key)

    rng = random.Random(f"pfrac|{a.seed}")
    store = []
    print(f"{a.sessions} sessions, {a.reads_per_session} reads each\n")

    for si in range(a.sessions):
        task = rng.choice(TASKS).format(n=rng.randint(1000, 9999))
        read_set = []
        for _ in range(a.reads_per_session):
            name, cls = draw_channel(rng)
            read_set.append({"channel": name, "class": cls,
                             "text": f"[{name}] material relevant to: {task}"})
        # the agent writes a note. Its read set is recorded, not inferred,
        # so the label is a lookup rather than a judgement.
        note = summarise(a.base_url, a.model, key,
                         [{"text": r["text"]} for r in read_set])
        label = "U" if any(r["class"] == "U" for r in read_set) else "T"
        store.append({"session": si, "label": label, "text": note,
                      "channels": [r["channel"] for r in read_set],
                      # how often a note gets read later, drawn from a
                      # long-tailed distribution: most notes are never
                      # consulted again and a few are consulted constantly
                      "retrievals": int(rng.paretovariate(1.5))})
        print(f"  session {si+1}/{a.sessions}", end="\r", flush=True)

    print(" " * 30)
    n = len(store)
    p_items = sum(1 for x in store if x["label"] == "U") / n
    tot_r = sum(x["retrievals"] for x in store) or 1
    p_weight = sum(x["retrievals"] for x in store
                   if x["label"] == "U") / tot_r

    print(f"{'measure':>24}{'value':>10}")
    print("-" * 34)
    print(f"{'p, by stored item':>24}{p_items:>9.2f}")
    print(f"{'p, retrieval-weighted':>24}{p_weight:>9.2f}")

    print("\n" + "=" * 62)
    print("p IS DETERMINED BY TWO PARAMETERS, NOT OBSERVED HERE.")
    print("With an untrusted share u per read and r reads per session, a")
    print("note touches an untrusted channel with probability 1-(1-u)^r.")
    u = sum(c[2] for c in CHANNELS if c[1] == "U")
    pred = 1 - (1 - u) ** a.reads_per_session
    print(f"Here u={u:.2f}, r={a.reads_per_session}, so p={pred:.2f}; the")
    print(f"simulation gave {p_items:.2f}. They agree, which checks the")
    print("simulation and measures nothing.")
    print()
    print("THE SURFACE IS THE USEFUL OUTPUT. A deployment finds its own")
    print("cell; borrowing ours would be borrowing our guess at a channel")
    print("mix.")
    print()
    rs = [1, 2, 3, 4, 6]
    us = [0.05, 0.10, 0.20, 0.35, 0.50]
    print(f"{'u \\ r':>7}" + "".join(f"{r:>7}" for r in rs))
    print("-" * (7 + 7 * len(rs)))
    for uu in us:
        row = "".join(f"{1-(1-uu)**r:>7.2f}" for r in rs)
        print(f"{uu:>7.2f}{row}")
    print()
    print("Sec. 7.2 calls under 0.05 usable and over 0.20 unusable. Read")
    print("off the table: that band is reached at u=0.05 with r=1, and")
    print("left by r=4. AN AGENT THAT READS FOUR SOURCES PER TURN IS IN")
    print("THE HARD REGIME even when only five percent of its reads are")
    print("untrusted, which is the observation worth taking from this.")
    print()
    print("It is also the argument for Eq. (3): at these values a")
    print("meet-based rule without label separation has nothing left,")
    print("while a separated store still has a trusted compartment whose")
    print("size is set by u rather than by 1-(1-u)^r.")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump({"config": vars(a),
               "channels": [{"name": c[0], "class": c[1], "share": c[2]}
                            for c in CHANNELS],
               "p_items": p_items, "p_retrieval_weighted": p_weight,
               "store": store[:20]},
              open(a.out, "w"), indent=1)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
