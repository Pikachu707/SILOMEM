#!/usr/bin/env python3
"""RQ5: where the overhead is, broken out by component.

    python harness/run_overhead.py --trials 2000

Three components with different asymptotics, and the paper insists they be
reported separately because folding them into one number hides the one that
scales badly:

  per-write labelling      O(1)          -- a meet over the influence set
  compaction re-derivation O(cluster)    -- one meet per summary
  leave-one-out probing    O(cluster)    -- but with a MODEL CALL per element

The first two are model-independent and measured here directly. The third is
one call per item per cluster, so its cost is (calls x backend latency); this
reports the call count and multiplies by a latency you supply, rather than
pretending a CPU measurement says anything about a served model.

Section 6.6 already shows the third component is the one not earning its cost,
which is why the breakdown matters more than the total.
"""
from __future__ import annotations

import argparse
import json
import os
import statistics
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from harness.backends import MockBackend, token_similarity
from provenire.compaction import taint_preserving_compaction
from provenire.influence import EstimatorConfig, EstimatorStats, estimate
from provenire.lattice import Item, SourceClass, label_generated, label_source


def bench(fn, trials, warmup=50):
    for _ in range(warmup):
        fn()
    ts = []
    for _ in range(trials):
        t0 = time.perf_counter_ns()
        fn()
        ts.append((time.perf_counter_ns() - t0) / 1e6)   # ms
    ts.sort()
    return {"p50": ts[len(ts) // 2], "p95": ts[int(len(ts) * 0.95) - 1],
            "mean": statistics.fmean(ts)}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--trials", type=int, default=2000)
    ap.add_argument("--cluster-size", type=int, default=4)
    ap.add_argument("--context", type=int, default=5)
    ap.add_argument("--backend-latency-ms", type=float, default=600.0,
                    help="measured latency of one model call on the backend "
                         "you will deploy; used only to scale the "
                         "leave-one-out component")
    ap.add_argument("--out", default="results/overhead.json")
    a = ap.parse_args()

    ctx = [label_source(f"s{j}", f"source text {j} with some body to it",
                        SourceClass.TRUSTED_TOOL if j % 2 else
                        SourceClass.RETRIEVED, f"ev{j}")
           for j in range(a.context)]
    cluster = [label_generated(f"g{j}", f"note {j} derived from the session",
                               ctx) for j in range(a.cluster_size)]
    backend = MockBackend()
    cfg_noloo = EstimatorConfig(enable_loo=False)

    print("=" * 68)
    print(f"Overhead, model-independent components  ({a.trials} trials)")
    print("=" * 68)

    r_write = bench(lambda: label_generated("x", "a written note", ctx),
                    a.trials)
    print(f"per-write labelling      p50 {r_write['p50']:.4f} ms   "
          f"p95 {r_write['p95']:.4f} ms   O(1) in the influence set")

    st = EstimatorStats()
    r_est = bench(lambda: estimate("summary text", cluster, cfg=cfg_noloo,
                                   stats=st), a.trials)
    print(f"influence estimate       p50 {r_est['p50']:.4f} ms   "
          f"p95 {r_est['p95']:.4f} ms   (probing disabled)")

    r_comp = bench(lambda: taint_preserving_compaction(
        cluster, backend, cfg=cfg_noloo), max(a.trials // 10, 100))
    print(f"compaction re-derivation p50 {r_comp['p50']:.4f} ms   "
          f"p95 {r_comp['p95']:.4f} ms   O(cluster), one meet per summary")

    print()
    print("=" * 68)
    print("Leave-one-out probing: one model call per item per cluster")
    print("=" * 68)
    per_round_calls = a.cluster_size          # one per element
    ms = per_round_calls * a.backend_latency_ms
    print(f"calls per cluster        {per_round_calls}")
    print(f"at {a.backend_latency_ms:.0f} ms per call     "
          f"{ms:.0f} ms per cluster")
    ratio = ms / max(r_comp["p50"], 1e-9)
    print(f"ratio to the rest        {ratio:,.0f}x")
    print()
    print("The two model-independent components are microseconds. Everything")
    print("in the overhead budget is the probing, and Section 6.6 measures")
    print("what it buys: a moves by 3.9% and TER by 0.005.")

    print()
    print("=" * 68)
    print("Storage amplification")
    print("=" * 68)
    it = cluster[0]
    body = len(it.text.encode())
    side = len(json.dumps({"l": int(it.level),
                           "rho": sorted(it.origins),
                           "pi": int(it.how), "v": 1}).encode())
    print(f"item text                {body} B")
    print(f"side-table record        {side} B")
    print(f"amplification            {(body + side) / body:.2f}x")
    print("The origin set is the term that grows: it is the union over the")
    print("influence set, so it widens as lineage accumulates. Report it")
    print("against horizon, not as a constant.")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump({"write": r_write, "estimate": r_est, "compaction": r_comp,
               "loo_calls_per_cluster": per_round_calls,
               "backend_latency_ms": a.backend_latency_ms,
               "storage": {"text_bytes": body, "record_bytes": side}},
              open(a.out, "w"), indent=2)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
