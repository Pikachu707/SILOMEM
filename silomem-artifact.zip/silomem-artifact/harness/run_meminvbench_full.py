#!/usr/bin/env python3
"""Run the full labelling path over MEM-INV-Bench, with compaction added.

    python harness/run_meminvbench_full.py --bench mem-inv-bench/ \
        --backend vllm --model Qwen/Qwen2.5-7B-Instruct --rounds 0,1,3,7

This is the experiment that turns Section 6.3 from an argument about their
setup into a measurement on it. Their scenarios are two sessions --- one
ingests, one acts --- so the compaction rounds over which over-tainting
accumulates never occur. We insert them and report where over-tainting goes.

Two numbers come out, and they answer different halves of the section:

  d_eff   the realised declassification rate on their legitimate-elevation
          scenarios. Those are built so a trusted corroborator exists, so a
          value near 1 would confirm that their utility is measured where
          declassification always succeeds.
  TER(r)  over-tainting after r inserted compaction rounds. At r=0 this
          should reproduce their near-zero cost; the question is the slope.

WHAT WOULD REFUTE US. If TER stays flat as rounds are added, over-tainting is
not a function of compaction depth on their workload and the paper's central
claim does not apply to it. The script prints that reading when it occurs
rather than leaving it to be noticed.
"""
from __future__ import annotations

import argparse
import collections
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from harness.backends import MockBackend, token_similarity
from harness.run_meminvbench import adapt, is_scenario, load
from provenire.compaction import taint_preserving_compaction
from provenire.declassify import (Budget, DeclassificationRefused, Ledger,
                                  d2_corroborate)
from provenire.influence import EstimatorConfig
from provenire.lattice import (Item, Level, SourceClass, label_generated,
                               label_source)


def build_backend(kind, model, cluster_size, base_url=None, api_key_env=None):
    if kind == "mock":
        return MockBackend(influence_fraction=0.5), token_similarity
    from harness.ollama_backend import OllamaBackend
    from harness.run_rq2 import PRESETS
    url, env, rps = PRESETS.get(kind, PRESETS["ollama"])
    return (OllamaBackend(model=model, cluster_size=cluster_size,
                          base_url=base_url or url,
                          api_key_env=api_key_env or env, rps=rps),
            token_similarity)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--bench", required=True)
    ap.add_argument("--backend", default="mock")
    ap.add_argument("--model", default="Qwen/Qwen2.5-7B-Instruct")
    ap.add_argument("--base-url", default=None)
    ap.add_argument("--api-key-env", default=None)
    ap.add_argument("--variant", default="adaptive")
    ap.add_argument("--rounds", default="0,1,3,7",
                    help="compaction rounds to insert between their two "
                         "sessions. 0 reproduces their setup.")
    ap.add_argument("--declass-rate", type=float, default=0.5)
    ap.add_argument("--cluster-size", type=int, default=4)
    ap.add_argument("--loo-workers", type=int, default=32)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--pool", type=int, default=16,
                    help="scenarios pooled into one store. Their scenarios "
                         "are isolated; a store of five items collapses to "
                         "one summary in a single round and TER over one "
                         "item is not a measurement. But pool trades against "
                         "batch count, and their corpus is 46 scenarios: "
                         "batches>=3 needs pool<=16, N>=20 after three "
                         "rounds needs pool>=16. 16 is the only value that "
                         "satisfies both, and only barely.")
    ap.add_argument("--out", default="results/meminvbench_full.json")
    a = ap.parse_args()

    raw, _ = load(a.bench)
    recs = [r for r in raw if is_scenario(r)]
    print(f"{len(raw)} records loaded, {len(recs)} are scenarios")
    scenarios = []
    for r in recs:
        got = adapt(r, a.variant)
        if got:
            scenarios.append(got)
    if a.limit:
        scenarios = scenarios[:a.limit]
    if not scenarios:
        print("nothing mapped; check adapt() against their schema")
        sys.exit(1)

    backend, sim = build_backend(a.backend, a.model, a.cluster_size,
                                 a.base_url, a.api_key_env)
    cfg = EstimatorConfig(tau=0.15, loo_max_cluster=16,
                          loo_workers=a.loo_workers)
    rounds = [int(x) for x in a.rounds.split(",")]

    print("=" * 66)
    print(f"MEM-INV-Bench, {len(scenarios)} scenarios, variant={a.variant}")
    print("=" * 66)
    kinds = collections.Counter(mt["kind"] for _, mt in scenarios)
    print(f"kinds: {dict(kinds)}")
    print()
    print(f"pooling {a.pool} scenarios per store")
    print()
    print(f"{'rounds':>7}{'TER':>9}{'|store|':>9}{'batches':>9}")
    print("-" * 34)

    out = {"config": vars(a), "rows": []}
    import random
    # Their scenarios are isolated: four sources and one written note each.
    # A store of five items collapses to one summary after a single
    # compaction round, and TER over one item is not a measurement. A
    # deployed store holds many sessions at once, so we POOL scenarios into
    # a shared store. This is a modelling decision and it is the right one,
    # but it is ours and not theirs -- their benchmark does not have a
    # shared store because it does not have compaction.
    for R in rounds:
        ters, deffs, sizes = [], [], []
        for b in range(0, len(scenarios), a.pool):
            batch = scenarios[b:b + a.pool]
            if len(batch) < a.pool // 2:
                continue
            rng = random.Random(b)
            store: list[Item] = []
            for gi, (items, meta) in enumerate(batch):
                store += items
                store.append(label_generated(f"note{gi}", "note on " +
                                             items[-1].text[:120], items))
            budget, ledger = Budget(b=10_000), Ledger()
            corr = label_source("corr", "trusted tool",
                                SourceClass.TRUSTED_TOOL, "corr_ev")
            att = ok = 0
            for r in range(R):
                # A real store keeps writing between compaction rounds. Ours
                # did not, so the population collapsed geometrically to a
                # single summary and TER was computed over N=1. We replay the
                # batch's sessions between rounds, which is the closest thing
                # to a continuing workload their scenarios can supply.
                for gi, (items, meta) in enumerate(batch):
                    store.append(label_generated(
                        f"note{gi}_r{r}", f"note {r} on " + items[-1].text[:100],
                        items))
                res = taint_preserving_compaction(
                    store, backend, regenerator=backend, similarity=sim,
                    cfg=cfg)
                store = res.items
                promoted = []
                for it in store:
                    if it.level is Level.U and rng.random() < a.declass_rate:
                        att += 1
                        try:
                            promoted.append(d2_corroborate(it, corr, True,
                                                           budget, ledger))
                            ok += 1
                        except DeclassificationRefused:
                            promoted.append(it)
                    else:
                        promoted.append(it)
                store = promoted
            n = len(store) or 1
            ters.append(sum(1 for it in store if it.level is Level.U) / n)
            deffs.append(ok / att if att else 0.0)
            sizes.append(n)
        ter = sum(ters) / len(ters)
        deff = sum(deffs) / len(deffs)
        nbar = sum(sizes) / len(sizes)
        flag = ("   <-- N too small; raise --pool" if nbar < 20 else "")
        print(f"{R:>7}{ter:>9.3f}{nbar:>9.1f}{len(ters):>9}{flag}")
        out["rows"].append({"rounds": R, "ter": ter, "d_eff": deff,
                            "store": nbar, "batches": len(ters)})

    print()
    nb = out["rows"][0].get("batches", 0)
    if nb < 3:
        print("!" * 66)
        print(f"ONLY {nb} BATCH(ES). There is no variance estimate, so the")
        print("TER column is one draw per row and its movement cannot be")
        print("separated from noise. Lower --pool until this is at least 3.")
        print("!" * 66)
        print()
    print("d_eff is NOT reported: the corroborator in this harness is")
    print("hardcoded to agree, so it would be 1.000 by construction and")
    print("would say nothing about their scenarios.")
    print()
    first = out["rows"][0]["ter"]
    last = out["rows"][-1]["ter"]
    if abs(last - first) < 0.05:
        print("TER is flat across the inserted rounds. Over-tainting is not")
        print("a function of compaction depth on this workload, and the")
        print("central claim of this paper does not apply to it. Report that")
        print("as a limit on the claim, not as a null result.")
    else:
        print(f"TER moves {first:.3f} -> {last:.3f} as rounds go "
              f"{rounds[0]} -> {rounds[-1]}. Their benchmark measures the")
        print("left end. That is the Section 6.3 argument, measured rather")
        print("than asserted.")

    if hasattr(backend, "report"):
        print(backend.report())
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(out, open(a.out, "w"), indent=2)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
