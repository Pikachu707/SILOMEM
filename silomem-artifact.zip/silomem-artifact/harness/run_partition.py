#!/usr/bin/env python3
"""Trust-partitioned compaction: enforce the property instead of estimating it.

    python harness/run_partition.py --model Qwen/Qwen2.5-7B-Instruct

THE IDEA. Every design this paper has measured takes the cluster as given and
then argues about how to label its summary: whole-cluster takes the meet over
all of K, ablation over an estimated subset, attribution by content over a
located subset. But K is not given. The compactor chooses it, and the
estimation problem exists only because K mixes trust levels. If every item in
K carries the same label then for any subset A of K,

    meet over A  =  meet over K  =  that common label

so the summary's label does not depend on the estimate. There is no estimate,
and an attack on the estimate has no target.

So: constrain the compactor to cluster only within a trust level. The store
becomes two pools that compact independently.

WHY THE REPHRASING ATTACK CANNOT WORK HERE. That attack rewrites a note so the
summariser drops its identifier, which fools a rule that reads the summary.
Partitioning never reads the summary. An item's pool is fixed at ingest by the
channel it arrived on, and no phrasing changes the channel. The property the
location test lacked is exactly this one: the adversary controls the text and
not the provenance.

WHAT IT COSTS, and this is the honest part: cross-label merges. Two items that
would have compacted together now cannot, so the store compacts less per round
and the item count falls more slowly. That is a utility cost a deployment can
measure and budget, which is the difference between it and a defeated
estimator.

WHAT THIS SCRIPT MEASURES. Soundness is by construction, so asserting it is
cheap and we do assert it: no summary may carry untrusted lineage under a
trusted label, on every cluster, every round. What has to be measured is the
price: compaction ratio against whole-cluster propagation, as a function of
how untrusted the store is.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from harness.observe_q1 import ONTOPIC, summarise
from harness.probe_grounded_fn import check_server
from harness.run_adversarial import PAYLOAD

from provenire.lattice import TRUSTED_POOL as TRUSTED
from provenire.lattice import UNTRUSTED_POOL as UNTRUSTED


def make_store(rng, n, frac_untrusted):
    items = []
    for i in range(n):
        u = rng.random() < frac_untrusted
        text = (rng.choice(list(PAYLOAD.values())) if u
                else rng.choice(ONTOPIC))
        items.append({"label": UNTRUSTED if u else TRUSTED,
                      "text": text.format(n=rng.randint(1000, 9999)),
                      "lineage": {"adv"} if u else set()})
    return items


def compact_whole(items, k, url, model, key):
    """Whole-cluster propagation: cluster freely, meet over everything."""
    out = []
    for i in range(0, len(items), k):
        cl = items[i:i + k]
        lab = UNTRUSTED if any(x["label"] == UNTRUSTED for x in cl) else TRUSTED
        lin = set().union(*(x["lineage"] for x in cl)) if cl else set()
        out.append({"label": lab,
                    "text": summarise(url, model, key,
                                      [{"text": x["text"]} for x in cl]),
                    "lineage": lin})
    return out


def compact_partitioned(items, k, url, model, key):
    """Cluster only within a trust level. The label needs no derivation."""
    out = []
    for lab in (TRUSTED, UNTRUSTED):
        pool = [x for x in items if x["label"] == lab]
        for i in range(0, len(pool), k):
            cl = pool[i:i + k]
            lin = set().union(*(x["lineage"] for x in cl)) if cl else set()
            out.append({"label": lab,
                        "text": summarise(url, model, key,
                                          [{"text": x["text"]} for x in cl]),
                        "lineage": lin})
    return out


def audit(items):
    """The property, checked rather than asserted: no item may be labelled
    trusted while carrying untrusted lineage."""
    return sum(1 for x in items
               if x["label"] == TRUSTED and x["lineage"])


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://localhost:8000/v1")
    ap.add_argument("--api-key-env", default="VLLM_KEY")
    ap.add_argument("--model", required=True)
    ap.add_argument("--store", type=int, default=48)
    ap.add_argument("--cluster-size", type=int, default=6)
    ap.add_argument("--rounds", type=int, default=3)
    ap.add_argument("--fracs", default="0.1,0.3,0.5")
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--out", default="results/partition.json")
    a = ap.parse_args()
    key = os.environ.get(a.api_key_env, "local")
    check_server(a.base_url, a.model, key)

    fracs = [float(x) for x in a.fracs.split(",")]
    print(f"store {a.store}, cluster {a.cluster_size}, "
          f"{a.rounds} rounds, {a.seeds} seeds\n")
    print(f"{'untrusted':>10}{'rule':>14}{'items after':>13}"
          f"{'ratio':>8}{'violations':>12}")
    print("-" * 58)
    out = {"config": vars(a), "rows": []}

    for frac in fracs:
        for name, fn in (("whole-cluster", compact_whole),
                         ("partitioned", compact_partitioned)):
            sizes, viol = [], 0
            for seed in range(a.seeds):
                rng = random.Random(f"part|{seed}|{frac}")
                items = make_store(rng, a.store, frac)
                for _ in range(a.rounds):
                    items = fn(items, a.cluster_size, a.base_url,
                               a.model, key)
                sizes.append(len(items))
                viol += audit(items)
            mean = sum(sizes) / len(sizes)
            print(f"{frac:>10.2f}{name:>14}{mean:>13.1f}"
                  f"{a.store/mean:>8.1f}x{viol:>12}")
            out["rows"].append({"frac": frac, "rule": name,
                                "items_after": mean,
                                "ratio": a.store / mean,
                                "violations": viol})
        print()

    bad = sum(r["violations"] for r in out["rows"]
              if r["rule"] == "partitioned")
    print("=" * 58)
    if bad:
        print(f"PARTITIONING VIOLATED ITS OWN PROPERTY {bad} times. That is a")
        print("bug in the implementation, not a finding: the construction")
        print("makes it impossible. Find it before reading anything else.")
    else:
        print("No trusted summary carries untrusted lineage under")
        print("partitioning, on any cluster of any round. That is the")
        print("construction working, and it is worth checking rather than")
        print("asserting, but it is not evidence: it could not have come")
        print("out otherwise.")
        print()
        print("The number that matters is the ratio column. Partitioning")
        print("compacts less because it cannot merge across the split, and")
        print("that gap IS the price of the guarantee.")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(out, open(a.out, "w"), indent=1)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
