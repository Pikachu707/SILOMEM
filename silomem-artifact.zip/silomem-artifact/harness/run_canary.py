#!/usr/bin/env python3
"""Whether the canary can work at all, and if so its false-positive rate.

The question this script was written to answer was the false-positive rate.
The answer it returns is prior to that: under leave-one-out attribution the
probe's own tracking is erased within three compaction rounds, so there is
nothing left to test. Lineage survival is therefore reported first, and the
false-positive rate only for the arms in which any probe survives.

    python harness/run_canary.py --backend vllm --model <tag> --epochs 40

A probe that fires on clean workloads is worse than no probe: it teaches the
operator to ignore the alerts, and then it is worse than nothing when a real
label loss happens. So the number that matters is not sensitivity but the rate
at which it cries wolf on a run with no attack in it.

The run is clean by construction --- no poisoned artifact is ingested --- so
every alarm is a false alarm. We also report the rate WITHOUT the Holm
correction, because the gap between the two is the argument for the correction
and a reviewer will want to see it rather than take it on faith.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from harness.backends import MockBackend, token_similarity
from harness.workload import make_session, strip_marks
from provenire.canary import ProbeMonitor, build_suite, distance, fingerprint
from provenire.compaction import taint_preserving_compaction
from provenire.influence import EstimatorConfig
from provenire.lattice import Item, Level, label_generated


def build_backend(kind, model, cluster_size, max_tokens=64,
                  base_url=None, api_key_env=None, rps=None):
    if kind == "mock":
        return MockBackend(influence_fraction=0.5), token_similarity
    from harness.ollama_backend import OllamaBackend
    from harness.run_rq2 import PRESETS
    url, env, drps = PRESETS.get(kind, PRESETS["ollama"])
    return (OllamaBackend(model=model, cluster_size=cluster_size,
                          max_tokens=max_tokens, base_url=base_url or url,
                          api_key_env=api_key_env or env,
                          rps=drps if rps is None else rps),
            token_similarity)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--backend", default="mock")
    ap.add_argument("--model", default="Qwen/Qwen2.5-7B-Instruct")
    ap.add_argument("--base-url", default=None)
    ap.add_argument("--api-key-env", default=None)
    ap.add_argument("--epochs", type=int, default=200,
                    help="compaction epochs; the probe fires at each one")
    ap.add_argument("--probes", type=int, default=24)
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--u", type=float, default=0.20)
    ap.add_argument("--n-items", type=int, default=5)
    ap.add_argument("--budget-items", type=int, default=48,
                    help="the probe suite is part of the population now, "
                         "so this must exceed --probes and still let "
                         "compaction fire more than the monitor's warm-up "
                         "window, or nothing is tested at all")
    ap.add_argument("--cluster-size", type=int, default=4)
    ap.add_argument("--alpha", type=float, default=0.01)
    ap.add_argument("--loo-workers", type=int, default=32)
    ap.add_argument("--out", default="results/canary.json")
    a = ap.parse_args()

    backend, sim = build_backend(a.backend, a.model, a.cluster_size,
                                 base_url=a.base_url,
                                 api_key_env=a.api_key_env)
    cfg = EstimatorConfig(tau=0.15, loo_max_cluster=16,
                          loo_workers=a.loo_workers)
    suite = build_suite(a.probes)

    print("=" * 68)
    print(f"Canary false-positive rate  --  {a.epochs} epochs x {a.seeds} "
          f"seeds, no attack present")
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    print("=" * 68)
    print("Every alarm below is a false alarm: the run is clean by")
    print("construction.\n")

    tot_ep = raw_fire = holm_fire = 0
    dists = []
    survival = []      # probes still resolvable, per compaction round
    for seed in range(a.seeds):
        rng = random.Random(seed)
        # The probe items must live IN the store and go through compaction.
        # An earlier version kept them in a side dict that compaction never
        # touched, so the fingerprint was constant by construction and the
        # measured false-positive rate was zero from a probe that could not
        # fire. That is not a result.
        memory: list[Item] = [p.item for p in suite]

        def resolve(it, mem=None):
            """Current level of a probe item as the STORE holds it.

            A probe item may have been consumed by a compaction round, in
            which case its lineage lives on in the summary that replaced it.
            We resolve through the origin set: the probe's level is the meet
            over every surviving item that descends from its ingestion event.
            If nothing survives, the probe is unresolvable and we say so
            rather than defaulting to its original level.
            """
            ev = next(iter(it.origins), None)
            surv = [m for m in memory if ev in m.origins]
            if not surv:
                return None
            return min(m.level for m in surv)
        mon = ProbeMonitor(alpha=a.alpha, seed=seed)
        base_fp = None

        for k in range(a.epochs):
            spec = make_session(k, rng, untrusted_fraction=a.u,
                                n_items=a.n_items)
            for it in spec.items:
                it.text = strip_marks(it.text)
            for j in range(2):
                memory.append(label_generated(f"g{k}_{j}",
                                              f"note on {spec.items[j].text[:80]}",
                                              spec.items))
            if len(memory) > a.budget_items:
                res = taint_preserving_compaction(
                    memory, backend, regenerator=backend, similarity=sim,
                    cfg=cfg)
                memory = res.items
                lv = {p.probe_id: resolve(p.item) for p in suite}
                live = [p for p in suite if lv[p.probe_id] is not None]
                survival.append(len(live) / len(suite))
                if len(live) < len(suite) // 2:
                    # more than half the suite has been compacted away; the
                    # fingerprint is no longer comparable to the baseline
                    continue
                fp = fingerprint(live, lambda it, _lv=lv: next(
                    _lv[p.probe_id] for p in live if p.item is it))
                if base_fp is None:
                    base_fp = fp
                dists.append(distance(fp, base_fp))
                p = mon.observe(fp)
                if p is not None:
                    tot_ep += 1
                    if p <= a.alpha:
                        raw_fire += 1
        holm_fire += sum(mon.alarms())

        if hasattr(backend, "report"):
            print(f"  seed {seed}: {backend.report()}")

    print()
    print("=" * 68)
    print("Probe lineage survival, by compaction round")
    print("=" * 68)
    if survival:
        n = max(len(survival) // a.seeds, 1)
        for r in range(min(n, 8)):
            vals = survival[r::n] if n else []
            if vals:
                print(f"  round {r+1}: {sum(vals)/len(vals):>6.1%} of probes "
                      "still resolvable")
        if sum(survival[-max(len(survival)//4,1):]) == 0:
            print()
            print("  Survival reaches zero. The probe resolves a memory item")
            print("  through its origin set, and the estimator drops the")
            print("  origins of inputs that did not move the summary, so the")
            print("  mechanism the canary monitors is the one that erases the")
            print("  canary. Run with --loo-max-cluster 0 to see the trivial")
            print("  estimator, under which survival stays at 100%.")
    print()
    if tot_ep == 0:
        print("!" * 68)
        print("NO EPOCHS TESTED. Compaction fired fewer times than the")
        print(f"monitor's warm-up window ({ProbeMonitor().window}), so the")
        print("test never ran. Lower --budget-items or raise --epochs: the")
        print("run needs at least window+1 compactions to produce a single")
        print("p-value. A zero false-positive rate from zero tests is not a")
        print("result.")
        print("!" * 68)
        json.dump({"config": vars(a), "epochs": 0, "survival": survival,
                   "reason": "probes erased before the warm-up window"},
                  open(a.out, "w"), indent=2)
        sys.exit(0)
    print(f"tested epochs                {tot_ep}")
    print(f"alarms, uncorrected          {raw_fire}"
          f"  ({100*raw_fire/max(tot_ep,1):.1f}%)")
    print(f"alarms, Holm-corrected       {holm_fire}"
          f"  ({100*holm_fire/max(tot_ep,1):.1f}%)")
    print(f"mean fingerprint drift       {sum(dists)/max(len(dists),1):.4f}")
    if sum(dists) == 0 and tot_ep:
        print()
        print("!" * 68)
        print("DRIFT IS EXACTLY ZERO over every tested epoch. Before")
        print("reporting a 0% false-positive rate, check that the probe")
        print("items are in the store and going through compaction: if the")
        print("fingerprint cannot move, the rate is a property of the")
        print("harness and not of the probe.")
        print("!" * 68)
    print()
    if tot_ep and holm_fire / tot_ep > 0.05:
        print("VERDICT: the probe fires too often on clean runs to ship.")
        print("  Report this as a negative result about the backstop rather")
        print("  than tuning alpha until it passes -- a threshold chosen to")
        print("  make the false-positive rate acceptable is not a")
        print("  false-positive rate.")
    else:
        print("VERDICT: false-positive rate is within the gate. The gap")
        print("  between the uncorrected and corrected rows is the argument")
        print("  for the correction; report both.")

    json.dump({"config": vars(a), "epochs": tot_ep, "raw": raw_fire,
               "holm": holm_fire, "survival": survival,
               "mean_drift": sum(dists)/max(len(dists), 1)},
              open(a.out, "w"), indent=2)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
