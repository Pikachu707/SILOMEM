#!/usr/bin/env python3
"""Can the compactor just tell us which inputs it used?

    python harness/observe_cite.py --model Qwen/Qwen2.5-7B-Instruct

Reviewer objection 3.5: the paper compares ablation against a location test
and never tries the obvious third option, which is to ask the summariser for
structured provenance. If a compactor can be instructed to emit the source IDs
it drew on, there is nothing to estimate: the attributed set is read off the
output, at no extra call, exactly.

This is the baseline that could make the paper's framing wrong, which is the
best reason to run it first. Two things have to hold for it to work:

  faithful   the IDs it cites are ones that actually shaped the summary
  complete   it cites every input that shaped the summary

Completeness is the one that matters, because a missing citation drops a
contributor from the meet exactly as a false negative does. A model that
under-cites has simply moved the false-negative problem inside the compactor,
where it is harder to see.

We measure both against the same identifier ground truth used elsewhere, and
we report the failure mode plainly if it appears. A compactor that cites
reliably would be better than anything else in this paper and we would say so.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from harness.observe_q1 import _check_pools, key_token, make_cluster

TASK = (
    "Summarise these notes for an invoice-triage agent in at most 40 words. "
    "Keep what matters for handling invoices.\n\n"
    "Then, on a second line beginning with SOURCES:, list the ID of every "
    "note whose content you used, separated by commas. Use only IDs that "
    "appear below. List every note you drew on, including any whose wording "
    "you changed.\n\n{body}"
)


def build_prompt(items):
    body = "\n".join(f"[{i+1}] {it['text']}" for i, it in enumerate(items))
    return TASK.format(body=body)


def parse(out, n):
    """Return (summary, cited indices). A missing or malformed SOURCES line
    is reported rather than silently treated as citing nothing, since those
    two cases have opposite implications for the method."""
    m = re.search(r"SOURCES:\s*(.*)", out, re.IGNORECASE)
    if not m:
        return out.strip(), None
    ids = {int(x) - 1 for x in re.findall(r"\d+", m.group(1))
           if 1 <= int(x) <= n}
    summary = out[:m.start()].strip()
    return summary, ids


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://localhost:8000/v1")
    ap.add_argument("--api-key-env", default="VLLM_KEY")
    ap.add_argument("--model", required=True)
    ap.add_argument("--clusters", type=int, default=60)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default="results/cite.json")
    a = ap.parse_args()
    key = os.environ.get(a.api_key_env, "local")
    _check_pools()

    import httpx
    mixes = [(4, 2), (3, 3), (2, 4)]
    obs, malformed = [], 0
    total = len(mixes) * a.clusters
    print(f"{total} clusters, one call each, asking for cited sources\n")

    done = 0
    for n_on, n_off in mixes:
        for c in range(a.clusters):
            rng = random.Random(f"{a.seed}|{n_on}|{n_off}|{c}")
            items = make_cluster(rng, n_on, n_off)
            r = httpx.post(f"{a.base_url}/chat/completions", timeout=180,
                           headers={"Authorization": f"Bearer {key}"},
                           json={"model": a.model, "max_tokens": 140,
                                 "temperature": 0.0,
                                 "messages": [{"role": "user",
                                               "content": build_prompt(items)}]})
            r.raise_for_status()
            out = r.json()["choices"][0]["message"]["content"]
            summary, cited = parse(out, len(items))
            if cited is None:
                malformed += 1
            cl = set() if cited is None else cited
            obs.append({"summary": summary, "cited": None if cited is None
                        else sorted(cited),
                        "items": [{"role": it["role"], "text": it["text"],
                                   "verdict": "present" if i in cl
                                              else "absent"}
                                  for i, it in enumerate(items)]})
            done += 1
            if done % 30 == 0:
                print(f"  {done}/{total}")

    # ground truth: identifier survives into the summary, as elsewhere
    tp = fp = fn = tn = 0
    for o in obs:
        if o["cited"] is None:
            continue
        cited = set(o["cited"])
        for i, it in enumerate(o["items"]):
            tok = key_token(it["text"])
            present = bool(tok) and tok in o["summary"]
            if i in cited and present:
                tp += 1
            elif i in cited:
                fp += 1
            elif present:
                fn += 1
            else:
                tn += 1
    n = tp + fp + fn + tn

    print("\n" + "=" * 66)
    print("Asking the compactor to cite its sources")
    print("=" * 66)
    print(f"  malformed or missing SOURCES line : {malformed}/{len(obs)} "
          f"({100*malformed/len(obs):.0f}%)")
    if n == 0:
        print("\n  No parseable citations at all. The compactor cannot be")
        print("  instructed to do this on this backend, which is itself the")
        print("  result: structured provenance is not free for the asking.")
        return
    print(f"  items scored                      : {n}")
    print(f"  cited and present   (TP)          : {tp}")
    print(f"  cited, not present  (FP)          : {fp}")
    print(f"  present, not cited  (FN)          : {fn}  "
          f"<-- these break the guarantee")
    print(f"  neither             (TN)          : {tn}")
    print()
    print(f"  attributed (cited)                : {100*(tp+fp)/n:.0f}%")
    print(f"  miss rate, of all items           : {100*fn/n:.1f}%")
    print(f"  miss rate, of true contributors   : {100*fn/max(tp+fn,1):.1f}%")
    print()
    print("  CAUTION. This FN is scored against \'the identifier appears in")
    print("  the summary\', and the summary and the SOURCES line come from ONE")
    print("  call, so the model can satisfy it by citing whatever it")
    print("  mentioned. The FP count shows it over-cites, which makes FN=0")
    print("  nearly free. The test cannot see an item that shaped the summary")
    print("  WITHOUT leaving an identifier; under this ground truth not citing")
    print("  such an item scores TN. Run harness/probe_grounded_fn.py against")
    print("  this file for the number that is not circular.")
    print()
    # The verdict has to account for summary quality, because the dual
    # task degrades it: measured 25% of summaries carrying no identifier at
    # all and a mean of 1.47 retained out of six inputs. A summary that
    # says nothing checkable cannot fail the identifier test, so it pads
    # the matrix with cases that cannot produce an FN.
    import re as _re
    empty = sum(1 for o in obs
                if not _re.search(r"\\b\\d{4}\\b", o["summary"]))
    cited_per = (tp + fp) / max(len(obs), 1)
    present_per = (tp + fn) / max(len(obs), 1)
    print(f"  summaries with no identifier      : {empty}/{len(obs)} "
          f"({100*empty/len(obs):.0f}%)")
    print(f"  cited per cluster                 : {cited_per:.2f}")
    print(f"  verifiable as present per cluster : {present_per:.2f}")
    print()
    if empty / max(len(obs), 1) > 0.10:
        print("  THE DUAL TASK DEGRADES THE SUMMARY. A quarter of summaries")
        print("  retain nothing the identifier test can check, and the model")
        print("  cites more items than are verifiable, so FN=0 follows by")
        print("  arithmetic rather than by faithfulness. Structured provenance")
        print("  is not free for the asking: it costs summary quality, and")
        print("  that cost is the result to report.")
    elif fn / max(tp + fn, 1) > 0.10:
        print("  UNDER-CITES. The compactor omits contributors from its own")
        print("  source list, moving the false-negative problem inside the")
        print("  model where there is no estimate to inspect.")
    else:
        print("  CITES CONSISTENTLY with its own summary text, on summaries")
        print("  that stayed informative. Whether it cites FAITHFULLY needs a")
        print("  judge, and the judge is unreliable on degraded summaries.")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump({"config": vars(a), "malformed": malformed,
               "tp": tp, "fp": fp, "fn": fn, "tn": tn,
               "observations": obs}, open(a.out, "w"), indent=1)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
