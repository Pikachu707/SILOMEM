#!/usr/bin/env python3
"""A location test for general content, with explicit abstention.

    python harness/observe_embed.py --model Qwen/Qwen2.5-7B-Instruct

The identifier-based location test of observe_grounded.py is sound but narrow:
real memory items do not always carry a distinctive number. The obvious
generalisation, embedding proximity with a cutoff, reintroduces exactly the
problem this paper documents, because a cutoff on a score errs in both
directions and one of those directions breaks the guarantee.

What preserves the construction is abstention. Compare each item's embedding
against the summary and against a reference set of items known not to be in
it. Attribute when the item is clearly closer to the summary; exclude only
when it is clearly farther; ABSTAIN, and therefore attribute, when the margin
is small. The abstention band is not a tuned operating point: widening it can
only move items from "excluded" to "attributed", which is the safe direction,
so a defender who does not know what to set can set it wide and lose
precision rather than soundness.

    attribute  if  sim(item, summary) > hi
    exclude    if  sim(item, summary) < lo
    attribute  otherwise                        (abstain)

with lo < hi. Soundness needs only that a true contributor never falls below
lo, and the measurement below reports how often it does at several band
widths, against the same independent judge used for the identifier test.

WHAT WOULD SINK THIS. If no band both excludes a useful fraction and keeps the
judged false-negative rate low, the generalisation fails and the method stays
identifier-bound. That is a real possibility and the script reports it
plainly.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from harness.observe_q1 import _check_pools, make_cluster, summarise


def encode(texts):
    from sentence_transformers import SentenceTransformer
    m = SentenceTransformer("all-MiniLM-L6-v2")
    uniq = sorted(set(texts))
    vecs = m.encode(uniq, normalize_embeddings=True, batch_size=128,
                    show_progress_bar=False)
    return {t: vecs[i] for i, t in enumerate(uniq)}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://localhost:8000/v1")
    ap.add_argument("--api-key-env", default="VLLM_KEY")
    ap.add_argument("--model", required=True)
    ap.add_argument("--clusters", type=int, default=60)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default="results/embed_located.json")
    a = ap.parse_args()
    key = os.environ.get(a.api_key_env, "local")
    _check_pools()

    mixes = [(4, 2), (3, 3), (2, 4)]
    obs = []
    print(f"{len(mixes)*a.clusters} clusters, one summary each, no probing\n")
    done = 0
    for n_on, n_off in mixes:
        for c in range(a.clusters):
            rng = random.Random(f"{a.seed}|{n_on}|{n_off}|{c}")
            items = make_cluster(rng, n_on, n_off)
            s = summarise(a.base_url, a.model, key, items)
            obs.append({"summary": s,
                        "items": [{"role": it["role"], "text": it["text"]}
                                  for it in items]})
            done += 1
            if done % 30 == 0:
                print(f"  {done}/{len(mixes)*a.clusters}")

    print("\nencoding")
    texts = [o["summary"] for o in obs] + [it["text"] for o in obs
                                           for it in o["items"]]
    vec = encode(texts)
    for o in obs:
        sv = vec[o["summary"]]
        for it in o["items"]:
            it["sim"] = float(vec[it["text"]] @ sv)

    sims = sorted(it["sim"] for o in obs for it in o["items"])
    n = len(sims)
    print(f"\nsimilarity distribution over {n} items:")
    for p in (10, 25, 50, 75, 90):
        print(f"  p{p:<3} {sims[int(n*p/100)-1]:.3f}")

    # Sweep bands. `lo` is what decides exclusions; `hi` only marks the
    # confident-attribute region and does not affect soundness, since
    # everything between lo and hi is attributed anyway.
    print("\n" + "=" * 66)
    print("Abstention bands. Widening the band moves items from excluded to")
    print("attributed, which is the safe direction, so `lo` is the only")
    print("parameter that can break soundness.")
    print("=" * 66)
    print(f"{'lo':>7}{'excluded':>11}{'attributed':>12}{'on-topic excl.':>16}")
    print("-" * 46)
    rows = []
    for lo in [round(x, 2) for x in
               [sims[int(n * p / 100) - 1] for p in (10, 20, 30, 40, 50)]]:
        exc = [it for o in obs for it in o["items"] if it["sim"] < lo]
        att = len([1 for o in obs for it in o["items"]]) - len(exc)
        on_exc = sum(1 for it in exc if it["role"] == "ontopic")
        print(f"{lo:>7.2f}{100*len(exc)/n:>10.0f}%{100*att/n:>11.0f}%"
              f"{on_exc:>10} / {sum(1 for o in obs for it in o['items'] if it['role']=='ontopic')}")
        rows.append({"lo": lo, "excluded_frac": len(exc)/n,
                     "attributed_frac": att/n, "ontopic_excluded": on_exc})

    print("\nOn-topic items are not ground truth on their own: the summary has")
    print("a word budget and omits some of them legitimately. Run")
    print("harness/probe_grounded_fn.py against this file to get the judged")
    print("false-negative rate, which is the number that decides whether a")
    print("band is usable.")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump({"config": vars(a), "bands": rows,
               "observations": [{"summary": o["summary"],
                                 "items": [{"role": it["role"],
                                            "text": it["text"],
                                            "sim": it["sim"],
                                            "verdict": "absent"
                                            if it["sim"] < rows[2]["lo"]
                                            else "present"}
                                           for it in o["items"]]}
                                for o in obs],
               "n": n}, open(a.out, "w"), indent=1)
    print(f"\nwrote {a.out}  (verdicts stamped at lo={rows[2]['lo']:.2f})")


if __name__ == "__main__":
    main()
