#!/usr/bin/env python3
"""Do the excluded items really contribute nothing?

    python harness/probe_grounded_fn.py --model Qwen/Qwen2.5-7B-Instruct

WHY THIS IS SEPARATE. observe_grounded.py reports zero false negatives, and
that zero is a tautology: `locate` judges an item "absent" only when its
identifier is missing from the summary, and the soundness gate asks whether
any item with its identifier present was judged absent. No implementation
could fail that check. It verifies the code against the specification and
says nothing about whether the specification is right.

The specification is right only if an item that shapes a summary always
leaves its identifier in it. That is the assumption the whole method rests
on, and testing it needs a signal that is not string matching.

So this asks the model. For each excluded item we present the summary and the
item and ask whether the summary reflects that item's content. A yes means
the item influenced the summary without leaving its identifier, which is a
false negative that the string-matching ground truth is blind to.

The judge is imperfect and its errors run in a known direction: asked whether
a summary "reflects" a note about the same general subject, a model tends to
say yes. That makes this an UPPER bound on the false-negative rate, which is
the conservative direction for a soundness claim.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys
import time

import httpx

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

JUDGE = (
    "A summary was written from several notes. Below are the summary and ONE "
    "note.\n\nSummary: {s}\n\nNote: {n}\n\nDid the content of this specific "
    "note make it into the summary? Answer with one word, YES or NO. Answer "
    "NO if the summary covers a different item, even one of the same kind."
)


def check_server(url, model, key):
    """Fail before spending 180 calls, not on call 1 of 180.

    The judge scripts crash on a refused connection and lose whatever they
    had already judged. The usual cause is that the batch runner pkills vLLM
    when it finishes, so a judging pass started afterwards has nothing to
    talk to."""
    try:
        r = httpx.get(f"{url}/models", timeout=15,
                      headers={"Authorization": f"Bearer {key}"})
        served = [m["id"] for m in r.json()["data"]]
    except Exception as e:
        raise SystemExit(
            f"cannot reach {url}: {e}\n"
            "Start vLLM before judging:\n"
            "  nohup python -m vllm.entrypoints.openai.api_server \\\n"
            "    --model <model> --port 8000 --max-num-seqs 64 &")
    if model not in served:
        raise SystemExit(f"{url} serves {served}, not {model}. A request for "
                         "an unserved model returns 404, not an error you "
                         "would recognise.")


def ask(url, model, key, summary, note, retries=3, prompt=None):
    """`prompt`, when given, replaces the contribution question with a
    caller-supplied one. run_crossmem asks a different question of the same
    judge and needs the same retry and error handling."""
    for attempt in range(retries):
        try:
            return _ask_once(url, model, key, summary, note, prompt)
        except (httpx.ConnectError, httpx.ReadTimeout) as e:
            if attempt == retries - 1:
                raise
            time.sleep(2 ** attempt)


def _ask_once(url, model, key, summary, note, prompt=None):
    r = httpx.post(f"{url}/chat/completions", timeout=180,
                   headers={"Authorization": f"Bearer {key}"},
                   json={"model": model, "max_tokens": 5, "temperature": 0.0,
                         "messages": [{"role": "user",
                                       "content": prompt or JUDGE.format(
                                           s=summary, n=note)}]})
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"].strip().upper()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default="http://localhost:8000/v1")
    ap.add_argument("--api-key-env", default="VLLM_KEY")
    ap.add_argument("--model", required=True)
    ap.add_argument("--grounded", default="results/grounded_qwen7b.json")
    ap.add_argument("--sample", type=int, default=120,
                    help="excluded items to judge")
    ap.add_argument("--out", default="results/grounded_fn.json")
    a = ap.parse_args()
    key = os.environ.get(a.api_key_env, "local")
    check_server(a.base_url, a.model, key)

    d = json.load(open(a.grounded))
    excluded = [(o["summary"], it) for o in d["observations"]
                for it in o["items"] if it["verdict"] == "absent"]
    # Control items are chosen by DEMONSTRATED presence, not by the verdict
    # of the method under test. Sampling the method's own attributions makes
    # the control measure that method's precision instead of the judge's
    # reliability, and a method that attributes liberally then voids its own
    # measurement.
    from harness.observe_q1 import key_token
    attributed = []
    for o in d["observations"]:
        for it in o["items"]:
            tok = key_token(it["text"])
            if tok and tok in o["summary"]:
                attributed.append((o["summary"], it))
    rng = random.Random(0)
    exc = rng.sample(excluded, min(a.sample, len(excluded)))
    att = rng.sample(attributed, min(a.sample // 2, len(attributed)))

    print(f"judging {len(exc)} excluded items and {len(att)} attributed ones")
    print("control items are ones whose identifier is demonstrably in the")
    print("summary, chosen independently of the method under test. The judge")
    print("should say YES to nearly all of them; if it does not, the judge is")
    print("unreliable and the run is void.\n")

    fn = 0
    for i, (s, it) in enumerate(exc, 1):
        if ask(a.base_url, a.model, key, s, it["text"]).startswith("YES"):
            fn += 1
        if i % 40 == 0:
            print(f"  {i}/{len(exc)} excluded judged")
    ctrl = 0
    for s, it in att:
        if ask(a.base_url, a.model, key, s, it["text"]).startswith("YES"):
            ctrl += 1

    fn_rate = fn / len(exc)
    ctrl_rate = ctrl / len(att) if att else float("nan")
    # `n` is written by observe_grounded; observe_embed and observe_domain2
    # write observations without it. Derive it rather than requiring the key,
    # so any file carrying per-item verdicts can be judged.
    total_items = d.get("n") or sum(len(o["items"]) for o in d["observations"])
    excluded_frac = len(excluded) / total_items

    print("\n" + "=" * 68)
    print("Independent check of the exclusions")
    print("=" * 68)
    print(f"  control, demonstrably present items judged to contribute: "
          f"{100*ctrl_rate:.0f}%")
    print(f"  excluded items the judge says DID contribute        : "
          f"{100*fn_rate:.0f}%")
    print(f"  as a fraction of all items                          : "
          f"{100*fn_rate*excluded_frac:.1f}%")
    print()
    if ctrl_rate < 0.8:
        print("JUDGE UNRELIABLE. It fails to recognise contribution even for")
        print("items whose identifier is in the summary, so its verdicts on")
        print("the excluded items carry no weight. Nothing below the control")
        print("line can be read.")
    elif fn_rate * excluded_frac > 0.05:
        print("THE METHOD IS NOT SOUND. Items are being excluded that an")
        print("independent judge says reached the summary, at a rate that")
        print("would break the guarantee on a meaningful fraction of")
        print("clusters. Identifier survival is too narrow a test for")
        print("contribution, and the paper must say so rather than report")
        print("the tautological zero.")
    else:
        print("SOUNDNESS SURVIVES AN INDEPENDENT CHECK. The excluded items")
        print("are judged non-contributors by a signal that is not string")
        print("matching, at a rate low enough not to threaten the guarantee.")
        print("This is the number to report, not the zero from the")
        print("construction check.")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump({"config": vars(a), "n_excluded_judged": len(exc),
               "fn_among_excluded": fn_rate, "control_rate": ctrl_rate,
               "fn_of_all_items": fn_rate * excluded_frac},
              open(a.out, "w"), indent=1)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
