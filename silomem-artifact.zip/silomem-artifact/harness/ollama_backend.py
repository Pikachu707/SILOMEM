"""A concrete Compactor and Regenerator backed by Ollama.

This fills the two `TODO(you)` holes in backends.HostedBackend. It is
deliberately minimal: the summarisation prompt is generic, because the point
of the harness is to measure PROVENIRE's labelling behaviour, not to tune a
prompt.

WHEN YOU WRAP A REAL FRAMEWORK, REPLACE THIS. Section 4.7 says the wrapper
sits outside the base compactor's clustering, so `cluster()` should delegate
to the framework's own clusterer rather than the size-k chunking used here.
Chunking by size is a stand-in that lets the rest of the evaluation run; it is
not a claim about how real compactors group items.
"""
from __future__ import annotations

import hashlib
import os
import re
import time
from dataclasses import dataclass, field
from typing import Sequence

from provenire.lattice import Item

SUMMARISE_PROMPT = (
    "You are an agent's memory compactor. Merge these notes into ONE entry "
    "of at most 35 words. Write the entry only, no preamble.\n\n{items}"
)


@dataclass
class OllamaBackend:
    """Compactor + Regenerator over a local Ollama daemon.

    Caching is on by default and matters more than anything else here: the
    defended and undefended arms replay the same trajectories, and
    leave-one-out probing re-summarises near-identical clusters thousands of
    times. Without the cache this is a different experiment entirely.
    """

    model: str = "qwen2.5:0.5b-instruct"
    base_url: str = "http://localhost:11434/v1"
    api_key_env: str = "OLLAMA_KEY"
    cache_dir: str = ".cache/llm"
    cluster_size: int = 4
    timeout: float = 600.0
    max_retries: int = 4
    max_tokens: int = 64      # a memory entry is short; small models ramble
    rps: float = 0.0
    verbose: bool = True      # a 40-minute run should not be silent
    strip_think: bool = True

    calls: int = field(default=0, init=False)
    cached: int = field(default=0, init=False)
    throttled: int = field(default=0, init=False)
    _last: float = field(default=0.0, init=False)
    _t0: float = field(default_factory=lambda: __import__("time").monotonic(),
                       init=False)

    def __post_init__(self) -> None:
        os.makedirs(self.cache_dir, exist_ok=True)

    # -- the one network call -----------------------------------------
    def _complete(self, prompt: str) -> str:
        key = hashlib.blake2b((self.model + "\0" + prompt).encode(),
                              digest_size=16).hexdigest()
        path = os.path.join(self.cache_dir, key + ".txt")
        if os.path.exists(path):
            self.cached += 1
            return open(path).read()

        import httpx

        if self.rps > 0:
            wait = 1.0 / self.rps - (time.monotonic() - self._last)
            if wait > 0:
                time.sleep(wait)
            self._last = time.monotonic()

        last = None
        for attempt in range(self.max_retries + 200):  # 429 waits are free
            try:
                r = httpx.post(
                    f"{self.base_url}/chat/completions",
                    headers={"Authorization":
                             f"Bearer {os.environ.get(self.api_key_env, 'local')}"},
                    json={"model": self.model,
                          "messages": [{"role": "user", "content": prompt}],
                          "temperature": 0.0,
                          "max_tokens": self.max_tokens,
                          "stop": ["\n\n"]},
                    timeout=self.timeout,
                )
                if r.status_code == 429:
                    # Honour Retry-After, or the seconds the body names,
                    # before falling back to exponential backoff.
                    wait = None
                    ra = r.headers.get("retry-after")
                    if ra:
                        try:
                            wait = float(ra)
                        except ValueError:
                            wait = None
                    if wait is None:
                        m = re.search(r"try again in ([0-9.]+)\s*s", r.text)
                        wait = float(m.group(1)) if m else min(2 ** attempt, 30)
                    time.sleep(wait + 0.5)
                    self.throttled += 1
                    continue
                if r.status_code >= 400:
                    # Surface the BODY. A bare status code is useless: ollama
                    # puts the real reason ("model not found", "context
                    # length exceeded") in the payload, and swallowing it
                    # turns a one-line fix into an afternoon.
                    body = r.text[:400]
                    if 400 <= r.status_code < 500:
                        # a client error will not fix itself; do not burn
                        # four retries on it
                        raise RuntimeError(
                            f"HTTP {r.status_code} from {self.base_url}\n"
                            f"  response: {body}\n"
                            f"  model requested: {self.model!r}\n"
                            f"  check `ollama list` for the exact tag")
                    raise httpx.HTTPStatusError(
                        f"HTTP {r.status_code}: {body}",
                        request=r.request, response=r)
                text = r.json()["choices"][0]["message"]["content"]
                if self.strip_think:
                    # A reasoning model's traces vary run to run, which would
                    # make leave-one-out probing see spurious change and
                    # inflate the attributed cluster size. Strip them if
                    # present, and prefer an instruct model in the first place.
                    text = re.sub(r"<think>.*?</think>", "", text,
                                  flags=re.S).strip()
                tmp = path + f".{os.getpid()}.tmp"
                with open(tmp, "w") as fh:
                    fh.write(text)
                os.replace(tmp, path)   # atomic: several probes write at once
                self.calls += 1
                if self.verbose and self.calls % 10 == 0:
                    el = time.monotonic() - self._t0
                    print(f"    [backend] {self.calls} calls, "
                          f"{self.cached} cached, {el/60:.1f} min, "
                          f"{el/max(1,self.calls):.0f} s/call", flush=True)
                return text
            except RuntimeError:
                raise                       # client error: propagate at once
            except Exception as e:  # noqa: BLE001
                last = e
                if attempt < self.max_retries - 1:
                    time.sleep(min(2 ** attempt, 20))
        raise RuntimeError(
            f"ollama failed after {self.max_retries} attempts.\n"
            f"  last error : {last}\n"
            f"  endpoint   : {self.base_url}/chat/completions\n"
            f"  model      : {self.model!r}\n"
            f"  prompt len : {len(prompt)} chars\n"
            f"Check, in this order:\n"
            f"  ollama ps                       # is the model resident?\n"
            f"  ollama list                     # is the tag exactly right?\n"
            f"  ps aux | grep '[o]llama serve'  # exactly one daemon?\n"
            f"  tail -40 /tmp/ollama.log        # the daemon's own error\n"
            f"A 500 right after diagnose2.sh or sweep_threads.sh usually\n"
            f"means those scripts left the daemon in a bad state. Restart:\n"
            f"  pkill -f 'ollama serve'; sleep 2\n"
            f"  OLLAMA_NUM_THREAD=6 OLLAMA_KEEP_ALIVE=60m nohup ollama serve \\\n"
            f"      > /tmp/ollama.log 2>&1 &")

    # -- Compactor -----------------------------------------------------
    def cluster(self, items: Sequence[Item]) -> list[list[Item]]:
        items = list(items)
        k = self.cluster_size
        return [items[i:i + k] for i in range(0, len(items), k)] or [[]]

    def summarise(self, cluster: Sequence[Item]) -> str:
        if not cluster:
            return ""
        body = "\n".join(f"- {it.text}" for it in cluster)
        return self._complete(SUMMARISE_PROMPT.format(items=body))

    # -- Regenerator ---------------------------------------------------
    def regenerate(self, context: Sequence[Item], withheld: Item) -> str:
        return self.summarise([it for it in context
                               if it.item_id != withheld.item_id])

    def report(self) -> str:
        extra = (f", {self.throttled} rate-limit waits"
                 if self.throttled else "")
        total = self.calls + self.cached
        pct = 100 * self.cached / total if total else 0
        return (f"{self.calls:,} live calls, {self.cached:,} cache hits "
                f"({pct:.0f}% hit rate){extra}")
