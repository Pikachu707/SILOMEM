#!/usr/bin/env python3
"""Screen candidate models before spending hours on them.

Two things disqualify a model for this harness, and both are invisible until
you look:

  1. REASONING TRACES. A model that emits <think> blocks, or puts reasoning
     in a separate field, produces summaries that vary run to run for reasons
     unrelated to their inputs. Leave-one-out probing compares summaries for
     semantic change, so that variance is read as influence and inflates the
     attributed cluster size `a`. A model-comparison experiment then measures
     which model reasons more verbosely, not how the estimator behaves.

  2. NON-DETERMINISM at temperature 0. The on-disk cache assumes the same
     prompt yields the same completion. If it does not, the cache silently
     serves a stale answer and every repeat measurement is wrong.

This sends each candidate the same prompt twice and reports both.

    python harness/probe_models.py --backend groq \\
        --models openai/gpt-oss-20b,openai/gpt-oss-120b,qwen/qwen3.6-27b
"""
from __future__ import annotations

import argparse
import os
import re
import sys
import time

PRESETS = {
    "groq":   ("https://api.groq.com/openai/v1", "GROQ_API_KEY"),
    "lambda": ("https://api.lambda.ai/v1", "LAMBDA_API_KEY"),
    "openai": ("https://api.openai.com/v1", "OPENAI_API_KEY"),
    "ollama": ("http://localhost:11434/v1", "OLLAMA_KEY"),
}

PROMPT = ("You are an agent's memory compactor. Merge these notes into ONE "
          "entry of at most 35 words. Write the entry only, no preamble.\n\n"
          "- vendor onboarding: net-30 terms confirmed by finance\n"
          "- invoice 4417 approved by the team lead on 12 March\n"
          "- procurement asks that vendor docs be filed in the shared drive\n"
          "- vendor X support contact is support@example.invalid\n")


def call(url, model, key, timeout=120):
    import httpx
    t0 = time.perf_counter()
    r = httpx.post(f"{url}/chat/completions",
                   headers={"Authorization": f"Bearer {key}"},
                   json={"model": model,
                         "messages": [{"role": "user", "content": PROMPT}],
                         "temperature": 0.0, "max_tokens": 96},
                   timeout=timeout)
    dt = time.perf_counter() - t0
    if r.status_code >= 400:
        return None, dt, f"HTTP {r.status_code}: {r.text[:120]}"
    return r.json(), dt, None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--backend", choices=sorted(PRESETS), default="groq")
    ap.add_argument("--base-url", default=None)
    ap.add_argument("--api-key-env", default=None)
    ap.add_argument("--models", required=True, help="comma separated")
    ap.add_argument("--gap", type=float, default=2.5,
                    help="seconds between calls; free tiers are ~30 RPM")
    a = ap.parse_args()

    url, env = PRESETS[a.backend]
    url, env = a.base_url or url, a.api_key_env or env
    key = os.environ.get(env, "local")

    print("=" * 74)
    print(f"Screening {len(a.models.split(','))} models at {url}")
    print("=" * 74)

    verdicts = []
    for model in [m.strip() for m in a.models.split(",") if m.strip()]:
        print(f"\n--- {model}")
        try:
            j1, t1, err = call(url, model, key)
            if err:
                print(f"    {err}")
                verdicts.append((model, "UNUSABLE", err[:40]))
                continue
            time.sleep(a.gap)
            j2, t2, _ = call(url, model, key)
        except Exception as e:  # noqa: BLE001
            print(f"    failed: {e}")
            verdicts.append((model, "UNUSABLE", str(e)[:40]))
            continue

        m1 = j1["choices"][0]["message"]
        c1 = (m1.get("content") or "").strip()
        c2 = (j2["choices"][0]["message"].get("content") or "").strip()
        reasoning_field = m1.get("reasoning") or m1.get("reasoning_content")
        inline_think = bool(re.search(r"<think>|</think>", c1))
        usage = j1.get("usage", {})

        print(f"    latency      {t1:.2f}s")
        print(f"    completion   {usage.get('completion_tokens','?')} tokens")
        print(f"    content      {c1[:100]!r}")
        if reasoning_field:
            print(f"    reasoning    separate field, "
                  f"{len(reasoning_field)} chars")
        if inline_think:
            print("    reasoning    INLINE <think> inside content")
        print(f"    deterministic {'yes' if c1 == c2 else 'NO -- repeats differ'}")

        if inline_think:
            v = ("REJECT", "inline reasoning contaminates the summary")
        elif c1 != c2:
            v = ("REJECT", "non-deterministic at temp 0; the cache breaks")
        elif not c1:
            v = ("REJECT", "empty content")
        elif reasoning_field:
            v = ("OK*", "reasoning is in a separate field, content is clean")
        else:
            v = ("OK", "")
        verdicts.append((model, v[0], v[1]))

    print()
    print("=" * 74)
    print(f"{'model':<34} {'verdict':<9} note")
    print("-" * 74)
    for m, v, n in verdicts:
        print(f"{m:<34} {v:<9} {n}")
    print()
    print("Use only OK / OK* models. A rejected model will still produce")
    print("numbers -- they will just be measuring the wrong thing, and a")
    print("model comparison built on them measures verbosity, not the")
    print("estimator.")


if __name__ == "__main__":
    main()
