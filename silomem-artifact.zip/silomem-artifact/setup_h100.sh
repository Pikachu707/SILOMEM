#!/usr/bin/env bash
# Bring up vLLM on an H100 and run everything.
#
# On an 80GB card the workload is trivially small -- a 7B model uses under
# 20GB and the whole remaining grid is minutes. The card's real value here is
# not speed: it is that there is NO RATE LIMIT, so a bug found halfway
# through costs a re-run rather than another three hours of waiting. This
# project has found five harness bugs so far; every one needed a re-run.
#
# The second thing 80GB buys is RQ4. Groq's catalog gives a narrow capability
# range; locally you can serve 0.5B, 7B, 32B and a quantised 70B at the SAME
# config, which is a far better test of whether the attributed cluster size
# rises with backend capability.
set -uo pipefail
hr() { printf '%.0s=' {1..70}; echo; }

MODEL="${MODEL:-Qwen/Qwen2.5-7B-Instruct}"
PORT="${PORT:-8000}"

hr; echo "vLLM on $(nvidia-smi --query-gpu=name,memory.total --format=csv,noheader)"; hr

# A freshly imaged host has PEP 668 in force: pip refuses to touch the system
# Python and the error it prints is about apt, not about vllm. Create a venv
# first, and re-exec inside it so the rest of this script and every later
# command see the same interpreter.
if [ -z "${VIRTUAL_ENV:-}" ]; then
  if [ ! -d .venv ]; then
    echo "creating .venv"
    python3 -m venv .venv || {
      echo "FATAL: python3 -m venv failed. On a new image run:"
      echo "  sudo apt-get update && sudo apt-get install -y python3-venv"
      exit 1; }
  fi
  echo "activating .venv"
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi

if ! python -c "import vllm" 2>/dev/null; then
  echo "installing vllm (10-15 minutes on a fresh host)"
  pip install -q --upgrade pip
  pip install vllm || {
    echo "FATAL: vllm install failed. The next check will say vLLM rejects"
    echo "its own arguments, which is this failure and not an argument bug."
    exit 1; }
fi

# the experiment harness needs these too, and finding out later costs a run
python -c "import httpx" 2>/dev/null || pip install -q httpx
python -c "import sentence_transformers" 2>/dev/null || \
  pip install -q sentence-transformers

# vLLM's flag names drift between releases (--disable-log-requests became
# --no-enable-log-requests). Ask the installed version rather than guessing.
QUIET=""
if python -m vllm.entrypoints.openai.api_server --help 2>&1 | grep -q -- "--no-enable-log-requests"; then
  QUIET="--no-enable-log-requests"
elif python -m vllm.entrypoints.openai.api_server --help 2>&1 | grep -q -- "--disable-log-requests"; then
  QUIET="--disable-log-requests"
fi

echo "checking the launch line before backgrounding it"
# A process launched into nohup that dies on a bad argument looks exactly
# like a slow start. Validate the arguments first; --help exits non-zero on
# an unrecognised flag, which is what we want to catch here.
if ! python -m vllm.entrypoints.openai.api_server $QUIET --help >/dev/null 2>&1; then
  echo "FATAL: vLLM rejects these arguments. Run this to see why:"
  echo "  python -m vllm.entrypoints.openai.api_server $QUIET --help"
  exit 1
fi

echo "serving $MODEL on :$PORT"
# --max-num-seqs is what lets concurrent leave-one-out probes batch. The
# default is high enough; it is the CLIENT that has to send them at once.
nohup python -m vllm.entrypoints.openai.api_server \
  --model "$MODEL" --port "$PORT" --max-num-seqs 64 \
  $QUIET > /tmp/vllm.log 2>&1 &

echo -n "waiting for the server"
for i in $(seq 1 360); do   # first run downloads ~15GB
  if curl -s "http://localhost:$PORT/v1/models" >/dev/null 2>&1; then
    echo " up"; break; fi
  echo -n "."; sleep 5
  if ! pgrep -f "vllm.entrypoints" >/dev/null; then
    echo; echo "the server process died. tail -40 /tmp/vllm.log:"; tail -40 /tmp/vllm.log; exit 1
  fi
done
echo

export VLLM_KEY=local
python harness/check_backend.py --base-url "http://localhost:$PORT/v1" \
    --api-key-env VLLM_KEY --model "$MODEL" || {
  echo "server not answering; tail -40 /tmp/vllm.log"; exit 1; }

hr; echo "measuring sustainable throughput"; hr
python harness/bench_rpm.py --base-url "http://localhost:$PORT/v1" \
    --api-key-env VLLM_KEY --model "$MODEL" --burst 40 --parallel 16

hr
echo "Now run, with concurrency -- a single stream leaves an H100 idle:"
echo
echo "  MODEL=$MODEL BK=vllm bash run_all_local.sh"
echo
echo "or a single sweep:"
echo "  python harness/run_rq2.py --backend vllm --model $MODEL \\"
echo "      --loo-workers 32 --seeds 5 --horizon 96 --budget-items 32 \\"
echo "      --keep-frac 0 --sweep-u 0.05,0.1,0.2,0.3,0.4 \\"
echo "      --declass-rate 0.5 --max-calls 0 --out results/vllm_usweep.json"
