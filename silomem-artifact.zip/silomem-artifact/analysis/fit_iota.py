#!/usr/bin/env python3
"""Fit Eq. (iota) to the measured results and locate the crossing.

    python analysis/fit_iota.py results/

Does three things the paper needs:

  1. tests whether the measured influx follows phi*(1-(1-u)^m). The formula
     fixes the dependence on m, so a sweep over m can only confirm or refute
     it -- if iota does not move with m, phi was a coincidence of one
     parameter setting and the reachability criterion does not hold;
  2. reports the crossing u at which a given over-tainting budget becomes
     unreachable;
  3. compares measured TER against the closed recurrence and against the
     influx form, at the OBSERVED round count rather than the fixed point.
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from analysis.prop2 import finite_horizon, with_influx


def load(d):
    out = []
    for f in sorted(glob.glob(os.path.join(d, "*.json"))):
        try:
            j = json.load(open(f))
        except Exception:  # noqa: BLE001
            continue
        c = j.get("config", {})
        for r in j.get("rows", []):
            out.append({"file": os.path.basename(f), "model": c.get("model", "?"),
                        "d": c.get("declass_rate", 0), "m": c.get("n_items", 5),
                        "u": r.get("u", 0), "ter": r.get("ter", 0),
                        "ci": r.get("ter_ci", [0, 0]), "iota": r.get("iota", -1),
                        "a": r.get("a", 0), "rounds": int(r.get("rounds", 0)),
                        "n": r.get("n_items", 0)})
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("results", nargs="?", default="results")
    ap.add_argument("--budget", type=float, default=0.20,
                    help="over-tainting budget whose reachability we test")
    a = ap.parse_args()
    rows = [r for r in load(a.results) if r["iota"] >= 0]
    if not rows:
        print("no rows with a measured iota; run the sweeps first")
        sys.exit(1)

    # ---- 1. does iota follow the predicted form? --------------------
    print("=" * 74)
    print("Eq. (iota):  iota ~= phi * (1 - (1-u)^m)")
    print("=" * 74)
    print(f"{'model':<22}{'m':>3}{'u':>6}{'iota meas':>11}{'1-(1-u)^m':>11}{'phi':>7}")
    print("-" * 74)
    phis = []
    for r in sorted(rows, key=lambda r: (r["model"], r["m"], r["u"])):
        p = 1 - (1 - r["u"]) ** r["m"]
        if p <= 0:
            continue
        phi = r["iota"] / p
        phis.append((r["m"], phi))
        print(f"{r['model'][-22:]:<22}{r['m']:>3}{r['u']:>6.2f}"
              f"{r['iota']:>11.3f}{p:>11.3f}{phi:>7.2f}")

    if phis:
        vals = [p for _, p in phis]
        mean = sum(vals) / len(vals)
        sd = (sum((x - mean) ** 2 for x in vals) / len(vals)) ** 0.5
        print(f"\nphi = {mean:.3f}  sd {sd:.3f}  over {len(vals)} points")
        by_m = {}
        for m, p in phis:
            by_m.setdefault(m, []).append(p)
        if len(by_m) > 1:
            print("\nphi by m -- the formula says this should be FLAT:")
            for m in sorted(by_m):
                v = by_m[m]
                print(f"  m={m:<3} phi={sum(v)/len(v):.3f}  (n={len(v)})")
            spread = max(sum(v)/len(v) for v in by_m.values()) - \
                min(sum(v)/len(v) for v in by_m.values())
            print(f"  spread {spread:.3f} -- "
                  + ("consistent with the form" if spread < 0.15 else
                     "NOT flat. Eq. (iota) does not hold; the criterion in "
                     "Sec. 4 has to be withdrawn or reformulated."))

        # ---- 2. the crossing --------------------------------------
        print()
        print("=" * 74)
        print(f"Reachability of a {a.budget:.2f} over-tainting budget")
        print("=" * 74)
        print(f"{'m':>4}{'crossing u':>13}   verdict below / above")
        print("-" * 50)
        for m in sorted(by_m) or [5]:
            # solve phi*(1-(1-u)^m) = budget
            if a.budget / mean >= 1:
                print(f"{m:>4}{'always':>13}   floor never binds")
                continue
            u_star = 1 - (1 - a.budget / mean) ** (1.0 / m)
            print(f"{m:>4}{u_star:>13.3f}   reachable / UNREACHABLE")

    # ---- 3. model vs measurement ------------------------------------
    print()
    print("=" * 74)
    print("Measured TER vs the recurrence, at the OBSERVED round count")
    print("=" * 74)
    print(f"{'u':>5}{'d':>5}{'rnds':>5}{'TER':>8}{'95% CI':>16}"
          f"{'closed':>8}{'+influx':>9}{'in CI':>7}")
    print("-" * 74)
    hits = tot = 0
    for r in sorted(rows, key=lambda r: (r["d"], r["u"])):
        if not r["rounds"] or r["a"] < 1:
            continue
        c = finite_horizon(r["a"], r["d"], r["rounds"])
        w = with_influx(r["a"], r["d"], r["rounds"], r["iota"])
        lo, hi = r["ci"]
        ok = lo <= w <= hi
        hits += ok
        tot += 1
        print(f"{r['u']:>5.2f}{r['d']:>5.2f}{r['rounds']:>5}{r['ter']:>8.3f}"
              f" [{lo:>5.3f},{hi:>5.3f}]{c:>8.3f}{w:>9.3f}"
              f"{'yes' if ok else 'NO':>7}")
    if tot:
        print(f"\n{hits}/{tot} points inside the 95% interval with influx.")
        print("The closed column is expected to sit BELOW the measurement and")
        print("the gap to widen with d; that is the signature of a missing")
        print("floor and it is the paper's central claim.")


if __name__ == "__main__":
    main()
