#!/usr/bin/env python3
"""How many model calls does this evaluation actually need?

Run this before you spend anything. It does the arithmetic for the protocol
of Section 6.1 and shows where the calls go, because the answer is not
uniform: leave-one-out probing dominates everything else, and three of the
apparent multipliers cost nothing at all.

Usage:
    python analysis/cost.py                    # defaults
    python analysis/cost.py --loo-off          # what LOO costs you
    python analysis/cost.py --price 0.15 0.60  # $/Mtok in, out
"""
from __future__ import annotations

import argparse


def estimate(*, seeds, attacks, horizon, memory_items, cluster_size,
             loo_enabled, loo_max_cluster, tok_in, tok_out,
             price_in, price_out, cache_hit_rate):
    clusters_per_round = max(1, memory_items // cluster_size)

    summarise_per_traj = clusters_per_round * horizon
    if loo_enabled and cluster_size <= loo_max_cluster:
        loo_per_traj = clusters_per_round * cluster_size * horizon
    else:
        loo_per_traj = 0

    per_traj = summarise_per_traj + loo_per_traj

    # --- what actually multiplies, and what does not ------------------
    # Trajectories you must genuinely run:
    #   seeds x attacks   for the attack arm
    #   seeds             for the benign arm (utility; no attack present)
    attack_trajs = seeds * attacks
    benign_trajs = seeds
    real_trajs = attack_trajs + benign_trajs

    # Free multipliers, listed so you do not budget for them:
    #   strict vs permissive  -- a lookup in Table 2 after the fact, 0 calls
    #   defended vs undefended -- replays the SAME trajectory, all cache hits
    #   the four horizons     -- snapshots of one K=20 run, not four runs
    gross = real_trajs * per_traj
    net = gross * (1 - cache_hit_rate)

    tokens_in = net * tok_in
    tokens_out = net * tok_out
    usd = tokens_in / 1e6 * price_in + tokens_out / 1e6 * price_out

    return {
        "clusters_per_round": clusters_per_round,
        "summarise_per_traj": summarise_per_traj,
        "loo_per_traj": loo_per_traj,
        "per_traj": per_traj,
        "attack_trajs": attack_trajs,
        "benign_trajs": benign_trajs,
        "gross_calls": gross,
        "net_calls": int(net),
        "tokens_in": int(tokens_in),
        "tokens_out": int(tokens_out),
        "usd": usd,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--attacks", type=int, default=4)
    ap.add_argument("--horizon", type=int, default=20)
    ap.add_argument("--memory-items", type=int, default=40)
    ap.add_argument("--cluster-size", type=int, default=4)
    ap.add_argument("--loo-off", action="store_true")
    ap.add_argument("--loo-max-cluster", type=int, default=16)
    ap.add_argument("--tok-in", type=int, default=500)
    ap.add_argument("--tok-out", type=int, default=120)
    ap.add_argument("--price", nargs=2, type=float, default=[0.15, 0.60],
                    metavar=("IN", "OUT"), help="USD per Mtok")
    ap.add_argument("--cache-hit-rate", type=float, default=0.45)
    a = ap.parse_args()

    r = estimate(seeds=a.seeds, attacks=a.attacks, horizon=a.horizon,
                 memory_items=a.memory_items, cluster_size=a.cluster_size,
                 loo_enabled=not a.loo_off, loo_max_cluster=a.loo_max_cluster,
                 tok_in=a.tok_in, tok_out=a.tok_out,
                 price_in=a.price[0], price_out=a.price[1],
                 cache_hit_rate=a.cache_hit_rate)

    print("=" * 66)
    print("Model-call budget for the Section 6.1 protocol")
    print("=" * 66)
    print(f"clusters per compaction round      {r['clusters_per_round']:>10,}")
    print(f"summarise calls per trajectory     {r['summarise_per_traj']:>10,}")
    print(f"leave-one-out calls per trajectory {r['loo_per_traj']:>10,}"
          + ("   <-- dominates" if r['loo_per_traj'] > r['summarise_per_traj']
             else ""))
    print(f"total per trajectory               {r['per_traj']:>10,}")
    print()
    print(f"attack-arm trajectories            {r['attack_trajs']:>10,}"
          "   (seeds x attacks)")
    print(f"benign-arm trajectories            {r['benign_trajs']:>10,}"
          "   (utility, no attack present)")
    print()
    print(f"gross calls                        {r['gross_calls']:>10,}")
    print(f"after cache                        {r['net_calls']:>10,}")
    print(f"tokens                             {r['tokens_in']:>10,} in / "
          f"{r['tokens_out']:,} out")
    print(f"cost at ${a.price[0]}/${a.price[1]} per Mtok      "
          f"{'$' + format(r['usd'], '.2f'):>10}")
    print()
    print("THREE MULTIPLIERS THAT COST NOTHING, so do not budget for them:")
    print("  strict vs permissive   -- a lookup in Table 2 after the run")
    print("  defended vs undefended -- replays the same trajectory, all cache")
    print("  the four horizons      -- snapshots of one K=20 run, not four")
    print()
    if not a.loo_off:
        r2 = estimate(seeds=a.seeds, attacks=a.attacks, horizon=a.horizon,
                      memory_items=a.memory_items,
                      cluster_size=a.cluster_size, loo_enabled=False,
                      loo_max_cluster=a.loo_max_cluster, tok_in=a.tok_in,
                      tok_out=a.tok_out, price_in=a.price[0],
                      price_out=a.price[1], cache_hit_rate=a.cache_hit_rate)
        print(f"With leave-one-out disabled: {r2['net_calls']:,} calls, "
              f"${r2['usd']:.2f}")
        print("  ^ but that raises the attributed cluster size a, and by")
        print("    Proposition 2 a larger a needs a higher declassification")
        print("    rate to stay under the gate. Cheaper to run, harder to")
        print("    pass. Report both if you take this route.")


if __name__ == "__main__":
    main()
