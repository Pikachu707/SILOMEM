#!/usr/bin/env python3
"""Put a real interval on the judged figures by hand-labelling a sample.

    python analysis/calibrate_judge.py --sample 60          # emit a sheet
    python analysis/calibrate_judge.py --score labels.csv   # score it

Two of this paper's headline numbers rest on a model judge whose only evidence
is a control rate of 87 to 88 percent. A control rate is not a calibration: it
says the judge recognises contribution on items whose content is demonstrably
present, which is the easy direction. It says nothing about how often the
judge says YES when the answer is no, and that is the direction that inflates
a laundering rate.

WHAT THIS PRODUCES. A sheet of (summary, note) pairs drawn from the runs that
feed Tables 3 and 8, in randomised order, with the judge's verdict WITHHELD so
the labeller is not anchored. The labeller marks YES or NO. Scoring the
returned sheet gives the judge's confusion matrix against human labels, and
from it a Wilson interval on every figure the judge decided.

WHY THE VERDICT IS WITHHELD, and why the order is randomised: a labeller shown
the model's answer agrees with it, and a labeller working through one
condition at a time learns the condition. Both produce a calibration that
flatters the judge, which is the opposite of what this is for.

HOW MANY. At n=60 a judge agreeing on 90 percent of the sample has a Wilson
interval of roughly 80 to 95 percent, which is enough to distinguish "the
judge is usable" from "the judge is not" and not enough to place a figure to
the point. n=200 narrows that to about 86 to 94. We report which n was used
and do not round the interval away.
"""
from __future__ import annotations

import argparse
import csv
import glob
import json
import math
import os
import random
import sys


def wilson(k, n, z=1.96):
    """Wilson score interval; the normal approximation is wrong at these n."""
    if n == 0:
        return (0.0, 1.0)
    p = k / n
    d = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / d
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, centre - half), min(1.0, centre + half))


def collect(paths):
    """Pull every (summary, note, verdict) the judge decided, from whatever
    result files are present."""
    out = []
    for path in paths:
        try:
            d = json.load(open(path))
        except Exception:
            continue
        for row in d.get("rows", []):
            if not isinstance(row, dict):
                continue
            for o in row.get("observations", []):
                if "summary" in o and "payload" in o and "reached" in o:
                    out.append({"source": os.path.basename(path),
                                "condition": row.get("phrasing", ""),
                                "summary": o["summary"],
                                "note": o["payload"],
                                "judge": "YES" if o["reached"] else "NO"})
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--sample", type=int, default=0,
                    help="emit a labelling sheet of this many pairs")
    ap.add_argument("--score", default=None,
                    help="score a returned sheet")
    ap.add_argument("--out", default="judge_sheet.csv")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    if a.score:
        rows = list(csv.DictReader(open(a.score)))
        done = [r for r in rows if r.get("human", "").strip().upper()
                in ("YES", "NO")]
        if len(done) < len(rows):
            print(f"{len(rows)-len(done)} of {len(rows)} rows unlabelled; "
                  "scoring the rest")
        if not done:
            raise SystemExit("nothing labelled")

        tp = sum(1 for r in done if r["judge"] == "YES"
                 and r["human"].upper() == "YES")
        fp = sum(1 for r in done if r["judge"] == "YES"
                 and r["human"].upper() == "NO")
        fn = sum(1 for r in done if r["judge"] == "NO"
                 and r["human"].upper() == "YES")
        tn = sum(1 for r in done if r["judge"] == "NO"
                 and r["human"].upper() == "NO")
        n = len(done)
        agree = tp + tn

        print(f"n = {n} hand-labelled pairs\n")
        print(f"{'':>12}{'human YES':>11}{'human NO':>10}")
        print(f"{'judge YES':>12}{tp:>11}{fp:>10}")
        print(f"{'judge NO':>12}{fn:>11}{tn:>10}")
        lo, hi = wilson(agree, n)
        print(f"\nagreement {100*agree/n:.0f}% "
              f"(Wilson 95%: {100*lo:.0f} to {100*hi:.0f})")

        if tp + fp:
            plo, phi = wilson(tp, tp + fp)
            print(f"precision on YES {100*tp/(tp+fp):.0f}% "
                  f"({100*plo:.0f} to {100*phi:.0f})")
            print()
            print("PRECISION ON YES IS THE ONE THAT MATTERS for a laundering")
            print("rate: the judge deciding `reached' wrongly in the YES")
            print("direction inflates it. A reported figure of x% should be")
            print(f"read as at most x% x {phi:.2f} and at least x% x {plo:.2f}.")
        if fp > tp * 0.3:
            print()
            print("THE JUDGE OVER-SAYS YES on this sample. Every figure it")
            print("decided is an upper bound, and the paper must say so")
            print("rather than reporting the point estimate.")
        return

    paths = sorted(glob.glob(os.path.join(a.results, "*.json")))
    pool = collect(paths)
    if not pool:
        raise SystemExit(f"no judged observations under {a.results}/. "
                         "Run the experiments first.")
    n = a.sample or 60
    rng = random.Random(a.seed)
    sample = rng.sample(pool, min(n, len(pool)))
    rng.shuffle(sample)

    with open(a.out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["id", "summary", "note", "human", "judge_withheld"])
        for i, r in enumerate(sample):
            # the verdict is carried but not shown next to the question
            w.writerow([i, r["summary"], r["note"], "", r["judge"]])

    print(f"{len(sample)} pairs from {len(pool)} judged observations "
          f"-> {a.out}\n")
    print("For each row, read the note and the summary and answer: does the")
    print("summary reflect what the note says? Put YES or NO in the `human'")
    print("column. The judge's own verdict is in the last column; DO NOT")
    print("read it while labelling, or the calibration measures agreement")
    print("with yourself.")
    print()
    print(f"Then: python {sys.argv[0]} --score {a.out}")


if __name__ == "__main__":
    main()
