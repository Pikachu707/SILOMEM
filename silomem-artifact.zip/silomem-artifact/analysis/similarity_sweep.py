#!/usr/bin/env python3
"""Is the result a property of attribution, or of our similarity metric?

    python analysis/similarity_sweep.py results/q1_*.json

The distance in the main experiment is 1 minus Jaccard overlap of tokens,
which is the crudest metric available and the one a reviewer will challenge
first. If a sentence encoder separates contributors from non-contributors
cleanly, then there is a safe operating point after all and the paper's claim
collapses to "we picked a bad metric".

This recomputes every distance from the stored summaries under several
metrics and reruns the operating-point analysis for each. No model calls: the
summaries are already recorded, so adding a metric costs nothing.

Metrics, in increasing order of what they can see:
  jaccard   token set overlap, the original
  cosine    TF-IDF cosine, still lexical but weights rare tokens
  charngram character trigram overlap, robust to inflection and word order
  ratio     difflib sequence ratio, sensitive to order and to length
  embed     sentence-transformer cosine, if the package is installed

If every metric leaves the sound and useful regions disjoint, the result is
about attribution. If one metric closes the gap, the paper should say so and
recommend that metric instead of arguing the mechanism is unusable.
"""
from __future__ import annotations

import argparse
import difflib
import glob
import json
import math
import re
import sys
from collections import Counter


def toks(s):
    return re.findall(r"\w+", s.lower())


def jaccard(a, b):
    ta, tb = set(toks(a)), set(toks(b))
    if not ta and not tb:
        return 1.0
    return len(ta & tb) / len(ta | tb)


def cosine_tfidf(a, b, idf):
    ca, cb = Counter(toks(a)), Counter(toks(b))
    keys = set(ca) | set(cb)
    va = {k: ca.get(k, 0) * idf.get(k, 1.0) for k in keys}
    vb = {k: cb.get(k, 0) * idf.get(k, 1.0) for k in keys}
    num = sum(va[k] * vb[k] for k in keys)
    na = math.sqrt(sum(v * v for v in va.values()))
    nb = math.sqrt(sum(v * v for v in vb.values()))
    return num / (na * nb) if na and nb else 1.0


def charngram(a, b, n=3):
    ga = {a[i:i+n] for i in range(max(len(a) - n + 1, 0))}
    gb = {b[i:i+n] for i in range(max(len(b) - n + 1, 0))}
    if not ga and not gb:
        return 1.0
    return len(ga & gb) / len(ga | gb)


def ratio(a, b):
    return difflib.SequenceMatcher(None, a, b).ratio()


def build_embed(texts):
    """Sentence-transformer cosine, if available. Returns None otherwise so
    the sweep still runs; a missing encoder should not silently become a
    zero similarity, which would look like a dramatic result."""
    try:
        from sentence_transformers import SentenceTransformer
        import numpy as np
    except ImportError:
        return None
    m = SentenceTransformer("all-MiniLM-L6-v2")
    uniq = sorted(set(texts))
    vecs = m.encode(uniq, normalize_embeddings=True, batch_size=128,
                    show_progress_bar=False)
    idx = {t: i for i, t in enumerate(uniq)}

    def f(a, b):
        return float(vecs[idx[a]] @ vecs[idx[b]])
    return f


def auc(pos, neg):
    if not pos or not neg:
        return None
    p = len(pos) * len(neg)
    w = (sum(1 for a in pos for b in neg if a > b)
         + 0.5 * sum(1 for a in pos for b in neg if a == b))
    return w / p


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("paths", nargs="+")
    ap.add_argument("--fn-max", type=float, default=1.0,
                    help="max acceptable false-negative rate, percent")
    ap.add_argument("--fp-max", type=float, default=25.0,
                    help="max useful false-positive rate, percent")
    a = ap.parse_args()

    files = [f for p in a.paths for f in glob.glob(p)]
    if not files:
        raise SystemExit("no files matched")

    for path in sorted(files):
        d = json.load(open(path))
        model = d["config"]["model"].split("/")[-1]
        items = []
        for o in d["observations"]:
            for it in o["items"]:
                if "alt" not in it:
                    break
                items.append((o["summary"], it))
        if not items:
            print(f"{model}: no stored summaries; rerun observe_q1.py with "
                  "the current version")
            continue

        corpus = [s for s, _ in items] + [it["alt"] for _, it in items]
        df = Counter()
        for t in set(corpus):
            for w in set(toks(t)):
                df[w] += 1
        n_doc = len(set(corpus))
        idf = {w: math.log(n_doc / (1 + c)) + 1.0 for w, c in df.items()}
        embed = build_embed(corpus)

        metrics = {
            "jaccard": jaccard,
            "cosine": lambda x, y: cosine_tfidf(x, y, idf),
            "charngram": charngram,
            "ratio": ratio,
        }
        if embed:
            metrics["embed"] = embed

        print("=" * 74)
        print(f"{model}   {len(items)} item observations")
        print("=" * 74)
        print(f"{'metric':>10}{'AUC':>8}{'sound tau':>12}{'attributed':>12}"
              f"{'FP there':>10}   safe+useful?")
        print("-" * 68)

        for name, fn in metrics.items():
            ds = [(1.0 - fn(s, it["alt"]), it["in_summary"]) for s, it in items]
            pos = [x for x, y in ds if y]
            neg = [x for x, y in ds if not y]
            A = auc(pos, neg)
            best = None
            for tau in [i / 100 for i in range(1, 100)]:
                fnr = 100 * sum(1 for x in pos if x <= tau) / len(pos)
                fpr = 100 * sum(1 for x in neg if x > tau) / len(neg)
                if fnr <= a.fn_max:
                    att = 100 * sum(1 for x, _ in ds if x > tau) / len(ds)
                    best = (tau, att, fpr)
            usable = best and best[2] < a.fp_max
            if best:
                print(f"{name:>10}{A:>8.3f}{best[0]:>12.2f}{best[1]:>11.0f}%"
                      f"{best[2]:>9.0f}%   {'YES' if usable else 'no'}")
            else:
                print(f"{name:>10}{A:>8.3f}{'none':>12}{'':>12}{'':>10}   no")

        if not embed:
            print("\n  embed not evaluated: sentence-transformers is not "
                  "installed.\n  pip install sentence-transformers to include "
                  "it. Its absence is\n  the one gap a reviewer will point at.")

    print()
    print("The 'sound tau' column is the loosest threshold whose false-negative")
    print(f"rate stays at or below {a.fn_max}%, since a false negative drops a")
    print("real contributor from the meet and breaks the guarantee. If every")
    print("metric attributes most items there, the estimator is doing the work")
    print("of whole-cluster propagation at several times the cost.")


if __name__ == "__main__":
    main()
