#!/usr/bin/env python3
"""What a deployment actually cares about: does the action get refused?

    python analysis/endtoend.py

Every rate in this paper is per item or per round. A deployment does not
choose between rules on a per-item miss rate; it chooses on how often a
sensitive action goes through on lineage that should have been refused, over
the horizon it runs for. This composes the measured rates into that quantity.

IT IS A MODEL, NOT A MEASUREMENT, and the difference matters. The per-round
miss rates are measured (Sections 4.2 and 6.1). The horizon, the cluster size
and how often a session proposes a sensitive action are parameters a
deployment sets, and we sweep them rather than guessing. What comes out is
"under these assumptions, this many actions in a thousand", which is a
statement about the model.

THE INDEPENDENCE ASSUMPTION, which is the load-bearing one. A rule that misses
an item on one round is more likely to miss a similar item on the next, since
the same summariser and the same metric are at work. Correlated misses make
the true figure LOWER than this model says, because the failures concentrate
on fewer trajectories. We report the independent case because it is the one we
can compute, and it is the pessimistic direction for every rule equally, so
the comparison between rules survives even where the absolute numbers do not.

WHOLE-CLUSTER AND SILOMEM ARE ZERO HERE BY CONSTRUCTION, not by luck: neither
estimates, so neither can exclude a true contributor, so no laundered lineage
reaches an action. That is what the theorem says. Listing them makes the point
that the estimators' figures are not small numbers to be traded off against
convenience -- they are the only non-zero column.
"""
from __future__ import annotations

import argparse


def leak_probability(miss_per_item, k, rounds):
    """Probability that at least one untrusted ancestor is dropped from the
    meet somewhere along a compaction chain of `rounds` rounds, each merging
    `k` items, under independence."""
    per_round = 1.0 - (1.0 - miss_per_item) ** k
    return 1.0 - (1.0 - per_round) ** rounds


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--k", type=int, default=6,
                    help="items per compaction call")
    ap.add_argument("--horizons", default="5,10,20,50")
    ap.add_argument("--actions", type=float, default=0.10,
                    help="fraction of sessions proposing a sensitive action")
    a = ap.parse_args()
    horizons = [int(x) for x in a.horizons.split(",")]

    # measured per-item miss rates, with their source
    rules = [
        ("whole-cluster", 0.0,    "no estimate; Thm 1"),
        ("SiloMem",       0.0,    "no estimate; Thm 1"),
        ("ablation",      0.010,  "Tab. 2, soundest threshold"),
        ("content rule",  0.020,  "Sec. 6.1, judged"),
        ("content rule",  0.026,  "Sec. 6.1, upper end"),
    ]

    print(f"k = {a.k} items per call, "
          f"{100*a.actions:.0f}% of sessions propose a sensitive action\n")
    print(f"{'rule':>14}{'per item':>10}", end="")
    for h in horizons:
        print(f"{('r=' + str(h)):>9}", end="")
    print("   source")
    print("-" * (24 + 9 * len(horizons) + 30))

    for name, m, src in rules:
        print(f"{name:>14}{100*m:>9.1f}%", end="")
        for h in horizons:
            leak = leak_probability(m, a.k, h)
            print(f"{100*leak*a.actions:>8.1f}%", end="")
        print(f"   {src}")

    print()
    print("Columns are the fraction of trajectories in which a sensitive")
    print("action is taken on lineage that should have been refused.")
    print()
    worst = leak_probability(0.026, a.k, max(horizons)) * a.actions
    best = leak_probability(0.010, a.k, max(horizons)) * a.actions
    print(f"At r = {max(horizons)} the estimators leak on "
          f"{100*best:.0f}% to {100*worst:.0f}% of trajectories.")
    print("The two rules that do not estimate leak on none, and that is a")
    print("consequence of Theorem 1 rather than a measurement.")
    print()
    print("ASSUMPTIONS, all of which move the numbers:")
    print("  independence across rounds -- correlated misses would lower")
    print("    every non-zero figure, equally, so the ordering survives")
    print(f"  k = {a.k}; a smaller read set lowers the per-round rate")
    print(f"  {100*a.actions:.0f}% action frequency scales every column linearly")
    print("  the per-item rates are single runs on a synthetic workload")


if __name__ == "__main__":
    main()
