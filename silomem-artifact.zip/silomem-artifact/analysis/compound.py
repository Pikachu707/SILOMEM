#!/usr/bin/env python3
"""Per-cluster and multi-round risk, from the per-item rates already measured.

    python analysis/compound.py results/

Reviewer objection 3.4: a per-item miss rate is the wrong unit. The guarantee
breaks when a cluster loses any contributor, and a long-horizon store compacts
repeatedly, so the quantities that matter are

  p_cluster  the probability a given cluster loses at least one contributor
  p_horizon  the probability a payload's lineage is severed at some round

We report both from the per-item rates, and we are explicit that this is a
derivation under an independence assumption, not a measurement. Items in a
cluster are not independent: they share a summary, and whichever pressure
caused one to be dropped acts on the others. Independence therefore gives an
UPPER bound on p_cluster if misses are positively correlated within a cluster,
which is the direction we expect, and the true figure could be lower. It is
still the right order-of-magnitude check, because a 2% per-item rate does not
stay a 2% risk once a cluster holds six items and the store compacts twenty
times.

What would replace this with a measurement: instrument the harness to record,
per cluster, whether any contributor was excluded, and run a multi-round
trajectory rather than single compactions. We did not.
"""
from __future__ import annotations

import argparse


def p_cluster(p_item: float, k: int) -> float:
    """At least one of k items missed, under independence."""
    return 1.0 - (1.0 - p_item) ** k


def p_horizon(p_c: float, rounds: int) -> float:
    """At least one round loses the lineage, under independence across
    rounds. A severed lineage does not heal, so this compounds."""
    return 1.0 - (1.0 - p_c) ** rounds


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--rates", default="0.008,0.020,0.026",
                    help="per-item miss rates to tabulate")
    ap.add_argument("--cluster-sizes", default="4,6,10")
    ap.add_argument("--rounds", default="1,5,10,20")
    a = ap.parse_args()

    rates = [float(x) for x in a.rates.split(",")]
    ks = [int(x) for x in a.cluster_sizes.split(",")]
    rs = [int(x) for x in a.rounds.split(",")]

    print("=" * 70)
    print("Per-cluster risk: probability a cluster loses a contributor")
    print("=" * 70)
    print(f"{'per-item':>10}" + "".join(f"{'k=' + str(k):>10}" for k in ks))
    print("-" * (10 + 10 * len(ks)))
    for p in rates:
        print(f"{p:>10.3f}" + "".join(f"{p_cluster(p, k):>10.3f}" for k in ks))

    print()
    print("=" * 70)
    print("Compounded over compaction rounds, at k = 6")
    print("=" * 70)
    print(f"{'per-item':>10}" + "".join(f"{str(r) + ' rd':>10}" for r in rs))
    print("-" * (10 + 10 * len(rs)))
    for p in rates:
        pc = p_cluster(p, 6)
        print(f"{p:>10.3f}" + "".join(f"{p_horizon(pc, r):>10.3f}"
                                     for r in rs))

    print()
    print("Read the bottom-right cell before quoting the per-item rate. A")
    print("2.0% per-item miss is a 11% chance of losing a contributor from a")
    print("six-item cluster, and near-certainty that some cluster in a")
    print("twenty-round trajectory loses one.")
    print()
    print("CAVEAT, and it is not small: this assumes independence both within")
    print("a cluster and across rounds. Items in a cluster share a summary, so")
    print("misses are plausibly correlated, and correlated misses make the")
    print("true per-cluster figure LOWER than shown. The direction of the")
    print("compounding is nonetheless the point: a per-item rate is not the")
    print("unit in which this risk should be reported.")


if __name__ == "__main__":
    main()
