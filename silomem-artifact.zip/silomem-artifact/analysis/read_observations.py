#!/usr/bin/env python3
"""Answer the six open questions from harness/observe.py's output.

    python analysis/read_observations.py results/observations.json

Each question gets its own section, and each section states what result would
count against the hypothesis as well as for it. That is the point: the last
three hypotheses in this project were each consistent with an aggregate and
refuted by the underlying observations, so the analysis has to be written so
that a refutation is visible rather than absorbed.
"""
from __future__ import annotations

import argparse
import json
import statistics as st
import sys
from collections import defaultdict


def pct(x):
    return f"{100*x:5.1f}%"


def q1_estimator_accuracy(obs, taus):
    print("=" * 72)
    print("Q1  Is the estimator right on benign clusters?")
    print("=" * 72)
    print("An item whose distinctive content appears in the summary genuinely")
    print("contributed to it. Excluding such an item is a false negative, and")
    print("a false negative is what breaks the guarantee.\n")
    print(f"{'tau':>6}{'items':>8}{'contributed':>13}{'excluded':>11}"
          f"{'FN rate':>10}{'FP rate':>10}")
    print("-" * 60)
    for tau in taus:
        n = fn = fp = contrib = 0
        for o in obs:
            if o["n_dup"]:      # benign clusters only
                continue
            for it in o["items"]:
                n += 1
                attributed = it["distance"] > tau
                real = it["content_in_summary"]
                contrib += real
                fn += real and not attributed
                fp += attributed and not real
        if not n:
            continue
        print(f"{tau:>6.2f}{n:>8}{contrib:>13}{n-contrib:>11}"
              f"{pct(fn/max(contrib,1)):>10}{pct(fp/max(n-contrib,1)):>10}")
    print("\n  A high false-negative rate means the estimator drops real")
    print("  contributors, so labels are meets over incomplete sets even with")
    print("  no adversary. A low rate means the estimator is fine and the")
    print("  earlier k=1 observation was an artifact of six trials.")


def q2_equivalence(obs):
    print("\n" + "=" * 72)
    print("Q2  Is the equivalence hypothesis stable across clusters?")
    print("=" * 72)
    print("Theorem 1 needs distance = 0 for a duplicated payload item.")
    print("One hand-built cluster gave exactly 0. Here is the distribution.\n")
    print(f"{'copies':>7}{'n':>6}{'mean d':>9}{'median':>9}{'p90':>8}"
          f"{'d=0':>8}{'d<0.05':>9}")
    print("-" * 56)
    for nd in sorted({o["n_dup"] for o in obs}):
        if nd < 1:
            continue
        ds = [it["distance"] for o in obs if o["n_dup"] == nd
              for it in o["items"] if it["role"] == "payload"]
        if not ds:
            continue
        ds.sort()
        z = sum(1 for d in ds if d == 0) / len(ds)
        lo = sum(1 for d in ds if d < 0.05) / len(ds)
        print(f"{nd:>7}{len(ds):>6}{st.fmean(ds):>9.3f}{st.median(ds):>9.3f}"
              f"{ds[int(len(ds)*0.9)-1]:>8.3f}{pct(z):>8}{pct(lo):>9}")
    print("\n  At two or more copies the hypothesis predicts d = 0. If the")
    print("  'd=0' column is near 100% the theorem applies generally; if it")
    print("  is a minority the attack is conditional and the paper must say")
    print("  which condition and how often it holds.")


def q3_drivers(obs):
    print("\n" + "=" * 72)
    print("Q3  What drives the distance for a duplicated item?")
    print("=" * 72)
    print("If it is predictable, an attacker can engineer the condition.\n")
    for field, label in (("n_trusted", "trusted items in cluster"),
                         ("topic_mix", "topics in cluster"),
                         ("length", "sentences per item")):
        by = defaultdict(list)
        for o in obs:
            if o["n_dup"] < 2:
                continue
            for it in o["items"]:
                if it["role"] == "payload":
                    by[o[field]].append(it["distance"])
        if not by:
            continue
        print(f"  by {label}:")
        for v in sorted(by):
            ds = by[v]
            z = sum(1 for d in ds if d == 0) / len(ds)
            print(f"    {v:>3}: mean d {st.fmean(ds):.3f}   d=0 {pct(z)}"
                  f"   (n={len(ds)})")
        print()


def q4_threshold(obs, taus):
    print("=" * 72)
    print("Q4  Which thresholds separate anything?")
    print("=" * 72)
    ds = sorted(it["distance"] for o in obs for it in o["items"])
    if not ds:
        return
    qs = [ds[int(len(ds)*p)-1] for p in (0.1, 0.25, 0.5, 0.75, 0.9)]
    print(f"  all distances: p10 {qs[0]:.3f}  p25 {qs[1]:.3f}  "
          f"median {qs[2]:.3f}  p75 {qs[3]:.3f}  p90 {qs[4]:.3f}")
    print()
    print(f"{'tau':>6}{'attributed':>12}")
    print("-" * 20)
    for tau in taus:
        print(f"{tau:>6.2f}{pct(sum(1 for d in ds if d > tau)/len(ds)):>12}")
    print("\n  A tau above p90 attributes almost nothing and a tau below p10")
    print("  attributes almost everything; neither is a working setting. If")
    print("  our grid sits outside the informative range, results at those")
    print("  values describe the grid rather than the estimator.")


def q5_fallback(obs, taus):
    print("\n" + "=" * 72)
    print("Q5  How often would the fail-closed fallback fire?")
    print("=" * 72)
    print(f"{'tau':>6}{'clusters with empty A':>24}")
    print("-" * 30)
    for tau in taus:
        e = sum(1 for o in obs
                if all(it["distance"] <= tau for it in o["items"]))
        print(f"{tau:>6.2f}{pct(e/len(obs)):>24}")
    print("\n  Where this is high the estimator is not running: the defense")
    print("  reverts to whole-cluster propagation, which is sound but is not")
    print("  what the design claims to be doing.")


def q6_determinism(obs):
    reps = {o["repeat"] for o in obs}
    if len(reps) < 2:
        return
    print("\n" + "=" * 72)
    print("Q6  Is the estimator deterministic on a fixed cluster?")
    print("=" * 72)
    by = defaultdict(list)
    for o in obs:
        k = (o["n_trusted"], o["n_dup"], o["topic_mix"], o["length"],
             o["cluster"])
        by[k].append([it["distance"] for it in o["items"]])
    diff = sum(1 for v in by.values() if len(v) > 1 and any(x != v[0] for x in v))
    print(f"  {diff}/{len(by)} clusters gave different distances across repeats")
    print("  Any non-zero count means the attributed set is a sample rather")
    print("  than a function of the cluster.")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("path", nargs="?", default="results/observations.json")
    ap.add_argument("--taus", default="0.05,0.10,0.15,0.20,0.30")
    a = ap.parse_args()
    taus = [float(x) for x in a.taus.split(",")]
    obs = json.load(open(a.path))["observations"]
    print(f"{len(obs)} clusters, "
          f"{sum(len(o['items']) for o in obs)} item observations\n")
    q1_estimator_accuracy(obs, taus)
    q2_equivalence(obs)
    q3_drivers(obs)
    q4_threshold(obs, taus)
    q5_fallback(obs, taus)
    q6_determinism(obs)
    print("\nPick the paper's claim after reading this, not before.")


if __name__ == "__main__":
    main()
