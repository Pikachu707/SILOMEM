# RUNBOOK — what to run, and what each run fills in

Every `\TODO` in `main.tex` is listed here with the artifact entry point that
produces it. Grep the paper for `\TODO` to get the same list in source order.

**Nothing in this artifact invents a number.** The only values it produces
without an experiment are the Proposition 2 curves and thresholds, which are
analytic. Everything else is a harness waiting for a backend.

---

## 0. Before anything: the kill criterion

RQ2 is a gate, not a result. Run it first. If `ΔBTSR > 5%` or `TER > 20%`,
the design changes before any attack coverage is measured — that is what
makes it an *a priori* gate, and reporting it only when it passes would
retroactively make it not one.

```
python -m harness.run_rq2 --env agent-driver --config strict   --seeds 5
python -m harness.run_rq2 --env agent-driver --config permissive --seeds 5
```

Fills: **Table 4**, **Figure 7 markers**, and the `a` / `d` you need for
everything downstream.

---

## 1. What runs with no backend at all

```
python -m pytest tests/ -q          # 13 tests: the guarantees
python analysis/prop2.py            # threshold table, real numbers
python analysis/prop2.py --emit data/   # rewrites ter_model_*.csv for Fig. 7
```

`prop2.py` output is publishable as-is. Current values at the paper's
TER ≤ 0.20 gate:

| a | TER at d=0 | d needed for gate | d that collapses TER |
|---|---|---|---|
| 1.25 | 1.000 | 0.178 | 0.200 |
| 1.50 | 1.000 | 0.297 | 0.333 |
| 2.00 | 1.000 | 0.444 | 0.500 |
| 3.00 | 1.000 | 0.590 | 0.667 |
| 5.00 | 1.000 | 0.703 | 0.800 |

The first column is Proposition 2(ii) with `d = 0`: **the store saturates for
every `a > 1`**. That is the sharpest prediction in the paper and the cheapest
to falsify — one ablation run with declassification disabled.

Sample sizes, from `harness.stats.trials_per_cell`:

| pilot ASR | MDE | n per arm |
|---|---|---|
| 0.10 | 0.10 | 199 |
| 0.30 | 0.10 | 356 |
| 0.50 | 0.15 | 170 |

Report the pilot rate and the MDE alongside `n`, or the number looks arbitrary.

---

## 2. What needs a backend

Implement two protocols and the rest of the harness runs:

- `provenire.compaction.Compactor` — `cluster()` and `summarise()` from the
  framework you wrap.
- `provenire.influence.Regenerator` — `regenerate(context, withheld)`, one
  model call, used only by leave-one-out probing.

Then, by paper section:

| Paper | Command | Fills |
|---|---|---|
| §3.2 corpus | `run_corpus --attacks memorygraft,minja` | counts, pairing procedure |
| §3.2 δ̂ | `run_delta --on artifacts` | δ̂ and its discriminator |
| §3.3 detectors | `run_detectors --all` | layer, probe family, judge prompt, k, thresholds |
| §3.3 scale trend | `run_detectors --probe-sizes 0.1B,0.5B,1B` | AUC vs log-params |
| §3.4 result | `run_detectors --report` | **Figure 2**, AUCs with CIs |
| §4.5 fallback | any run; read `EstimatorStats.fallback_rate` | how often fail-closed fires |
| §4.7 clustering | `run_rq6 --ablate label-aware-clustering` | the cheap ablation with a large effect |
| §4.9 budget | `run_pilot --measure-declass-demand` | b, and the induced d |
| §4.10 probes | `run_canary --clean-run 200` | benign false-positive rate |
| §5 impl | `cloc provenire harness` + `run_overhead` | LoC, where overhead sits |
| §6.1 setup | — | environment versions, backends, which is the spot-check |
| §6.2 | `run_rq1 --attacks all --horizons 0,1,5,20` | **Table 3**, **Figure 6** |
| §6.4 | `run_rq3 --baselines struq,secalign,melon,sandbox,judge --compose` | **Table 5** |
| §6.5 | `run_rq4 --strategies A1,A2,A3,A4` | **Table 6**, App. C |
| §6.6 | `run_overhead --breakdown` | latency p50/p95, storage, per component |
| §6.7 | `run_rq6 --ablate all` | **Table 7** |

---

## 3. The one experiment worth designing carefully

**A3, attribution evasion.** It attacks `Ihat` rather than the policy: content
crafted so that withholding it changes the summary by less than τ. It is the
only one of the four that would generalise to any attribution-based defense,
and it is the one to disclose if it works.

Prediction, recorded before running: A2 and A3 partially succeed, A1 and A4
do not. Write the prediction down, then report the outcome either way. If all
four fail cleanly, the attacks are too weak — strengthen them rather than
reporting a sweep.

---

## 4. Landing results in the paper

```
python analysis/fill_tables.py --results results.json --tex main.tex
```

Then, and only then:

1. Replace every placeholder CSV in `main.tex`'s `filecontents` blocks with
   measured data. The `ter_model_*` blocks are analytic — leave them.
2. Set `\syntheticdatafalse`. The SYNTHETIC watermarks on Figures 2, 6 and 7
   disappear. **Do not set this while any CSV is still synthetic**; the
   watermark is the last line of defence against shipping a placeholder.
3. Confirm every `refs.bib` entry flagged `PLACEHOLDER`.

---

## Appendix: what run_rq2 does and does not establish

`harness/run_rq2.py` runs today, on a synthetic benign workload, with no
published attack and no agent framework. It measures **properties of the
labelling system**: TER, LLR, the attributed cluster size `a`, the
declassification rate `d`, and a Delta-BTSR proxy. Those are workload-
dependent but attack-independent, which is exactly why the gate can be
decided before any attack is reproduced.

It does **not** produce RQ1, RQ3 or RQ4. Those need Agent-Driver,
WebShop/MIMIC-III or MPBench, and the published attacks. Do not report a
number from this script as if it were one of those.

Two things in the script were bugs found by running it, and both would have
been easy to ship:

- **Compaction ran every round unconditionally**, which shrinks memory
  geometrically (40 → 10 → 3 → 1). With three items left, TER is computed
  over three items and the confidence interval is [0, 1]. Real stores compact
  the oldest portion when they exceed a budget; `--budget-items` now controls
  that.
- **The Delta-BTSR proxy counted CONFIRM as a lost task.** A confirmation the
  principal approves is a prompt, not a failure. Deny and confirm are now
  separate columns, because otherwise the 5% gate means different things in
  the strict and permissive configurations.

### Three more bugs the first live run found

The first `--backend ollama` run reported plausible-looking numbers and was
entirely meaningless. The tell was one line at the bottom:

    0 live calls, 0 cache hits (0% hit rate)

The backend was never called, because compaction never fired, because the
default budget was 40 and a 20-session run producing 2 notes per session
lands at exactly 40. `len(memory) > 40` was never true. Every figure in that
table came from a system in which the mechanism under test did not execute.
There is now a loud check that refuses to let that pass silently.

Two more, both of which made the numbers look better than they were:

- **LLR counted declassification as label loss.** Corollary 1 says untrusted
  lineage is lost either by an auditable declassification event or by an
  estimator omission; LLR is meant to measure the second. Counting the first
  made LLR a monotone function of `d` and therefore useless. Declassified
  items are now excluded from the denominator.
- **Declassification was applied per session rather than per compaction
  round.** `d` in Proposition 2 is a per-round, per-item probability. Applying
  it once per session inflates the effective rate to `1-(1-d)^horizon`, which
  is ~1 for `d=0.5` over 20 sessions -- which is why TER looked like 0.04
  when it should have been around 0.4.

Set `--budget-items` well below `2 x horizon`. The default is now 16.
