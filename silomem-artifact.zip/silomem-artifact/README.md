# Artifact: SiloMem

Measurement harness, reference implementation, and every sweep behind
*Don't Infer Influence, Record Exposure: Provenance-Safe Memory Compaction
for LLM Agents*.

Every table in the paper regenerates from cached model outputs without a GPU.

## What this artifact is for

The paper has two halves and the artifact serves both.

The first half measures the attribution step that published provenance
defenses add, and finds no setting of it a deployment could rely on. Those
results are falsifiable from the cached observations: the stored summaries,
the per-item verdicts and the sweeps are all here, so a reader can recompute
any number without running a model and without trusting our harness.

The second half builds SiloMem, which propagates over the read set the
orchestrator records rather than over an inferred influence set. Its security
property is a theorem, so what the artifact contributes there is the
containment experiment (`run_injection.py`) and the cost and selectivity
measurements, including the ones that go against the design.

## Quick start, no GPU

    bash setup.sh                  # deps only; no model download
    python -m pytest tests/ -q     # 21 tests, about a second
    python analysis/read_observations.py results/

## Running the experiments

Every experiment needs a served model. Start one first; the scripts check for
it and refuse to run, rather than failing on call 1 of 180.

    nohup python -m vllm.entrypoints.openai.api_server \
      --model Qwen/Qwen2.5-7B-Instruct --port 8000 --max-num-seqs 64 &
    export VLLM_KEY=local

| script | paper | what it measures |
|---|---|---|
| `harness/observe_q1.py` | Tab. 1, 2 | threshold sweep, four backends x five metrics |
| `harness/run_adversarial.py` | Tab. 3 | rephrasing attack on the identifier locator |
| `harness/run_adv_embed.py` | Tab. 5 | the same attack against an embedding locator |
| `harness/run_injection.py` | Tab. 6 | prompt injection contained by isolated atomisation |
| `harness/run_selectivity.py` | Tab. 7 | tainted fraction against the coarse baseline |
| `harness/run_cost.py` | Tab. 8, 9 | calls, tokens, wall clock, atomisation ratio |
| `analysis/compound.py` | Eq. 5 | saturation under a per-item miss rate |

## The guards, and why they are the interesting part

Each refuses to report a number rather than reporting a wrong one, and each
exists because it caught an error that had already produced a plausible table.

**The design check** refuses to report an AUC when the surviving and dropped
item pools differ in mean length beyond a tolerance. A first version of the
sweep varied influence by item length; withholding a long item removes more
text, so distance tracked length rather than influence and the run reported an
AUC of 0.16, which reads as an estimator running backwards. Nothing else in
the run signalled it.

**The template check** refuses to run when a note carries no extractable
identifier, since an unmeasurable item would otherwise default to "dropped".

**The judge control** voids a measurement when the judge fails to recognise
contribution on items whose content is demonstrably present. It has voided
real runs, including one whose control sample was drawn from the rule's own
attributions and was therefore tautological.

**The obey gate** in `run_injection.py` refuses to claim containment when the
injection was not obeyed, since an injection the model ignores would be
contained by any design at all.

**The floor check** in `run_selectivity.py` refuses to compare tainted
fractions when a configuration left under 20 items, because the fraction is
then quantised more coarsely than the effect being measured.

**The ratio warning** in `run_cost.py` fires when atomisation produces about
one claim per memory, which means extraction was a no-op on that workload and
the cost figures bound SiloMem from below.

## Results that went against us

Listed here because the artifact should make them easy to check.

- SiloMem does not delay saturation. Routing changes which claims share a
  read set, not how many, so the curve is the baseline's
  (`run_selectivity.py`).
- SiloMem costs 2.0x the baseline's tokens and never recovers it
  (`run_cost.py`).
- The rephrasing attack does not defeat an embedding locator, which places
  the 58% result on surface-form attribution rather than on content-based
  attribution as a class (`run_adv_embed.py`).

## Layout

    harness/     experiment drivers, one per paper table
    analysis/    recompute tables from stored observations
    provenire/   the lattice, the propagation rules, the claim store
    tests/       21 tests, two of which pin Theorem 1's property
    results/     stored summaries and per-item verdicts

## Reproduction without a model

`analysis/read_observations.py` reads the observation files directly. They
carry each cluster's inputs, the summary the model produced and the verdict
the rule under test assigned, so a disputed number can be recomputed in a few
lines of Python that do not involve our code.
