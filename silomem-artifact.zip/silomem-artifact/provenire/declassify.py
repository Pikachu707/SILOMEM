"""Declassification, Section 4.9.

Without an upgrade path Theorem 2 is a ratchet and, by Proposition 2, the
store saturates at U. This is the release valve, and it has to be specified
tightly enough not to become the attack -- adaptive strategy A2 targets
exactly this file.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .lattice import Item, Level, Provenance


class DeclassificationRefused(Exception):
    pass


@dataclass
class Budget:
    """At most b events per session, so a laundering campaign that needs many
    hops is rate-limited rather than merely detected. Set b from the benign
    workload's observed demand (95th percentile on a pilot), not by intuition.
    """

    b: int
    used: int = 0

    def take(self) -> None:
        if self.used >= self.b:
            raise DeclassificationRefused(f"session budget b={self.b} exhausted")
        self.used += 1

    def reset(self) -> None:
        self.used = 0


@dataclass
class Ledger:
    """The audit trail Theorem 2 leans on: declassification is the only
    operation that assigns a label not obtained as a meet, so every one of
    them has to be recoverable after the fact."""

    events: list[tuple[str, Level, Level, str]] = field(default_factory=list)

    def record(self, item_id, before, after, rule):
        self.events.append((item_id, before, after, rule))


def d1_principal(item: Item, budget: Budget, ledger: Ledger) -> Item:
    """Principal confirmation at act time, shown the item and its origins.
    Lifts D -> T only. U -> T in one step is not available to anyone.
    """
    if item.level is not Level.D:
        raise DeclassificationRefused("D1 lifts D to T only")
    budget.take()
    ledger.record(item.item_id, item.level, Level.T, "D1")
    out = item.with_level(Level.T, Provenance.BY_DECLASS)
    out.declassified = True
    return out


def d2_corroborate(item: Item, corroborator: Item, agrees: bool,
                   budget: Budget, ledger: Ledger) -> Item:
    """Independent corroboration by a trusted tool. Lifts U -> D only.

    Two guards matter as much as the check itself. The corroborator must be
    trusted AT THE TIME OF USE, and it must not itself be a declassified item
    -- that forbids the chain in which an item is laundered and then used to
    launder the next, which is adaptive strategy A1.
    """
    if item.level is not Level.U:
        raise DeclassificationRefused("D2 lifts U to D only")
    if corroborator.level is not Level.T:
        raise DeclassificationRefused("corroborator must be trusted at use")
    if corroborator.declassified:
        raise DeclassificationRefused(
            "a declassified item may not serve as a corroborator")
    if not agrees:
        raise DeclassificationRefused("equivalence check failed")
    budget.take()
    ledger.record(item.item_id, item.level, Level.D, "D2")
    out = item.with_level(Level.D, Provenance.BY_DECLASS)
    out.declassified = True
    return out
