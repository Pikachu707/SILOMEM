"""Provenance lattice L = ({T, D, U}, <=) and labelled memory items.

This is Section 4.3 of the paper. The meet rule is Denning's, applied in the
integrity direction; nothing here is novel and nothing here needs a model, so
it is fully testable offline.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Iterable


class Level(IntEnum):
    """Trust levels, ordered U < D < T so that `min` is the meet."""

    U = 0  # untrusted   (bottom)
    D = 1  # derived
    T = 2  # trusted     (top)

    def __str__(self) -> str:  # pragma: no cover - display only
        return {Level.U: "U", Level.D: "D", Level.T: "T"}[self]


def meet(levels: Iterable[Level]) -> Level:
    """Greatest lower bound. Empty input is a programming error, not U.

    The fail-closed rule lives in the influence estimator, which guarantees a
    non-empty attributed set before we get here. Returning U for an empty meet
    would silently mask an estimator bug, so we refuse instead.
    """
    levels = list(levels)
    if not levels:
        raise ValueError(
            "meet over an empty set: the caller must apply the fail-closed "
            "rule before computing a label (Section 4.5)"
        )
    return Level(min(levels))


class SourceClass(IntEnum):
    """The four entry points of Section 4.6."""

    TRUSTED_TOOL = 0      # -> T
    USER_INSTRUCTION = 1  # -> T
    USER_PASTED = 2       # -> U   (a forwarded page is attacker material)
    RETRIEVED = 3         # -> U


SOURCE_LEVEL = {
    SourceClass.TRUSTED_TOOL: Level.T,
    SourceClass.USER_INSTRUCTION: Level.T,
    SourceClass.USER_PASTED: Level.U,
    SourceClass.RETRIEVED: Level.U,
}


class Provenance(IntEnum):
    """How an item's level was assigned. Recorded for the audit trail."""

    BY_RULE = 0        # source class
    BY_MEET = 1        # Equation (1) or Algorithm 1
    BY_DECLASS = 2     # D1 or D2
    FAIL_CLOSED = 3    # estimator returned nothing, or restore found no record


@dataclass
class Item:
    """A memory item. `level` and `origins` are held out of band in Store."""

    item_id: str
    text: str
    level: Level
    origins: frozenset[str] = field(default_factory=frozenset)
    how: Provenance = Provenance.BY_RULE
    declassified: bool = False  # flagged items may not act as corroborators

    def with_level(self, level: Level, how: Provenance) -> "Item":
        return Item(self.item_id, self.text, level, self.origins, how,
                    self.declassified)


def label_source(item_id: str, text: str, cls: SourceClass,
                 ingestion_event: str) -> Item:
    """Apply the source-class rule of Section 4.6."""
    lvl = SOURCE_LEVEL[cls]
    origins = frozenset() if lvl is Level.T else frozenset({ingestion_event})
    return Item(item_id, text, lvl, origins, Provenance.BY_RULE)


def label_generated(item_id: str, text: str, influences: list[Item]) -> Item:
    """Equation (1): a generated item inherits the meet over its influences.

    `influences` must be the *attributed* set, already passed through the
    fail-closed rule. See influence.estimate.
    """
    lvl = meet(i.level for i in influences)
    origins = frozenset().union(*(i.origins for i in influences)) \
        if influences else frozenset()
    return Item(item_id, text, lvl, origins, Provenance.BY_MEET)


# ---------------------------------------------------------------------
#  Pool identifiers for trust-partitioned compaction (harness/run_partition).
#  Kept here rather than in the harness so that a test can check the
#  partitioning property without importing the network client.
# ---------------------------------------------------------------------
TRUSTED_POOL = "T"
UNTRUSTED_POOL = "U"
