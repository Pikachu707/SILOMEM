"""The influence estimator of Section 4.5.

Three signals in increasing order of cost:

  (a) retrieval provenance  -- recorded exactly, always included, no model
  (b) segmented generation  -- per-field attribution, no model
  (c) leave-one-out probing -- one model call per candidate, capped

Only (c) needs a backend. It is behind the `Regenerator` protocol so the rest
of the system, and all of the tests, run without one.

The asymmetry that governs every choice here: an edge OMITTED from the
estimate breaks Theorem 2, while an edge spuriously INCLUDED costs only
precision. So we over-approximate by default and refine only where refinement
is cheap and checkable.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Protocol, Sequence

from .lattice import Item


class Regenerator(Protocol):
    """Re-run a generation with one candidate withheld. Backend-specific."""

    def regenerate(self, context: Sequence[Item], withheld: Item) -> str: ...


@dataclass
class EstimatorConfig:
    """Configured, not tuned. Fixed on a pilot before any attack was run."""

    tau: float = 0.15          # semantic-change threshold for signal (c)
    loo_max_cluster: int = 16  # skip (c) above this size; see Section 6.6
    enable_loo: bool = True
    # Leave-one-out probes within a cluster are independent: each withholds a
    # different candidate and compares against the same summary. Against a
    # rate-limited API concurrency buys nothing, because the limit binds
    # first. Against a local server it is the difference between one GPU
    # stream and a saturated batch.
    loo_workers: int = 1


@dataclass
class EstimatorStats:
    """Counters the paper reports. `fallbacks` is the number the TODO in
    Section 4.5 asks for: if it is large, the effective estimator is the
    trivial one and Proposition 2 predicts the resulting TER."""

    calls: int = 0
    fallbacks: int = 0
    loo_calls: int = 0
    loo_skipped: int = 0

    @property
    def fallback_rate(self) -> float:
        return self.fallbacks / self.calls if self.calls else 0.0


def estimate(
    generated_text: str,
    context: Sequence[Item],
    *,
    retrieved: Sequence[Item] = (),
    field_attribution: Sequence[Item] = (),
    regenerator: Regenerator | None = None,
    similarity: Callable[[str, str], float] | None = None,
    cfg: EstimatorConfig | None = None,
    stats: EstimatorStats | None = None,
) -> list[Item]:
    """Return the attributed subset of `context`. Never returns empty.

    The fail-closed rule is the last line: an unattributed generation is
    treated as influenced by everything, never as influenced by nothing.
    Every soundness claim in the paper is conditional on it.
    """
    cfg = cfg or EstimatorConfig()
    stats = stats or EstimatorStats()
    stats.calls += 1

    attributed: dict[str, Item] = {}

    # (a) retrieval provenance -- a hard edge, recorded not estimated
    for it in retrieved:
        attributed[it.item_id] = it

    # (b) segmented generation -- per-field, when the harness emits fields
    for it in field_attribution:
        attributed[it.item_id] = it

    # (c) leave-one-out probing -- only when affordable and only for
    #     candidates (a) and (b) did not already settle
    if cfg.enable_loo and regenerator is not None and similarity is not None:
        candidates = [it for it in context if it.item_id not in attributed]
        if len(context) <= cfg.loo_max_cluster:
            if cfg.loo_workers > 1 and len(candidates) > 1:
                import concurrent.futures as _cf
                with _cf.ThreadPoolExecutor(
                        max_workers=cfg.loo_workers) as ex:
                    alts = list(ex.map(
                        lambda c: regenerator.regenerate(context, c),
                        candidates))
            else:
                alts = [regenerator.regenerate(context, c) for c in candidates]
            for cand, alt in zip(candidates, alts):
                stats.loo_calls += 1
                if 1.0 - similarity(generated_text, alt) > cfg.tau:
                    attributed[cand.item_id] = cand
        else:
            stats.loo_skipped += 1

    if not attributed:
        # FAIL CLOSED. Do not delete this branch.
        stats.fallbacks += 1
        return list(context)

    return list(attributed.values())


def attributed_cluster_size(sizes: Sequence[int]) -> float:
    """The parameter `a` of Proposition 2: mean attributed cluster size.

    Report this from a real run and hand it to analysis.prop2 to get the
    predicted TER. It is the single number that decides whether the utility
    gate of Section 6.3 is reachable at all.
    """
    return sum(sizes) / len(sizes) if sizes else 0.0
