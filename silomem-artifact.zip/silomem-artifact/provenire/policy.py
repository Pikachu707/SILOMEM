"""The read/act split of Section 4.8, Table 2.

Action classes are ordered by REVERSIBILITY, which is the property the policy
actually keys on: a read-only tool call can be retracted by ignoring its
result, a file write cannot, and an outbound message cannot be recalled at all.
"""
from __future__ import annotations

from enum import IntEnum, Enum

from .lattice import Level


class ActionClass(IntEnum):
    A1_ANSWER = 1   # textual answer
    A2_READ = 2     # read-only tool: search, file read
    A3_LOCAL = 3    # local state change: file write, exec
    A4_OUTBOUND = 4 # irreversible / outbound: email, payment, external POST


class Decision(Enum):
    ALLOW = "A"
    CONFIRM = "C"
    DENY = "D"


# Table 2, strict configuration.
STRICT = {
    (Level.T, ActionClass.A1_ANSWER):  Decision.ALLOW,
    (Level.T, ActionClass.A2_READ):    Decision.ALLOW,
    (Level.T, ActionClass.A3_LOCAL):   Decision.ALLOW,
    (Level.T, ActionClass.A4_OUTBOUND):Decision.ALLOW,
    (Level.D, ActionClass.A1_ANSWER):  Decision.ALLOW,
    (Level.D, ActionClass.A2_READ):    Decision.ALLOW,
    (Level.D, ActionClass.A3_LOCAL):   Decision.CONFIRM,
    (Level.D, ActionClass.A4_OUTBOUND):Decision.CONFIRM,
    (Level.U, ActionClass.A1_ANSWER):  Decision.ALLOW,   # with lineage note
    (Level.U, ActionClass.A2_READ):    Decision.CONFIRM,
    (Level.U, ActionClass.A3_LOCAL):   Decision.DENY,
    (Level.U, ActionClass.A4_OUTBOUND):Decision.DENY,
}

# Permissive relaxes only the D row of A3/A4: an item all of whose sources
# were trusted but whose attribution was imprecise is a different object from
# one that descends from an untrusted document. Both are policies over the
# same lattice; neither touches Algorithm 1 or Theorem 2.
PERMISSIVE = dict(STRICT)
PERMISSIVE[(Level.D, ActionClass.A3_LOCAL)] = Decision.ALLOW
PERMISSIVE[(Level.D, ActionClass.A4_OUTBOUND)] = Decision.ALLOW


def decide(level: Level, action: ActionClass, *, permissive: bool = False):
    return (PERMISSIVE if permissive else STRICT)[(level, action)]


def annotates_lineage(level: Level, action: ActionClass) -> bool:
    """Goal G2: a U-derived answer is allowed but carries its origin set."""
    return level is Level.U and action is ActionClass.A1_ANSWER
