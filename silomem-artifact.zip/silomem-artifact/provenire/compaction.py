"""Algorithm 1, taint-preserving compaction (Section 4.7).

The reason this file exists at all: a compactor destroys and re-authors the
content it summarises, so a label bound to syntax does not survive it. We
re-derive the label at the compactor over the *attributed* subset instead.
Theorem 2 extends across compaction rounds precisely because line 7 below is a
meet over a set containing the predecessor.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Protocol, Sequence

from .influence import EstimatorConfig, EstimatorStats, Regenerator, estimate
from .lattice import Item, Level, Provenance, meet


class Compactor(Protocol):
    """The base compactor being wrapped. Framework-specific."""

    def cluster(self, items: Sequence[Item]) -> list[list[Item]]: ...
    def summarise(self, cluster: Sequence[Item]) -> str: ...


@dataclass
class CompactionResult:
    items: list[Item]
    attributed_sizes: list[int]   # feeds `a` in Proposition 2
    stats: EstimatorStats


def taint_preserving_compaction(
    memory: Sequence[Item],
    compactor: Compactor,
    *,
    regenerator: Regenerator | None = None,
    similarity: Callable[[str, str], float] | None = None,
    cfg: EstimatorConfig | None = None,
    next_id: Callable[[], str] | None = None,
) -> CompactionResult:
    """Algorithm 1. Line numbers below match the paper.

    The wrapper sits OUTSIDE the base compactor's clustering: it observes the
    clusters `compactor` produces and re-derives a label for each summary, but
    does not influence how items are grouped. That keeps PROVENIRE independent
    of the compactor's internals, which is what lets it wrap an unmodified
    framework. Section 4.7 flags label-aware clustering as an ablation.
    """
    stats = EstimatorStats()
    counter = [0]

    def _mkid() -> str:
        counter[0] += 1
        return f"sum{counter[0]:06d}"

    mkid = next_id or _mkid

    out: list[Item] = []                      # 1: M' <- {}
    sizes: list[int] = []

    for cluster in compactor.cluster(memory):  # 2: for all cluster K
        text = compactor.summarise(cluster)    # 3: s <- C(K)
        attributed = estimate(                 # 4: A <- Ihat(s, K)
            text, cluster,
            retrieved=(), field_attribution=(),
            regenerator=regenerator, similarity=similarity,
            cfg=cfg, stats=stats,
        )
        if not attributed:                     # 5: fail closed
            attributed = list(cluster)

        level = meet(i.level for i in attributed)              # 7
        origins = frozenset().union(*(i.origins for i in attributed))  # 8

        out.append(Item(mkid(), text, level, origins, Provenance.BY_MEET))
        sizes.append(len(attributed))

    return CompactionResult(out, sizes, stats)                 # 11: return


def trivial_compaction(
    memory: Sequence[Item], compactor: Compactor,
    *, next_id: Callable[[], str] | None = None,
) -> CompactionResult:
    """The ablation baseline of Section 6.7: attribute every summary to its
    whole cluster. Sound and useless. Any provenance system for agents has to
    beat this to be more than a session-level kill switch, and Proposition 2
    predicts what it costs: TER -> 1 for any cluster size above one.
    """
    counter = [0]

    def _mkid() -> str:
        counter[0] += 1
        return f"triv{counter[0]:06d}"

    mkid = next_id or _mkid
    out, sizes = [], []
    for cluster in compactor.cluster(memory):
        text = compactor.summarise(cluster)
        level = meet(i.level for i in cluster)
        origins = frozenset().union(*(i.origins for i in cluster))
        out.append(Item(mkid(), text, level, origins, Provenance.BY_MEET))
        sizes.append(len(cluster))
    return CompactionResult(out, sizes, EstimatorStats())
