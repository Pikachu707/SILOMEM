"""Longitudinal canary probes (Section 4.10).

The labels are the primary mechanism; this is the backstop for the case they
are lost --- an estimator that misses an edge, or a compaction round that
drops a side-table record. It works by fixing a suite of probe decisions whose
correct outcome does not change over the run, replaying them at every
compaction epoch, and testing whether the agent's decision-policy fingerprint
has moved.

WHAT A PROBE IS HERE. The paper specifies the fingerprint as the distribution
over the agent's chosen action on each probe. In this harness a probe is a
memory item with known lineage plus an action class, and the outcome is the
enforcement decision. That is narrower than a full behavioural fingerprint,
and it is narrower in an informative direction: it isolates drift caused by
label loss from drift caused by the model changing its mind, because the
policy is a lookup and cannot change its mind. A probe that fires here means a
label moved.

The false-positive rate is what decides whether this is deployable at all. A
probe that fires on clean workloads is worse than no probe, because it trains
the operator to ignore it.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Sequence

from .lattice import Item, Level, SourceClass, label_source
from .policy import ActionClass, Decision, decide


@dataclass(frozen=True)
class Probe:
    """One invariant decision. `expected` is fixed at suite construction."""

    probe_id: str
    item: Item
    action: ActionClass
    expected: Decision


def build_suite(n: int = 32, seed: int = 0,
                permissive: bool = False) -> list[Probe]:
    """A fixed suite of untrusted-lineage probes, spanning the action classes.

    Only untrusted sources. An earlier version spanned the whole lattice on
    the reasoning that a suite of untrusted items would be blind to half the
    label space, but that reasoning is wrong twice over. The loss this probe
    backstops is untrusted lineage becoming trusted; a trusted item cannot
    lose its label in the harmful direction, so a trusted probe can only
    report noise. And trusted items carry no origin set --- \cref{eq:meet}
    records origins for untrusted lineage only --- so they cannot be resolved
    through a compaction round at all, which made half the suite silently
    unresolvable after the first epoch.

    Each probe therefore carries its own ingestion event, and is resolved
    through the store by that event rather than by identity: after compaction
    the probe item is gone and its lineage lives in the summary that replaced
    it, which is exactly the transition the probe exists to watch.
    """
    rng = random.Random(seed)
    classes = [SourceClass.RETRIEVED, SourceClass.USER_PASTED]
    actions = [ActionClass.A2_READ, ActionClass.A3_LOCAL,
               ActionClass.A4_OUTBOUND]
    probes = []
    for i in range(n):
        cls = classes[i % len(classes)]
        act = actions[(i // len(classes)) % len(actions)]
        it = label_source(f"probe{i:03d}",
                          f"probe item {i} " + str(rng.random()),
                          cls, f"probe_ev{i}")
        probes.append(Probe(f"p{i:03d}", it, act,
                            decide(it.level, act, permissive=permissive)))
    return probes


def fingerprint(suite: Sequence[Probe], resolve, *,
                permissive: bool = False) -> tuple[Decision, ...]:
    """Replay the suite against the current store.

    `resolve(item) -> Level` returns the level the store currently holds for
    that item. In a clean run it returns what the item was labelled with; if a
    label has been lost it returns something higher, and the decision moves.
    """
    return tuple(decide(resolve(p.item), p.action, permissive=permissive)
                 for p in suite)


def distance(a: Sequence[Decision], b: Sequence[Decision]) -> float:
    """Fraction of probes whose decision differs. Total variation over the
    empirical decision distribution when each probe is replayed once."""
    if not a:
        return 0.0
    return sum(1 for x, y in zip(a, b) if x is not y) / len(a)


@dataclass
class ProbeMonitor:
    """Permutation test against a baseline window, Holm-corrected.

    The correction is not optional. The probe fires at every compaction epoch,
    so an uncorrected test at a plausible epoch count produces a false alarm
    by construction --- which is exactly the failure mode that makes an
    operator stop reading the alerts.
    """

    window: int = 5
    alpha: float = 0.01
    reps: int = 2000
    seed: int = 0
    history: list[tuple[Decision, ...]] = field(default_factory=list)
    pvalues: list[float] = field(default_factory=list)

    def observe(self, fp: tuple[Decision, ...]) -> float | None:
        """Record one epoch. Returns its p-value, or None while warming up."""
        if len(self.history) < self.window:
            self.history.append(fp)
            return None
        base = self.history[-self.window:]
        obs = sum(distance(fp, b) for b in base) / len(base)

        rng = random.Random(self.seed + len(self.history))
        pool = [d for b in base for d in b] + list(fp)
        hits = 0
        for _ in range(self.reps):
            shuffled = pool[:]
            rng.shuffle(shuffled)
            k = len(fp)
            cand = tuple(shuffled[:k])
            rest = [tuple(shuffled[i:i + k])
                    for i in range(k, len(shuffled) - k + 1, k)]
            if not rest:
                continue
            null = sum(distance(cand, r) for r in rest) / len(rest)
            if null >= obs:
                hits += 1
        p = (hits + 1) / (self.reps + 1)
        self.history.append(fp)
        self.pvalues.append(p)
        return p

    def alarms(self) -> list[bool]:
        """Holm-corrected across every epoch seen so far."""
        if not self.pvalues:
            return []
        idx = sorted(range(len(self.pvalues)), key=lambda i: self.pvalues[i])
        m = len(self.pvalues)
        out = [False] * m
        for rank, i in enumerate(idx):
            if self.pvalues[i] <= self.alpha / (m - rank):
                out[i] = True
            else:
                break
        return out
