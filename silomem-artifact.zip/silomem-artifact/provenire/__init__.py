"""PROVENIRE reference implementation.

Everything in this package is model-independent and unit-tested. The parts
that need a backend sit behind protocols (influence.Regenerator,
compaction.Compactor) so the guarantees can be checked without one.
"""
from .lattice import Level, Item, meet, label_source, label_generated
from .compaction import taint_preserving_compaction, trivial_compaction
from .policy import ActionClass, Decision, decide
from .declassify import Budget, Ledger, d1_principal, d2_corroborate

__all__ = [
    "Level", "Item", "meet", "label_source", "label_generated",
    "taint_preserving_compaction", "trivial_compaction",
    "ActionClass", "Decision", "decide",
    "Budget", "Ledger", "d1_principal", "d2_corroborate",
]
