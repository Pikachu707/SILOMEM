#!/usr/bin/env bash
# The two remaining TODOs that need a machine. The other two are facts
# about your setup, not experiments.
#
#   export VLLM_KEY=local
#   bash run_final_todos.sh 2>&1 | tee final.log
set -uo pipefail
source .venv/bin/activate 2>/dev/null || true
export VLLM_KEY="${VLLM_KEY:-local}"
MODEL="${MODEL:-Qwen/Qwen2.5-7B-Instruct}"
BENCH="${BENCH:-mem-inv-bench}"
OUT="${OUT:-results}"; mkdir -p "$OUT"
hr() { printf '%.0s=' {1..70}; echo; }

hr; echo "1/2  MEM-INV-Bench with compaction rounds inserted"; hr
echo "Section 6.3, measured rather than argued. Their scenarios ingest once"
echo "and act once; we insert the rounds and report where over-tainting goes."
echo
if [ ! -d "$BENCH" ]; then
  echo "cloning the benchmark"
  git clone --depth 1 https://github.com/yedidel/mem-inv-bench "$BENCH"
fi
python harness/run_meminvbench.py --bench "$BENCH" --variant adaptive \
  | tee "$OUT/meminvbench_characterisation.txt"
echo
python harness/run_meminvbench_full.py --bench "$BENCH" \
  --backend vllm --model "$MODEL" --base-url http://localhost:8000/v1 \
  --api-key-env VLLM_KEY --rounds 0,1,3,7,15 --pool 48 \
  --loo-workers 32 --out "$OUT/meminvbench_full.json"

hr; echo "2/2  storage against horizon"; hr
echo "The 2.77x in the body is at run start. The origin set is a monotone"
echo "union, so the question is the slope, not the intercept."
python harness/run_rq2.py --backend vllm --model "$MODEL" \
  --seeds 3 --horizon 200 --budget-items 48 --keep-frac 0 \
  --sweep-u 0.20 --declass-rate 0.5 --loo-max-cluster 16 \
  --loo-workers 32 --max-calls 0 --out "$OUT/storage_horizon.json"

hr; echo "regenerate the appendix table"; hr
python analysis/make_appendix_table.py "$OUT" > "$OUT/appendix_grid.tex"
echo "wrote $OUT/appendix_grid.tex"

hr
echo "The other two TODOs are facts, not experiments:"
echo "  - which framework PROVENIRE wraps (Sec 5)"
echo "  - component versions: results/versions.txt has them already"
