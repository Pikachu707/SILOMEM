# Running this at zero cost

Short version: **`HostedBackend` speaks the OpenAI chat-completions API, and
so do Ollama, vLLM and llama.cpp's server.** Point `base_url` at localhost and
nothing else changes. There is no separate local code path to write.

```python
from harness.backends import HostedBackend

backend = HostedBackend(
    model="qwen2.5:7b-instruct",
    base_url="http://localhost:11434/v1",   # Ollama
    api_key_env="OLLAMA_KEY",               # any non-empty value
)
```

```bash
export OLLAMA_KEY=local     # the client wants a token; Ollama ignores it
```

---

## What the evaluation actually costs

Run `python analysis/cost.py` with your own parameters. With the defaults:

| scenario | calls | on a $0.15/$0.60 model |
|---|---|---|
| pilot grid (5 seeds × 4 attacks) | 13,750 | $2.02 |
| frontier model, same grid | 13,750 | $45.38 |
| frontier as a spot-check only (1 seed) | 2,750 | $9.07 |
| powered grid (163/cell, MDE 0.15) | 448,250 | $65.89 |

Three things the estimator makes explicit, because each looks like a
multiplier and is not:

- **strict vs permissive** is a lookup in Table 2 applied after the run. Zero
  extra calls. Run once, report both.
- **defended vs undefended** replays the *same* trajectory — that is what
  makes the comparison paired — so with `temperature=0` and the cache on, the
  second arm is free.
- **the four horizons** are snapshots of one K=20 trajectory, not four runs.
  That is the paper's own cost-saving trick and it is already a 4× saving.

**Leave-one-out probing is 80% of the bill.** Everything else is noise next to
it. Options, in the order I would try them:

1. Keep it, run it on a local model. It is the component whose *cost* scales
   badly, not whose *quality* matters most — it answers "did withholding this
   change the summary", which a 7B model can do.
2. Cap `loo_max_cluster` lower than 16. Clusters above the cap fall back to
   the trivial estimator for that item, which is sound but raises `a`.
3. Disable it entirely (`--loo-off`, 2,750 calls). Sound, but `a` rises to the
   full cluster size and by Proposition 2 you then need a much higher
   declassification rate to stay under the gate. **Cheaper to run, harder to
   pass.** If you go this way, report it as a configuration rather than
   hiding it.

---

## Option 1: local models (genuinely free, needs hardware)

### Ollama — easiest

```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama serve &                    # OpenAI-compatible on :11434/v1
ollama pull qwen2.5:7b-instruct   # ~4.7 GB
ollama pull qwen2.5:1.5b-instruct # ~1 GB, for the activation probe
```

CPU-only is fine for the small model and slow but workable for 7B. Rough
throughput on 8 CPU cores: 7B q4 gives ~5–10 tok/s, so a 120-token summary is
~15–25 s. At 13,750 calls that is **60–95 hours wall-clock**. Run it in a
`tmux` session and let it go over a weekend; the cache means an interrupted
run resumes rather than restarts.

With one consumer GPU (12 GB+), the same grid is 2–4 hours.

### vLLM — faster if you have a GPU

```bash
pip install vllm
python -m vllm.entrypoints.openai.api_server \
    --model Qwen/Qwen2.5-7B-Instruct --port 8000
```

Batches properly, so throughput is 10–50× Ollama on the same card. Worth it
above ~50k calls.

### The activation probe specifically

Section 3.3 already commits to a sub-1B open model on CPU, and argues that
this *strengthens* the negative result rather than weakening it. So this part
was designed to be free. `qwen2.5:0.5b` or `pythia-410m` with
`output_hidden_states=True` via transformers, no server needed.

---

## Option 2: free API tiers (no hardware needed)

These are rate-limited rather than paid. With `temperature=0`, the on-disk
cache, and patience, a rate limit is a scheduling problem, not a cost.

| provider | what you get | notes |
|---|---|---|
| Google AI Studio (Gemini) | generous daily free tier | OpenAI-compatible endpoint available |
| Groq | free tier, very fast | good for the bulk LOO calls |
| Cerebras | free tier | very fast |
| Mistral La Plateforme | free tier | |
| OpenRouter | some models free | one key, many models |
| Together AI | starting credits | |

Verify the current limits yourself before planning around them — they change
often, and I would not build a three-week schedule on a number I read once.

Add a rate limiter to `HostedBackend._complete` before pointing it at a free
tier; without one you will spend the first hour getting 429s.

---

## Option 3: academic credits

Worth an email before you start, because they take days to weeks:

- OpenAI Researcher Access Program
- Anthropic external researcher program
- Google Cloud / AWS / Azure research credits
- Your institution's cluster — often the fastest route, and free

---

## What I would actually do

1. **Today, free:** `setup.sh`, then the mock pilot. Proves the pipeline.
2. **This week, free:** Ollama + `qwen2.5:7b-instruct` on your server. Run the
   *pilot* grid (5 seeds), not the powered grid. You are looking for
   breakage and for the RQ2 gate, not for publishable numbers.
3. **Only if the gate passes:** scale to the powered grid. Still local if the
   wall-clock is tolerable; a free tier or ~$60 of hosted inference if not.
4. **Frontier model last, and only as a consistency check** — which is what
   Section 6.1 already says. That is $9, not $45.

The order matters more than the budget. If RQ2 fails the gate, the design
changes and everything downstream is thrown away. Do not spend money — or a
week of GPU time — on attack coverage before you know the utility cost.
