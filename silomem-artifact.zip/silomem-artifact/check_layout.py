#!/usr/bin/env python3
"""Check a built paper's layout by looking at the rendered pages.

    python check_layout.py main.pdf

The LaTeX log reports boxes that do not fit. It says nothing about a column
that ends short of its neighbour, a float that leaves a hole mid-column, or a
section heading stranded at a page foot, and those are what a reader notices.
This rasterises every page and measures them.

TWO MEASUREMENT TRAPS, both hit while writing this:

  the page-number band. IEEEtran puts the folio at the very foot, so a naive
  "lowest ink" scan reports every page as full and hides the thing being
  looked for. The band sits below y=985 at 100dpi; measure above it.

  the tolerance. Columns that differ by a few pixels are aligned: that is
  \\flushbottom's glue at work, not a defect. Only a gap of more than ~30px
  (0.8cm) is visible to a reader. A tighter threshold reports noise and
  trains you to ignore the output.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
import tempfile

DPI = 100
FOLIO_Y = 985          # page-number band starts below this
ALIGN_TOL = 30         # px; below this the columns read as aligned
GAP_TOL = 115          # px; an internal blank run larger than this is a hole.
                       # A subsection heading legitimately leaves up to
                       # ~100px of
                       # space around it, so a tighter threshold reports
                       # correct typography as a defect and trains you to
                       # ignore the output.


def render(pdf, outdir):
    subprocess.run(["pdftoppm", "-png", "-r", str(DPI), pdf,
                    os.path.join(outdir, "pg")], check=True)
    return sorted(os.path.join(outdir, f) for f in os.listdir(outdir)
                  if f.endswith(".png"))


def columns(path):
    from PIL import Image
    im = Image.open(path).convert("L")
    w, h = im.size
    px = im.load()

    def lowest(x0, x1):
        for y in range(FOLIO_Y, -1, -1):
            for x in range(x0, x1, 2):
                if px[x, y] < 200:
                    return y
        return 0

    def gaps(x0, x1):
        out, blank = [], 0
        for y in range(int(h * 0.08), FOLIO_Y):
            if any(px[x, y] < 200 for x in range(x0, x1, 2)):
                if blank > GAP_TOL:
                    out.append((y - blank, blank))
                blank = 0
            else:
                blank += 1
        return out

    L = (int(w * 0.08), int(w * 0.47))
    R = (int(w * 0.53), int(w * 0.92))
    return lowest(*L), lowest(*R), gaps(*L), gaps(*R)


def main() -> None:
    pdf = sys.argv[1] if len(sys.argv) > 1 else "main.pdf"
    issues = []
    with tempfile.TemporaryDirectory() as d:
        pages = render(pdf, d)
        print(f"{'page':>5}{'L':>7}{'R':>7}{'diff':>7}   note")
        print("-" * 44)
        for i, p in enumerate(pages, 1):
            lo, ro, lg, rg = columns(p)
            diff = abs(lo - ro)
            note = ""
            # the last page is balanced rather than filled, by design
            if i < len(pages) and diff > ALIGN_TOL:
                note = "COLUMNS UNEVEN"
                issues.append(f"p{i}: columns differ by {diff}px "
                              f"({diff/DPI*2.54:.1f}cm)")
            for side, gs in (("L", lg), ("R", rg)):
                for y, n in gs:
                    issues.append(f"p{i}{side}: {n}px hole at y={y} "
                                  f"({n/DPI*2.54:.1f}cm)")
                    note = "HOLE"
            print(f"{i:>5}{lo:>7}{ro:>7}{diff:>7}   {note}")

    # stranded headings, which the pixels cannot distinguish from prose
    for i in range(1, len(pages) + 1):
        t = subprocess.run(["pdftotext", "-layout", "-f", str(i), "-l", str(i),
                            pdf, "-"], capture_output=True, text=True).stdout
        lines = [l for l in t.split("\n") if l.strip()]
        if lines and re.match(r"^\d+(\.\d+)?\.\s+[A-Z]", lines[-1].strip()):
            issues.append(f"p{i}: section heading stranded at the foot")
        # a column ending on one or two words reads as a mistake. Skip
        # bibliography pages: an entry ending short is normal there.
        if lines and "[1]" not in t and not re.search(r"\[\d+\]", t[:400]):
            # only the final line can be a column foot; earlier ones in the
            # window may be runin headings introducing a list, which are not
            # short trailing lines and reporting them trains you to ignore
            # the output
            for l in lines[-1:]:
                left = l[:66].strip()
                if (left and len(left.split()) <= 2
                        and not left.replace(".", "").isdigit()
                        and not left[0].isdigit()):
                    issues.append(f"p{i}: column ends on {left!r}")

    print()
    if issues:
        print(f"{len(issues)} issue(s):")
        for s in issues:
            print("  " + s)
    else:
        print("no uneven columns, no internal holes, no stranded headings")


if __name__ == "__main__":
    main()
