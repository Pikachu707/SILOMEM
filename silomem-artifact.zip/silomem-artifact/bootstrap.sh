#!/usr/bin/env bash
# Bring a freshly imaged host to the point where setup_h100.sh can run.
#
# setup_h100.sh assumes a working driver and python3-venv. A new image has
# neither guaranteed, and the failure when python3-venv is missing is an
# error about apt rather than about venv, which costs more time to read than
# it should. This script checks first and installs only what is absent.
#
# IT DOES NOT TOUCH THE DRIVER unless there is none. Reinstalling a working
# NVIDIA driver is a good way to end up with a host that does not boot, and
# GPU images almost always ship one.
set -uo pipefail
hr() { printf '%.0s=' {1..70}; echo; }

hr; echo "  WHAT IS ALREADY HERE"; hr

echo -n "os        "; (lsb_release -ds 2>/dev/null || grep PRETTY /etc/os-release | cut -d'"' -f2)
echo -n "python    "; python3 --version 2>&1
echo -n "venv      "; python3 -c "import venv; print('present')" 2>&1 | tail -1
echo -n "pip       "; (pip3 --version 2>/dev/null | cut -d' ' -f1-2) || echo "absent"
echo -n "driver    "; nvidia-smi --query-gpu=name,driver_version --format=csv,noheader 2>/dev/null | head -1 || echo "ABSENT"
echo -n "disk free "; df -h --output=avail / | tail -1 | tr -d ' '
echo -n "cuda      "; (nvcc --version 2>/dev/null | grep -o 'release [0-9.]*') || echo "no nvcc (not required: vLLM ships its own)"

echo
DRIVER_OK=0
nvidia-smi >/dev/null 2>&1 && DRIVER_OK=1

# Four models are about 60GB. Warn before a download fails at 95%.
AVAIL=$(df --output=avail -BG / | tail -1 | tr -dc '0-9')
if [ "${AVAIL:-0}" -lt 80 ]; then
  hr
  echo "ONLY ${AVAIL}GB FREE ON /. The four backends need about 60GB of"
  echo "weights and vLLM needs room to compile. Either mount a larger"
  echo "volume and point HF_HOME at it:"
  echo "    export HF_HOME=/mnt/data/hf"
  echo "or run one backend at a time. A download that dies at 95 percent"
  echo "leaves a partial cache that the next attempt does not resume from."
  hr
fi

hr; echo "  INSTALLING WHAT IS MISSING"; hr

NEED=()
python3 -c "import venv" 2>/dev/null || NEED+=(python3-venv)
command -v pip3   >/dev/null || NEED+=(python3-pip)
command -v git    >/dev/null || NEED+=(git)
command -v unzip  >/dev/null || NEED+=(unzip)
command -v tmux   >/dev/null || NEED+=(tmux)
python3 -c "import sysconfig,os;exit(0 if os.path.exists(sysconfig.get_paths()['include']+'/Python.h') else 1)" \
  2>/dev/null || NEED+=(python3-dev build-essential)

if [ ${#NEED[@]} -eq 0 ]; then
  echo "nothing to install"
else
  echo "installing: ${NEED[*]}"
  sudo apt-get update -qq
  sudo apt-get install -y "${NEED[@]}" || {
    echo "FATAL: apt-get failed. If this is a lock error, another process"
    echo "is holding dpkg; wait for cloud-init to finish and re-run."
    exit 1; }
fi

if [ "$DRIVER_OK" -eq 0 ]; then
  hr
  echo "NO NVIDIA DRIVER. Check the image notes in the provider console"
  echo "before installing one: GPU images normally ship a driver, and a"
  echo "version mismatch is harder to recover from than a missing one."
  echo
  echo "If the console confirms there is none:"
  echo "    sudo apt-get install -y nvidia-driver-535"
  echo "    sudo reboot"
  echo "then re-run this script."
  hr
  exit 1
fi

hr; echo "  READY"; hr
echo "Next, inside tmux so a dropped connection does not kill it:"
echo
echo "    tmux new -s setup"
echo "    bash setup_h100.sh 2>&1 | tee setup.log"
echo
echo "Then verify BEFORE running any experiment:"
echo
echo "    source .venv/bin/activate && python -m pytest tests/ -q"
echo
echo "The suite runs in under a second and needs no GPU. It has caught a"
echo "broken environment several times; an experiment that fails on call"
echo "180 of 240 costs far more than the second this takes."
